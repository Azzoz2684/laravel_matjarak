<?php
namespace Tests\Feature;

use App\Models\Comment;
use App\Models\Notification;
use App\Models\Post;
use App\Models\Report;
use App\Models\User;
use App\Models\UserRole;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * RBAC & auth coverage for likes / not_interested / comments / reports / notifications.
 * Verifies 401 (guest), 403 (wrong role / wrong owner), and 2xx for the proper role.
 */
class RbacEndpointsTest extends TestCase
{
    use RefreshDatabase;

    protected function makeUser(string $role = 'user'): User
    {
        $u = User::create([
            'username' => 'u_'.uniqid(),
            'phone' => '249'.rand(100000000, 999999999),
            'password' => 'secret123',
        ]);
        UserRole::create(['user_id' => $u->id, 'role' => $role]);
        return $u;
    }

    protected function makePost(User $owner): Post
    {
        return Post::create([
            'user_id' => $owner->id, 'title' => 'منتج اختبار', 'description' => 't',
            'price' => 100, 'currency' => 'SDG', 'category' => 'إلكترونيات',
            'state' => 'الخرطوم', 'status' => 'active',
        ]);
    }

    public function test_guest_gets_401_or_redirect_on_protected_endpoints()
    {
        $owner = $this->makeUser('seller');
        $post = $this->makePost($owner);

        foreach ([
            ['POST', "/posts/{$post->id}/like"],
            ['POST', "/posts/{$post->id}/not-interested"],
            ['POST', "/posts/{$post->id}/comments"],
            ['POST', "/posts/{$post->id}/report"],
            ['GET',  "/notifications"],
            ['GET',  "/notifications/feed"],
        ] as [$m, $url]) {
            $res = $this->json($m, $url, ['body' => 'x', 'reason' => 'x']);
            $this->assertContains($res->getStatusCode(), [401, 302, 419], "Endpoint $url leaked to guest");
        }
    }

    public function test_user_can_like_save_not_interested_comment_report()
    {
        $owner = $this->makeUser('seller');
        $post = $this->makePost($owner);
        $user = $this->makeUser('user');

        $this->actingAs($user)->postJson("/posts/{$post->id}/like")->assertOk()->assertJson(['liked' => true]);
        $this->actingAs($user)->postJson("/posts/{$post->id}/not-interested")->assertOk();
        $this->actingAs($user)->post("/posts/{$post->id}/comments", ['body' => 'تعليق جيد'])->assertRedirect();
        $this->actingAs($user)->postJson("/posts/{$post->id}/report", ['reason' => 'محتوى مخالف'])->assertOk();
        $this->assertDatabaseHas('reports', ['user_id' => $user->id, 'post_id' => $post->id]);
    }

    public function test_non_admin_cannot_access_admin_routes()
    {
        $user = $this->makeUser('user');
        $seller = $this->makeUser('seller');
        foreach ([$user, $seller] as $u) {
            $this->actingAs($u)->get('/admin')->assertForbidden();
            $this->actingAs($u)->get('/admin/reports')->assertForbidden();
        }
    }

    public function test_admin_can_act_on_report_and_notifies_reporter()
    {
        $admin = $this->makeUser('admin');
        $reporter = $this->makeUser('user');
        $owner = $this->makeUser('seller');
        $post = $this->makePost($owner);
        $report = Report::create([
            'user_id' => $reporter->id, 'post_id' => $post->id,
            'reason' => 'spam', 'status' => 'pending',
        ]);

        $this->actingAs($admin)->post("/admin/reports/{$report->id}/act", [
            'status' => 'reviewed',
            'action_reason' => 'مخالف للشروط',
            'post_action' => 'hide',
        ])->assertRedirect();

        $this->assertDatabaseHas('posts', ['id' => $post->id, 'status' => 'hidden']);
        $this->assertDatabaseHas('notifications', [
            'user_id' => $reporter->id,
            'post_id' => $post->id,
        ]);
    }

    public function test_admin_action_does_not_notify_when_reporter_disabled()
    {
        $admin = $this->makeUser('admin');
        $reporter = $this->makeUser('user');
        $reporter->update(['notify_enabled' => false]);
        $owner = $this->makeUser('seller');
        $post = $this->makePost($owner);
        $report = Report::create([
            'user_id' => $reporter->id, 'post_id' => $post->id,
            'reason' => 'r', 'status' => 'pending',
        ]);

        $this->actingAs($admin)->post("/admin/reports/{$report->id}/act", [
            'status' => 'dismissed', 'action_reason' => 'لا يوجد مخالفة',
        ])->assertRedirect();

        $this->assertDatabaseMissing('notifications', ['user_id' => $reporter->id]);
    }

    public function test_user_cannot_mark_or_delete_other_users_notifications()
    {
        $a = $this->makeUser('user');
        $b = $this->makeUser('user');
        $n = Notification::create(['user_id' => $a->id, 'title' => 't', 'body' => 'b']);

        $this->actingAs($b)->postJson("/notifications/{$n->id}/read")->assertForbidden();
        $this->actingAs($b)->deleteJson("/notifications/{$n->id}")->assertForbidden();
        $this->actingAs($a)->postJson("/notifications/{$n->id}/read")->assertOk();
        $this->assertDatabaseHas('notifications', ['id' => $n->id, 'is_read' => 1]);
    }

    public function test_notifications_feed_filters_by_unread_and_category()
    {
        $u = $this->makeUser('user');
        $owner = $this->makeUser('seller');
        $p1 = $this->makePost($owner);
        $p2 = Post::create(['user_id'=>$owner->id,'title'=>'p2','price'=>1,'currency'=>'SDG','category'=>'سيارات','state'=>'الخرطوم','status'=>'active']);
        Notification::create(['user_id'=>$u->id,'title'=>'a','post_id'=>$p1->id,'is_read'=>false]);
        Notification::create(['user_id'=>$u->id,'title'=>'b','post_id'=>$p2->id,'is_read'=>true]);

        $res = $this->actingAs($u)->getJson('/notifications/feed?filter=unread')->assertOk()->json('items');
        $this->assertCount(1, $res);

        $res = $this->actingAs($u)->getJson('/notifications/feed?category=سيارات')->assertOk()->json('items');
        $this->assertCount(1, $res);
        $this->assertEquals('b', $res[0]['title']);
    }
}
