<?php
namespace Tests\Feature;

use App\Models\Like;
use App\Models\Notification;
use App\Models\Post;
use App\Models\Report;
use App\Models\User;
use App\Models\UserRole;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CoreFeaturesTest extends TestCase
{
    use RefreshDatabase;

    protected function user(string $role = 'user'): User
    {
        $u = User::create([
            'username' => 'u_'.uniqid(),
            'phone' => '249'.rand(100000000, 999999999),
            'password' => 'secret123',
        ]);
        UserRole::create(['user_id' => $u->id, 'role' => $role]);
        return $u;
    }

    protected function post(User $owner, array $attrs = []): Post
    {
        return Post::create(array_merge([
            'user_id' => $owner->id, 'title' => 'منتج', 'price' => 100,
            'currency' => 'SDG', 'category' => 'إلكترونيات', 'state' => 'الخرطوم',
            'status' => 'active', 'whatsapp' => '+249912345678',
        ], $attrs));
    }

    public function test_home_search_filters_by_state()
    {
        $owner = $this->user('seller');
        $khartoum = $this->post($owner, ['title' => 'هاتف خرطوم', 'state' => 'الخرطوم']);
        $kassala  = $this->post($owner, ['title' => 'هاتف كسلا',  'state' => 'كسلا']);

        $html = $this->get('/?state=الخرطوم')->assertOk()->getContent();
        $this->assertStringContainsString('هاتف خرطوم', $html);
        $this->assertStringNotContainsString('هاتف كسلا', $html);
    }

    public function test_report_modal_submission_creates_pending_report()
    {
        $owner = $this->user('seller');
        $post = $this->post($owner);
        $u = $this->user();

        $this->actingAs($u)
            ->postJson("/posts/{$post->id}/report", ['reason' => 'محتوى مخالف'])
            ->assertOk()->assertJson(['success' => true]);

        $this->assertDatabaseHas('reports', [
            'post_id' => $post->id, 'user_id' => $u->id,
            'reason' => 'محتوى مخالف', 'status' => 'pending',
        ]);
    }

    public function test_like_acts_as_important_toggle_and_returns_flag()
    {
        $owner = $this->user('seller');
        $post = $this->post($owner);
        $u = $this->user();

        $r1 = $this->actingAs($u)->postJson("/posts/{$post->id}/like")->assertOk()->json();
        $this->assertTrue($r1['liked']);
        $this->assertTrue($r1['important']);
        $this->assertEquals(1, $r1['likes_count']);
        $this->assertDatabaseHas('likes', ['user_id' => $u->id, 'post_id' => $post->id]);

        $r2 = $this->actingAs($u)->postJson("/posts/{$post->id}/like")->assertOk()->json();
        $this->assertFalse($r2['liked']);
        $this->assertEquals(0, $r2['likes_count']);
    }

    public function test_whatsapp_number_is_normalized_without_spaces()
    {
        $u = $this->user('seller');
        $this->actingAs($u)->post('/posts', [
            'title' => 'سلعة',
            'price' => 50, 'currency' => 'SDG',
            'category' => 'إلكترونيات', 'state' => 'الخرطوم',
            'whatsapp' => '091 234 5678',
        ])->assertRedirect();

        $post = Post::latest()->first();
        $this->assertSame('+249912345678', $post->whatsapp);
        $this->assertStringNotContainsString(' ', $post->whatsapp);
        $waUrl = 'https://wa.me/' . ltrim($post->whatsapp, '+');
        $this->assertSame('https://wa.me/249912345678', $waUrl);
    }

    public function test_admin_action_delivers_notification_to_reporter()
    {
        $admin = $this->user('admin');
        $reporter = $this->user();
        $owner = $this->user('seller');
        $post = $this->post($owner);
        $report = Report::create([
            'user_id' => $reporter->id, 'post_id' => $post->id,
            'reason' => 'r', 'status' => 'pending',
        ]);

        $this->actingAs($admin)->post("/admin/reports/{$report->id}/act", [
            'status' => 'reviewed', 'action_reason' => 'تمت المعالجة', 'post_action' => 'hide',
        ])->assertRedirect();

        $n = Notification::where('user_id', $reporter->id)->first();
        $this->assertNotNull($n);
        $this->assertStringContainsString('قبول', $n->title);
    }
}
