# متجرك — Laravel Marketplace (سوق سوداني)

تطبيق سوق إلكتروني كامل مبني بـ **Laravel 11** ومصمم للعمل على استضافة مشتركة (Hostinger Premium) ويظهر كتطبيق هاتف عبر **TWA** في Google Play.

---

## ✨ الميزات المضافة حديثاً (v2 — Wallet & Privacy)

### 1) نظام المحفظة الإلكترونية 💳
- كل مستخدم يمتلك محفظة برصيد قابل للشحن (SDG افتراضياً).
- **مكافأة تسجيل ترحيبية تلقائية** لكل حساب جديد (يمكن ضبط قيمتها من لوحة التحكم).
- استخدام الرصيد لـ **تمييز الإعلانات** لمدة محددة (افتراضياً 7 أيام).
- الشحن يتم عبر **زر واتساب الدعم** الذي يرسل رسالة مُعدّة تلقائياً باسم المستخدم.
- الإدارة يمكنها شحن المحافظ يدوياً من لوحة التحكم مع ملاحظة لكل عملية.
- كل معاملة محفوظة في `wallet_transactions` (سجل شفاف كامل).
- عمليات الخصم/الإضافة داخل `DB::transaction` مع `lockForUpdate` لمنع سباق البيانات.

### 2) التنبيهات الإدارية (Announcements) 📢
- الأدمن يستطيع إنشاء رسائل تظهر داخل صفحة المحفظة بألوان (معلومة / نجاح / تحذير / هام).
- كل مستخدم يستطيع الضغط «موافق» لإخفاء الرسالة نهائياً (يُحفظ في `wallet_announcement_dismissals`).

### 3) سياسة الخصوصية 🔒
- صفحة عامة `/privacy` قابلة للتحرير من لوحة التحكم.
- **إلزامية القبول**: أي مستخدم مسجّل لم يقبل أحدث إصدار يُعاد توجيهه للصفحة ولا يستطيع استخدام الموقع حتى يقبل.
- زيادة قيمة `privacy_version` تُجبر جميع المستخدمين على القبول من جديد (مفيد عند التحديث).

### 4) الأمان الشامل 🛡️
- Middleware `SecurityHeaders` عام يضيف: `HSTS`, `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`.
- **Rate limiting** على: تسجيل الدخول، إنشاء الحساب، التمييز، الشحن، قبول الخصوصية، والشحن الإداري.
- التحقق من ملكية الإعلان قبل التمييز.
- تشفير `AppSetting::ENCRYPTED_KEYS` للمفاتيح الحساسة.
- CSRF مفعّل تلقائياً في كل النماذج.

---

## 🚀 كيفية التحديث بعد كل `git pull`

في كل مرة تسحب فيها تحديثات من هذا المستودع، نفّذ الأوامر التالية داخل مجلد المشروع على استضافتك:

```bash
# 1) تحديث الاعتماديات (فقط إذا تغيّرت composer.json)
composer install --no-dev --optimize-autoloader

# 2) تنفيذ ملفات الهجرة الجديدة (يُنشئ الجداول تلقائياً)
php artisan migrate --force

# 3) مسح كل الكاش
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear

# 4) إعادة بناء الكاش للأداء (اختياري لكن موصى به)
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 5) رابط تخزين للملفات المرفوعة
php artisan storage:link
```

على Hostinger: افتح **hPanel → Advanced → SSH Access** ونفّذ الأوامر، أو استخدم **Terminal** من داخل File Manager.

---

## 🗂 الملفات الجديدة في هذا التحديث

### قاعدة البيانات
- `database/migrations/2026_07_01_000001_create_wallets_and_featuring.php`
- `database/migrations/2026_07_01_000002_announcements_and_privacy.php`

### نماذج (Models)
- `app/Models/Wallet.php`
- `app/Models/WalletTransaction.php`
- `app/Models/WalletAnnouncement.php`

### متحكمات (Controllers)
- `app/Http/Controllers/WalletController.php`
- `app/Http/Controllers/WalletAnnouncementController.php`
- `app/Http/Controllers/PrivacyController.php`

### Middleware
- `app/Http/Middleware/SecurityHeaders.php`
- `app/Http/Middleware/RequirePrivacyAcceptance.php`

### واجهات (Views)
- `resources/views/wallet/show.blade.php`
- `resources/views/wallet/feature-list.blade.php`
- `resources/views/wallet/feature-confirm.blade.php`
- `resources/views/privacy/policy.blade.php`
- `resources/views/admin/wallets/index.blade.php`
- `resources/views/admin/wallets/transactions.blade.php`
- `resources/views/admin/wallets/settings.blade.php`
- `resources/views/admin/announcements/index.blade.php`

### تعديلات
- `app/Models/User.php` — علاقة `wallet()` + `walletOrCreate()` + حقول الخصوصية.
- `app/Models/Post.php` — حقل `featured_until` + `scopeFeatured()`.
- `app/Http/Controllers/AuthController.php` — منح مكافأة التسجيل التلقائية (عادي + Google + API).
- `app/Http/Controllers/Admin/AdminController.php` — إدارة المحافظ والتنبيهات والخصوصية.
- `app/Http/Controllers/HomeController.php` — استخدام `scopeFeatured` لاحترام تاريخ انتهاء التمييز.
- `resources/views/settings/index.blade.php` — بطاقة المحفظة + رابط سياسة الخصوصية.
- `routes/web.php` — مسارات المحفظة / الأدمن + rate limiting.
- `bootstrap/app.php` — تسجيل الـ middleware.

---

## ⚙ الإعدادات المتاحة من لوحة التحكم

بعد الترقية، افتح **admin → المحافظ → إعدادات المحفظة** (`/admin/wallets-settings`) واضبط:

| المفتاح | الوصف | الافتراضي |
|---|---|---|
| `wallet_signup_bonus` | مكافأة التسجيل (رصيد ترحيبي) | 5000 |
| `wallet_feature_cost` | تكلفة تمييز إعلان واحد | 2000 |
| `wallet_feature_days` | مدة التمييز بالأيام | 7 |
| `wallet_currency` | عملة المحفظة | SDG |
| `support_whatsapp` | رقم واتساب الدعم (دولي بدون +) | — |
| `privacy_policy` | نص سياسة الخصوصية | — |
| `privacy_version` | إصدار السياسة (لإجبار القبول) | 1 |

---

## 🔗 المسارات الأساسية للمستخدم

- `/wallet` — عرض المحفظة والرصيد والتنبيهات وسجل المعاملات
- `/wallet/feature` — اختيار إعلان للتمييز
- `/wallet/topup` — تحويل لواتساب الدعم لشحن المحفظة
- `/privacy` — سياسة الخصوصية (يجب قبولها لاستخدام الموقع)

## 🔗 المسارات الإدارية

- `/admin/wallets` — قائمة المحافظ + شحن يدوي
- `/admin/wallets/{user}/transactions` — سجل معاملات مستخدم
- `/admin/wallets-settings` — إعدادات المحفظة + نص سياسة الخصوصية
- `/admin/announcements` — إنشاء وإدارة تنبيهات المحفظة

---

## 📱 TWA (Trusted Web Activity) لمتجر Play

المشروع يعمل مع TWA مباشرة (PWA جاهز عبر `manifest.webmanifest` + خدمة عمّال). فقط:
1. تأكد من أن الموقع يعمل على HTTPS (Hostinger يوفرها مجاناً).
2. اربط `assetlinks.json` من `/public/.well-known/assetlinks.json` بمشروع أندرويد.
3. ابنِ APK/AAB باستخدام Bubblewrap CLI.

---

## 🧪 الترقية على استضافة موجودة (خطوات مختصرة)

```bash
git pull origin main
composer install --no-dev --optimize-autoloader
php artisan migrate --force
php artisan config:cache && php artisan route:cache && php artisan view:cache
```

جاهز! افتح `/admin/wallets-settings` لضبط رقم الدعم وقيم المحفظة، ثم `/admin/announcements` لإرسال تنبيهات المستخدمين.
