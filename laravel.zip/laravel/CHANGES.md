# تحديثات نسخة لارافل (يونيو 2026)

نسخة مطابقة لتطبيق "متجرك" الأصلي، مُهيّأة للاستضافة المشتركة (cPanel/Hostinger).

## دفعة الأداء + PWA الكاملة (12 يونيو 2026)

1. **دعم Offline كامل + كاش CSS/JS/خطوط:** Service Worker جديد (`/sw.js`) بإستراتيجيات متعددة:
   - HTML: NetworkFirst مع fallback إلى `/offline.html`.
   - CSS / JS / خطوط (بما فيها Tailwind CDN + Google Fonts): StaleWhileRevalidate — التطبيق لا يظهر بدون تنسيق أبدًا.
   - الصور: CacheFirst مع تقليم تلقائي.
2. **Web Push نقي (بدون Firebase):**
   - جدول `push_subscriptions` + `App\Http\Controllers\PushController` + خدمة `App\Services\WebPushSender`.
   - مفاتيح VAPID تُضاف في `.env` (`VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`).
   - لتفعيل الإرسال الفعلي على Hostinger: `composer require minishlink/web-push`.
   - الاشتراك يحدث تلقائيًا بعد أول تفاعل من المستخدم؛ الإشعار يظهر حتى لو كان التطبيق مغلقًا.
3. **نشر في الخلفية + Optimistic UI:** نموذج إنشاء الإعلان يحوّل المستخدم للرئيسية فورًا ويُكمل الرفع في الخلفية، ويظهر العنصر تحت "قيد النشر" في صفحة "حسابي" حتى ينتهي.
4. **منع الرجوع لنماذج الإنشاء/التعديل:** `history.replaceState` + اعتراض `pageshow` (BFCache) — زر "رجوع" لا يعيد المستخدم أبدًا إلى نموذج النشر.
5. **حفظ تزامني + حفظ موضع التمرير:** نموذج "الإعدادات العامة" في لوحة التحكم يحفظ عبر AJAX بدون إعادة تحميل. كل الصفحات تحفظ `scrollY` في `sessionStorage` وتسترجعه بعد أي إعادة تحميل اضطرارية.

---


## ما الجديد في هذه الدفعة

1. الأيقونة في الهيدر صارت 🛍️ بدلاً من شعار PNG.
2. وضع العمود الواحد: تصميم البطاقة مطابق لمعاينة "🛒 شاهد على متجرك" مع أزرار "أعجبني / تعليق / مشاركة / واتساب" نصية.
3. وضع العمودين: تم حذف زر الخيارات تمامًا.
4. زر الخيارات والمميز ⭐ في عمود واحد بنفس الصف (لا تراكب).
5. زر التبديل بين عمود/عمودين موجود في **الإعدادات فقط** (تمت إزالته من الرئيسية).
6. أزرار البحث + مربع البحث + الولاية في صف واحد بتصميم Pill.
7. SEO + Open Graph + JSON-LD Product في كل صفحة منشور؛ الأيقونة `favicon` صارت `logo.png` لتظهر في معاينة الرابط.
8. مشاركة المنشور تستخدم الأيقونة ➦ في كل المواضع.
9. رابط واتساب يتضمّن رابط الإعلان كاملًا + سطر جديد:
   ```
   السلام عليكم، بخصوص إعلانك:
   https://yoursite.com/posts/123
   <يكتب المستخدم رسالته>
   ```
10. صفحة تعديل المنشور تُظهر **كل الصور** الحالية + اختيار غلاف + رفع جديد.
11. صفحة الإعدادات أعيد ترتيبها كاملةً لتطابق التطبيق الرسمي.
12. تم إزالة النقطة السفلية تحت أيقونة التبويب المحدد.
13. خبير متجرك: ضبط fallback للمفتاح + رسائل خطأ أوضح + فقاعات تتقلّص حسب المحتوى.
14. ميزة الردّ على التعليقات + إرسال إشعار قابل للنقر يأخذ المستخدم إلى مكان الرد (`#cmt-N`).
15. إشعارات تلقائية عند نشر منشور جديد لكل من فعّل الإشعارات (حسب الاهتمامات أو كل المنشورات).
16. صوت تنبيه (Web Audio) عند وصول إشعار جديد + إشعارات Web Push في الـ Service Worker مع اهتزاز + رابط نقر.
17. الرسائل الجماعية صارت كاملة: عنوان، نص، رابط + نص زره، رقم واتساب + نص زره، صورة، وخيار "عرض في الرئيسية" — وتظهر في أعلى الصفحة الرئيسية فوق المميز.
18. تذكّرني: تسجيل الدخول يُحفظ تلقائيًا (`Auth::attempt(... , true)` + كوكي دائم + `SESSION_LIFETIME=525600` دقيقة = سنة كاملة).

## خطوات النشر على استضافة مشتركة

1. ارفع كامل مجلد `laravel-app/` إلى الاستضافة (مثلاً تحت `~/matjarak`).
2. وجّه الـ Document Root إلى `~/matjarak/public/`.
3. شغّل في الـ Terminal أو SSH:
   ```bash
   composer install --no-dev --optimize-autoloader
   cp .env.example .env   # عدّل بيانات قاعدة البيانات
   php artisan key:generate
   php artisan migrate --force
   php artisan storage:link
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   chmod -R 775 storage bootstrap/cache
   ```
4. تأكد من أن `public/uploads/` قابل للكتابة (`chmod 775`).
5. (اختياري) فعّل cron job يومي:
   ```
   * * * * * cd /home/USER/matjarak && php artisan schedule:run >> /dev/null 2>&1
   ```

## ملاحظات

- مفتاح Gemini للخبير: ضعه في `.env` كـ `GEMINI_API_KEY=...` أو من لوحة الإدارة → إعدادات الذكاء.
- لا يلزم Node.js إطلاقًا — Tailwind يُحمّل من CDN.
- الـ Service Worker `/sw.js` يفعّل الإشعارات والصوت تلقائيًا.

## Update 2026-06-09 — Major UX/Backend overhaul

### New
- **Migration** `2026_06_09_000001_search_and_ratings.php`: adds `search_queries` (analytics) + `seller_ratings` (1 rating per (seller,rater)).
- Models: `SearchQuery`, `SellerRating`.
- Route: `POST /sellers/{user}/rate` (one-time star rating).
- Admin route: `/admin/search-trends` — top queries + recent.

### Service Worker (sw.js v3)
- Notifications now use device default sound (no custom asset), `requireInteraction: true` keeps them in the status bar, tap navigates to `data.url`.

### Post detail page (`posts/show.blade.php`)
- Gallery with left/right arrows, dot indicators, page counter, click-to-expand lightbox.
- Replaced URL block with 4 info cards (الولاية/المدينة/القسم/الحالة) in a 2-col grid.
- Action bar: like/save/share each `flex-1`, fully AJAX (no reload), share uses Native Share Sheet → clipboard fallback with toast.
- Seller card with 5-star rating (read-only once submitted).
- Sticky WhatsApp CTA pinned above the bottom-nav.
- Recommendations carousel "✨ اقتراحات لك" pulls related posts by category/state.

### Home page (`home.blade.php`)
- **PWA install prompt** shown first, persistent, listens to `beforeinstallprompt` + `appinstalled`. Fallback "كيفية التثبيت" instructions for Safari/blocked browsers.
- **Broadcast queue**: only one message visible at a time, dismissed IDs stored in `localStorage`, smooth fade between cards. Renders link, WhatsApp, and image buttons dynamically.
- Search submissions are logged via `HomeController` for admin analytics.

### Admin categories (`admin/categories.blade.php`)
- Full list view (1 card per row), iOS-style toggle switch, 6-dot drag handle, inline order input, color-coded "Add new" panels.

### Gemini Expert (`ExpertController`)
- Detailed per-status logging: 401/403/429/400/timeouts all log status + body snippet to `storage/logs/laravel.log`.
- Uses `x-goog-api-key` header instead of query string.
- In `APP_DEBUG=true`, the JSON error response includes `debug` payload to the frontend console.

### How to deploy
1. Upload changed files.
2. `php artisan migrate --force`
3. `php artisan config:clear && php artisan view:clear`

## Update 2026-06-11 — Major cleanup + features

### Removed
- All AI/Expert features stripped: `ExpertController`, `ExpertChat` model, `expert/chat.blade.php`, `admin/ai_settings.blade.php`, AI admin routes/methods, dashboard AI link, AI keys from `.env.example`.
- "Settings" button removed from main header.
- "Settings" and "WhatsApp" shortcuts removed from My Account page.

### Auth
- `SESSION_LIFETIME=43200` (30 days) and `SESSION_EXPIRE_ON_CLOSE=false` in `.env.example`.
- Login always uses `remember=true`; recall cookie extended via `cookie()->forever()`.
- Google OAuth added (no extra package): `/auth/google` + `/auth/google/callback`. Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI` in `.env`.
- Arabic auth + validation messages: `lang/ar/auth.php`, `lang/ar/validation.php`.
- Granular profile field updates via `PATCH /profile/field` (AJAX): name, email, state, bio, password — each saves independently.

### Posts
- All post creation fields strictly required: title, description (min 10), price, currency, category, state, city, condition, whatsapp, ≥1 image.
- Phone is optional, WhatsApp is mandatory.
- New optional video upload (≤5MB, MP4/WebM/MOV). New column `video_url` on posts (migration added).
- Post edit now redirects with 303 → back button after save goes to post, not edit form.

### Admin
- 3-dot menu on every post card (grid + single mode) — visible to owner + admin/mod with Edit / Delete / ⭐ Featured.
- `admin/posts.blade.php` redesigned: card-per-post with action buttons in clean columns (Featured, Activate, Hide, Ban, Edit, Delete) all in Arabic.
- Category emojis auto-assigned (migration backfills nulls; seeder uses defaults).

### UX
- Smooth page transitions via `@view-transition` + main fade-in animation.
- Interactive PWA install banner already wired via `beforeinstallprompt`.
- SEO meta (title, description, OG, Twitter card) already in `layouts/app.blade.php`.

### Run after deploy
```
php artisan migrate --force
php artisan config:clear && php artisan view:clear && php artisan route:clear
```
