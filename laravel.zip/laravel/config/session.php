<?php

return [
    'driver' => env('SESSION_DRIVER', 'file'),
    // 1 year (in minutes) — extended for long-term auto-login like Google.
    'lifetime' => (int) env('SESSION_LIFETIME', 525600),
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => storage_path('framework/sessions'),
    'connection' => env('SESSION_CONNECTION'),
    'table' => 'sessions',
    'store' => env('SESSION_STORE'),
    // Reduce GC sweep frequency so file-based sessions on shared hosting
    // are not deleted prematurely (remember-me cookie also kept long-lived).
    'lottery' => [1, 1000],
    'cookie' => env('SESSION_COOKIE', 'matjarak_session'),
    'path' => '/',
    'domain' => env('SESSION_DOMAIN'),
    'secure' => env('SESSION_SECURE_COOKIE'),
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
];
