<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\UserRole;
use App\Models\Post;
use App\Models\Category;
use App\Models\StateModel;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 19 Sudanese categories with default emojis
        $cats = [
            'إلكترونيات'=>'📱','سيارات'=>'🚗','عقارات'=>'🏠','أزياء'=>'👗','أثاث'=>'🛋',
            'وظائف'=>'💼','خدمات'=>'🛠','مواشي'=>'🐄','زراعة'=>'🌾','هواتف'=>'📞',
            'كمبيوترات'=>'💻','رياضة'=>'⚽','كتب'=>'📚','أطفال'=>'🧸','جمال'=>'💄',
            'طعام'=>'🍽','حرف يدوية'=>'🎨','مستعمل'=>'♻','أخرى'=>'🛍',
        ];
        $i = 0;
        foreach ($cats as $name => $icon) {
            Category::create(['name' => $name, 'slug' => Str::slug($name) ?: 'cat-'.$i, 'icon' => $icon, 'sort_order' => $i]);
            $i++;
        }
        // 18 Sudanese states
        $states = ['الخرطوم','الجزيرة','كسلا','البحر الأحمر','القضارف','سنار','النيل الأبيض','النيل الأزرق','نهر النيل',
                   'الشمالية','شمال كردفان','جنوب كردفان','غرب كردفان','شمال دارفور','جنوب دارفور','شرق دارفور','وسط دارفور','غرب دارفور'];
        foreach ($states as $i => $name) StateModel::create(['name' => $name, 'sort_order' => $i]);

        $admin = User::create([
            'username' => 'admin',
            'full_name' => 'مدير النظام',
            'phone' => '+249900000000',
            'password' => 'admin1234',
        ]);
        UserRole::create(['user_id' => $admin->id, 'role' => 'admin']);
        UserRole::create(['user_id' => $admin->id, 'role' => 'user']);

        $seller = User::create([
            'username' => 'seller1',
            'full_name' => 'تاجر تجريبي',
            'phone' => '+249911111111',
            'password' => 'pass1234',
            'state' => 'الخرطوم',
        ]);
        UserRole::create(['user_id' => $seller->id, 'role' => 'seller']);
        UserRole::create(['user_id' => $seller->id, 'role' => 'user']);

        foreach (['هاتف سامسونج', 'لابتوب HP', 'سيارة تويوتا'] as $i => $title) {
            Post::create([
                'user_id' => $seller->id,
                'title' => $title,
                'description' => 'وصف تجريبي للإعلان: ' . $title,
                'price' => ($i+1) * 50000,
                'currency' => 'SDG',
                'category' => ['إلكترونيات','إلكترونيات','سيارات'][$i],
                'state' => 'الخرطوم',
                'city' => 'بحري',
                'phone' => '+249911111111',
                'whatsapp' => '+249911111111',
                'images' => ['/assets/placeholder.svg'],
                'featured' => $i === 0,
            ]);
        }
    }
}
