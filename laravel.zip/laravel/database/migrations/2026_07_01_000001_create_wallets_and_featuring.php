<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wallets', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $t->decimal('balance', 14, 2)->default(0);
            $t->string('currency', 8)->default('SDG');
            $t->timestamps();
        });

        Schema::create('wallet_transactions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('wallet_id')->constrained('wallets')->cascadeOnDelete();
            $t->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $t->enum('type', ['credit', 'debit']);
            $t->decimal('amount', 14, 2);
            $t->string('reason', 40)->index(); // signup_bonus, admin_topup, feature_post, refund
            $t->unsignedBigInteger('reference_id')->nullable();
            $t->json('meta')->nullable();
            $t->string('note', 255)->nullable();
            $t->timestamps();
            $t->index(['user_id', 'reason']);
        });

        if (!Schema::hasColumn('posts', 'featured_until')) {
            Schema::table('posts', function (Blueprint $t) {
                $t->timestamp('featured_until')->nullable()->after('featured')->index();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('posts', 'featured_until')) {
            Schema::table('posts', function (Blueprint $t) {
                $t->dropColumn('featured_until');
            });
        }
        Schema::dropIfExists('wallet_transactions');
        Schema::dropIfExists('wallets');
    }
};
