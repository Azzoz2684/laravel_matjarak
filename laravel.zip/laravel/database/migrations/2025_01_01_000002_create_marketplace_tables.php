<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('posts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('title', 200);
            $t->text('description')->nullable();
            $t->decimal('price', 12, 2)->default(0);
            $t->string('currency', 10)->default('SDG');
            $t->string('category', 50)->index();
            $t->string('state', 50)->index();
            $t->string('city', 100)->nullable();
            $t->json('images')->nullable();
            $t->string('phone', 20)->nullable();
            $t->string('whatsapp', 20)->nullable();
            $t->enum('status', ['active','hidden','banned','pending'])->default('active')->index();
            $t->boolean('featured')->default(false)->index();
            $t->decimal('latitude', 10, 7)->nullable();
            $t->decimal('longitude', 10, 7)->nullable();
            $t->string('condition', 20)->nullable();
            $t->unsignedInteger('views_count')->default(0);
            $t->timestamps();
        });

        Schema::create('likes', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->timestamps();
            $t->unique(['user_id', 'post_id']);
        });

        Schema::create('saves', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->timestamps();
            $t->unique(['user_id', 'post_id']);
        });

        Schema::create('comments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->text('body');
            $t->timestamps();
        });

        Schema::create('not_interested', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->timestamps();
            $t->unique(['user_id', 'post_id']);
        });

        Schema::create('reports', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('post_id')->constrained()->cascadeOnDelete();
            $t->string('reason', 500);
            $t->enum('status', ['pending','reviewed','dismissed'])->default('pending')->index();
            $t->string('action_reason', 500)->nullable();
            $t->unsignedBigInteger('acted_by')->nullable();
            $t->timestamp('acted_at')->nullable();
            $t->timestamps();
        });

        Schema::create('notifications', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('title', 150);
            $t->string('body', 500)->nullable();
            $t->unsignedBigInteger('post_id')->nullable();
            $t->boolean('is_read')->default(false)->index();
            $t->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('reports');
        Schema::dropIfExists('not_interested');
        Schema::dropIfExists('comments');
        Schema::dropIfExists('saves');
        Schema::dropIfExists('likes');
        Schema::dropIfExists('posts');
    }
};
