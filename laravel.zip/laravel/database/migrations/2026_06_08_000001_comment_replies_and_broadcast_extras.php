<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('comments', function (Blueprint $t) {
            if (!Schema::hasColumn('comments', 'parent_id')) {
                $t->unsignedBigInteger('parent_id')->nullable()->after('post_id')->index();
            }
        });
        Schema::table('notifications', function (Blueprint $t) {
            if (!Schema::hasColumn('notifications', 'link')) {
                $t->string('link', 500)->nullable()->after('body');
            }
            if (!Schema::hasColumn('notifications', 'type')) {
                $t->string('type', 40)->nullable()->after('link')->index();
            }
        });
        Schema::table('broadcasts', function (Blueprint $t) {
            if (!Schema::hasColumn('broadcasts', 'link')) {
                $t->string('link', 500)->nullable()->after('body');
            }
            if (!Schema::hasColumn('broadcasts', 'link_text')) {
                $t->string('link_text', 80)->nullable()->after('link');
            }
            if (!Schema::hasColumn('broadcasts', 'contact_phone')) {
                $t->string('contact_phone', 30)->nullable()->after('link_text');
            }
            if (!Schema::hasColumn('broadcasts', 'contact_text')) {
                $t->string('contact_text', 80)->nullable()->after('contact_phone');
            }
            if (!Schema::hasColumn('broadcasts', 'image_url')) {
                $t->string('image_url', 500)->nullable()->after('contact_text');
            }
            if (!Schema::hasColumn('broadcasts', 'is_active')) {
                $t->boolean('is_active')->default(true)->index()->after('image_url');
            }
        });
    }
    public function down(): void {
        Schema::table('comments', fn(Blueprint $t) => $t->dropColumn('parent_id'));
        Schema::table('notifications', fn(Blueprint $t) => $t->dropColumn(['link','type']));
        Schema::table('broadcasts', fn(Blueprint $t) => $t->dropColumn(['link','link_text','contact_phone','contact_text','image_url','is_active']));
    }
};
