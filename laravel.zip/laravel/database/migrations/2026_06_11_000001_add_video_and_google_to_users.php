<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasColumn('posts', 'video_url')) {
            Schema::table('posts', function (Blueprint $t) {
                $t->string('video_url', 255)->nullable()->after('images');
            });
        }
        if (!Schema::hasColumn('users', 'google_id')) {
            Schema::table('users', function (Blueprint $t) {
                $t->string('google_id', 64)->nullable()->unique();
                $t->string('email', 191)->nullable()->index()->change();
                $t->string('avatar_url', 500)->nullable()->change();
            });
        }
        // Backfill default category emojis if missing
        $defaults = [
            'إلكترونيات'=>'📱','سيارات'=>'🚗','عقارات'=>'🏠','أزياء'=>'👗','أثاث'=>'🛋',
            'وظائف'=>'💼','خدمات'=>'🛠','مواشي'=>'🐄','زراعة'=>'🌾','هواتف'=>'📞',
            'كمبيوترات'=>'💻','رياضة'=>'⚽','كتب'=>'📚','أطفال'=>'🧸','جمال'=>'💄',
            'طعام'=>'🍽','حرف يدوية'=>'🎨','مستعمل'=>'♻','أخرى'=>'🛍',
        ];
        if (Schema::hasTable('categories')) {
            foreach ($defaults as $name => $icon) {
                \DB::table('categories')->where('name', $name)->whereNull('icon')->update(['icon' => $icon]);
                \DB::table('categories')->where('name', $name)->where('icon', '')->update(['icon' => $icon]);
            }
        }
    }
    public function down(): void {
        if (Schema::hasColumn('posts', 'video_url')) {
            Schema::table('posts', fn(Blueprint $t) => $t->dropColumn('video_url'));
        }
        if (Schema::hasColumn('users', 'google_id')) {
            Schema::table('users', fn(Blueprint $t) => $t->dropColumn('google_id'));
        }
    }
};
