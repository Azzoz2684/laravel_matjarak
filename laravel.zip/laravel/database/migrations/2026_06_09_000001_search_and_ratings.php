<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('search_queries')) {
            Schema::create('search_queries', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('user_id')->nullable()->index();
                $t->string('query', 200)->index();
                $t->string('category', 80)->nullable();
                $t->string('state', 80)->nullable();
                $t->unsignedInteger('results_count')->default(0);
                $t->string('ip', 45)->nullable();
                $t->timestamps();
            });
        }
        if (!Schema::hasTable('seller_ratings')) {
            Schema::create('seller_ratings', function (Blueprint $t) {
                $t->id();
                $t->unsignedBigInteger('seller_id')->index();
                $t->unsignedBigInteger('rater_id')->index();
                $t->unsignedTinyInteger('stars');
                $t->string('comment', 300)->nullable();
                $t->timestamps();
                $t->unique(['seller_id', 'rater_id']);
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('search_queries');
        Schema::dropIfExists('seller_ratings');
    }
};
