<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->string('name', 80)->unique();
            $t->string('slug', 80)->unique();
            $t->string('icon', 30)->nullable();
            $t->unsignedInteger('sort_order')->default(0)->index();
            $t->boolean('is_active')->default(true)->index();
            $t->timestamps();
        });

        Schema::create('states', function (Blueprint $t) {
            $t->id();
            $t->string('name', 80)->unique();
            $t->unsignedInteger('sort_order')->default(0)->index();
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });

        Schema::table('users', function (Blueprint $t) {
            $t->boolean('notify_enabled')->default(true);
            // 'all' = all notifications, 'interests' = only related to followed categories/posts
            $t->enum('notify_scope', ['all', 'interests'])->default('all');
            $t->json('interest_categories')->nullable();
            $t->timestamp('last_daily_notified_at')->nullable();
        });

        Schema::create('expert_chat_logs', function (Blueprint $t) {
            // ephemeral usage log only (no message content), for rate limiting
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->unsignedInteger('tokens_used')->default(0);
            $t->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('expert_chat_logs');
        Schema::table('users', function (Blueprint $t) {
            $t->dropColumn(['notify_enabled', 'notify_scope', 'interest_categories', 'last_daily_notified_at']);
        });
        Schema::dropIfExists('states');
        Schema::dropIfExists('categories');
    }
};
