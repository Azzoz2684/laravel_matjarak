<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('expert_chats', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('role', ['user', 'assistant']);
            $t->text('content');
            $t->timestamps();
            $t->index(['user_id', 'created_at']);
        });
    }
    public function down(): void {
        Schema::dropIfExists('expert_chats');
    }
};
