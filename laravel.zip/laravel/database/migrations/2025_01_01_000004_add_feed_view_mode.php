<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('users', function (Blueprint $t) {
            $t->enum('feed_view_mode', ['grid','single'])->default('grid')->after('interest_categories');
        });
    }
    public function down(): void {
        Schema::table('users', function (Blueprint $t) { $t->dropColumn('feed_view_mode'); });
    }
};
