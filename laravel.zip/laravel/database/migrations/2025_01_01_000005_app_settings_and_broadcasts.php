<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void {
        Schema::create('app_settings', function (Blueprint $t) {
            $t->id();
            $t->string('key', 80)->unique();
            $t->text('value')->nullable();
            $t->timestamps();
        });

        $defaults = [
            'gemini_api_key'   => env('GEMINI_API_KEY', 'AQ.Ab8RN6I-HKNT7JvRqS847yEEOG-6Sa7WMwRKBdXUIR6axlLErA'),
            'gemini_model'     => env('GEMINI_MODEL', 'gemini-1.5-flash'),
            'ai_system_prompt' => 'أنت خبير متجرك، مساعد ذكي للسوق السوداني، تتحدث باللهجة السودانية البسيطة، قصير ومباشر. ساعد المستخدم في تسعير المنتجات وكتابة الإعلانات وتسويقها.',
            'ai_temperature'   => '0.7',
            'ai_max_tokens'    => '800',
            'support_whatsapp' => '+249900000000',
            'app_name'         => 'متجرك',
        ];
        foreach ($defaults as $k => $v) {
            DB::table('app_settings')->insert(['key'=>$k,'value'=>$v,'created_at'=>now(),'updated_at'=>now()]);
        }

        // Broadcasts (mass messages)
        Schema::create('broadcasts', function (Blueprint $t) {
            $t->id();
            $t->string('title', 150);
            $t->text('body');
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->unsignedInteger('recipients_count')->default(0);
            $t->timestamps();
        });

        // Add 'is_important' flag context — like already represents importance now.
        // No schema change needed; we treat likes as "important" semantically.
    }

    public function down(): void {
        Schema::dropIfExists('broadcasts');
        Schema::dropIfExists('app_settings');
    }
};
