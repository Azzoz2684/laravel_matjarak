<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('push_subscriptions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->text('endpoint');
            $t->string('p256dh', 255);
            $t->string('auth', 255);
            $t->string('ua', 255)->nullable();
            $t->timestamps();
            $t->unique(['user_id', 'endpoint'], 'push_user_endpoint_unique');
        });
    }
    public function down(): void { Schema::dropIfExists('push_subscriptions'); }
};
