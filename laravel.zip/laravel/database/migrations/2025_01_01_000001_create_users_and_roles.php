<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('users', function (Blueprint $t) {
            $t->id();
            $t->string('username', 50)->unique();
            $t->string('full_name', 100)->nullable();
            $t->string('phone', 20)->unique();
            $t->string('email')->nullable()->unique();
            $t->timestamp('email_verified_at')->nullable();
            $t->string('password');
            $t->string('avatar_url')->nullable();
            $t->string('state', 50)->nullable();
            $t->text('bio')->nullable();
            $t->rememberToken();
            $t->timestamps();
        });

        Schema::create('user_roles', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('role', ['user','seller','admin'])->default('user');
            $t->timestamps();
            $t->unique(['user_id', 'role']);
        });

        Schema::create('password_reset_tokens', function (Blueprint $t) {
            $t->string('email')->primary();
            $t->string('token');
            $t->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $t) {
            $t->string('id')->primary();
            $t->foreignId('user_id')->nullable()->index();
            $t->string('ip_address', 45)->nullable();
            $t->text('user_agent')->nullable();
            $t->longText('payload');
            $t->integer('last_activity')->index();
        });
    }

    public function down(): void {
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('user_roles');
        Schema::dropIfExists('users');
    }
};
