<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wallet_announcements', function (Blueprint $t) {
            $t->id();
            $t->string('title', 200);
            $t->text('body');
            $t->enum('level', ['info', 'success', 'warning', 'danger'])->default('info');
            $t->boolean('is_active')->default(true);
            $t->timestamp('starts_at')->nullable();
            $t->timestamp('ends_at')->nullable();
            $t->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $t->timestamps();
            $t->index(['is_active', 'starts_at', 'ends_at']);
        });

        Schema::create('wallet_announcement_dismissals', function (Blueprint $t) {
            $t->id();
            $t->foreignId('announcement_id')->constrained('wallet_announcements')->cascadeOnDelete();
            $t->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $t->timestamp('dismissed_at')->useCurrent();
            $t->unique(['announcement_id', 'user_id']);
        });

        Schema::table('users', function (Blueprint $t) {
            if (!Schema::hasColumn('users', 'privacy_accepted_at')) {
                $t->timestamp('privacy_accepted_at')->nullable();
            }
            if (!Schema::hasColumn('users', 'privacy_version')) {
                $t->string('privacy_version', 20)->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            if (Schema::hasColumn('users', 'privacy_accepted_at')) $t->dropColumn('privacy_accepted_at');
            if (Schema::hasColumn('users', 'privacy_version')) $t->dropColumn('privacy_version');
        });
        Schema::dropIfExists('wallet_announcement_dismissals');
        Schema::dropIfExists('wallet_announcements');
    }
};
