/*
 * Background Sync client helper — متجرك
 * ---------------------------------------------------------------
 * يلتقط نموذج إنشاء الإعلان (#postForm أو [data-bgsync-form])
 * ويضع الطلب في IndexedDB ثم يطلب من Service Worker تنفيذ
 * Background Sync. بهذا تنتهي عملية النشر فوراً من واجهة المستخدم
 * ويتم الرفع الفعلي للخادم في الخلفية حتى بعد إغلاق التطبيق.
 *
 * الاستخدام في Blade:
 *   <form id="postForm" data-bgsync-form action="{{ route('posts.store') }}" ...>
 *   <script src="/assets/bgsync-client.js" defer></script>
 */
(function () {
    'use strict';

    const IDB_NAME = 'matjarak-bgsync';
    const IDB_STORE = 'queue';
    const SYNC_TAG = 'matjarak-post-queue';

    function idbOpen() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(IDB_NAME, 1);
            req.onupgradeneeded = () => {
                const db = req.result;
                if (!db.objectStoreNames.contains(IDB_STORE)) {
                    db.createObjectStore(IDB_STORE, { keyPath: 'id', autoIncrement: true });
                }
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror   = () => reject(req.error);
        });
    }
    async function idbAdd(item) {
        const db = await idbOpen();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(IDB_STORE, 'readwrite');
            const req = tx.objectStore(IDB_STORE).add(item);
            req.onsuccess = () => resolve(req.result);
            req.onerror   = () => reject(req.error);
        });
    }

    function uuid() {
        try { if (crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    async function formToQueueItem(form) {
        const fd = new FormData(form);
        const fields = [];
        for (const [name, value] of fd.entries()) {
            if (value instanceof File) {
                if (value.size === 0 && !value.name) continue;
                fields.push({ kind: 'file', name, filename: value.name, blob: value });
            } else {
                fields.push({ kind: 'text', name, value: String(value) });
            }
        }
        // Idempotency key — protects against double-submit (sync + manual replay)
        fields.push({ kind: 'text', name: 'idempotency_key', value: uuid() });
        const csrf = (document.querySelector('meta[name="csrf-token"]') || {}).content || null;
        const title = (form.querySelector('[name="title"]') || {}).value || '';
        return {
            url: form.getAttribute('action'),
            method: (form.getAttribute('method') || 'POST').toUpperCase(),
            csrf, title, fields,
            createdAt: Date.now(),
        };
    }

    async function registerSync() {
        try {
            const reg = await navigator.serviceWorker.ready;
            if ('sync' in reg) {
                await reg.sync.register(SYNC_TAG);
                return true;
            }
        } catch (e) { /* ignored */ }
        // Fallback: ask the SW to replay now (will retry next page load if offline)
        try {
            const reg = await navigator.serviceWorker.ready;
            if (reg.active) reg.active.postMessage({ type: 'REPLAY_QUEUE' });
        } catch (e) {}
        return false;
    }

    function toast(msg) {
        try {
            const el = document.createElement('div');
            el.textContent = msg;
            el.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#10b981;color:#fff;padding:10px 18px;border-radius:999px;z-index:99999;font-family:Cairo,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.2);';
            document.body.appendChild(el);
            setTimeout(() => el.remove(), 3500);
        } catch (e) {}
    }

    async function handleSubmit(e) {
        const form = e.target;
        if (!form.matches('#postForm, [data-bgsync-form]')) return;
        if (!('serviceWorker' in navigator) || !('indexedDB' in window)) return; // fall back to native submit
        e.preventDefault();
        try {
            const item = await formToQueueItem(form);
            await idbAdd(item);
            await registerSync();
            toast('تم استلام إعلانك ✅ سيتم رفعه في الخلفية');
            // Try one immediate online attempt for instant UX
            try {
                if (navigator.onLine) {
                    const reg = await navigator.serviceWorker.ready;
                    if (reg.active) reg.active.postMessage({ type: 'REPLAY_QUEUE' });
                }
            } catch (er) {}
            // Move user back to home so they see the queue clear when it's done
            setTimeout(() => { window.location.href = '/'; }, 400);
        } catch (err) {
            console.warn('bgsync enqueue failed, falling back to direct submit', err);
            form.submit();
        }
    }

    // Listen for SW completion messages so UI can refresh
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', (e) => {
            if (!e.data) return;
            if (e.data.type === 'BGSYNC_DONE' && e.data.ok) {
                window.dispatchEvent(new CustomEvent('matjarak:post-published', { detail: e.data }));
            }
            if (e.data.type === 'PUSH_RECEIVED') {
                window.dispatchEvent(new CustomEvent('matjarak:push', { detail: e.data.payload }));
            }
        });
    }

    document.addEventListener('submit', handleSubmit, true);

    // Best-effort: trigger a replay every time the page loads while online
    window.addEventListener('load', () => {
        if (!('serviceWorker' in navigator)) return;
        navigator.serviceWorker.ready.then((reg) => {
            if (reg.active) reg.active.postMessage({ type: 'REPLAY_QUEUE' });
        }).catch(() => {});
    });
    window.addEventListener('online', () => {
        if (!('serviceWorker' in navigator)) return;
        navigator.serviceWorker.ready.then((reg) => {
            if (reg.active) reg.active.postMessage({ type: 'REPLAY_QUEUE' });
        }).catch(() => {});
    });
})();
