// متجرك Service Worker — Offline-first + Background Sync + Web Push (no Firebase)
const VERSION   = 'matjarak-v10';
const SHELL     = 'matjarak-shell-v10';   // HTML pages (NetworkFirst)
const STATIC_C  = 'matjarak-static-v10';  // CSS/JS/Fonts (StaleWhileRevalidate)
const IMG_C     = 'matjarak-img-v10';     // images (CacheFirst, capped)
const FONT_HOSTS = ['fonts.googleapis.com', 'fonts.gstatic.com', 'cdn.tailwindcss.com'];
const OFFLINE_URL = '/offline.html';

const PRECACHE = [
    '/', OFFLINE_URL, '/manifest.webmanifest', '/assets/logo.png',
    'https://cdn.tailwindcss.com',
    'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap',
];

// ===== IndexedDB helpers (queue of pending POSTs) =====
const IDB_NAME = 'matjarak-bgsync';
const IDB_STORE = 'queue';

function idbOpen() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(IDB_NAME, 1);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(IDB_STORE)) {
                db.createObjectStore(IDB_STORE, { keyPath: 'id', autoIncrement: true });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror   = () => reject(req.error);
    });
}
async function idbAll() {
    const db = await idbOpen();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(IDB_STORE, 'readonly');
        const req = tx.objectStore(IDB_STORE).getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror   = () => reject(req.error);
    });
}
async function idbDelete(id) {
    const db = await idbOpen();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).delete(id);
        tx.oncomplete = () => resolve();
        tx.onerror    = () => reject(tx.error);
    });
}

self.addEventListener('install', e => {
    e.waitUntil((async () => {
        const c = await caches.open(STATIC_C);
        await Promise.allSettled(PRECACHE.map(u => c.add(new Request(u, { mode: 'no-cors' }))));
        self.skipWaiting();
    })());
});

self.addEventListener('activate', e => {
    e.waitUntil((async () => {
        const keys = await caches.keys();
        await Promise.all(keys.filter(k => ![SHELL, STATIC_C, IMG_C].includes(k)).map(k => caches.delete(k)));
        await self.clients.claim();
    })());
});

async function trim(cacheName, max) {
    const c = await caches.open(cacheName);
    const keys = await c.keys();
    if (keys.length > max) for (const k of keys.slice(0, keys.length - max)) await c.delete(k);
}

self.addEventListener('fetch', event => {
    const req = event.request;
    if (req.method !== 'GET') return;
    const url = new URL(req.url);

    // 1) HTML navigations: NetworkFirst → cache → offline page
    if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
        event.respondWith((async () => {
            try {
                const fresh = await fetch(req);
                const c = await caches.open(SHELL);
                c.put(req, fresh.clone()).catch(()=>{});
                return fresh;
            } catch (_) {
                const cached = await caches.match(req);
                return cached || (await caches.match(OFFLINE_URL)) || new Response('Offline', { status: 503 });
            }
        })());
        return;
    }

    // 2) CSS/JS/Fonts: StaleWhileRevalidate
    const isFontCdn = FONT_HOSTS.includes(url.host);
    const isStatic = url.origin === self.location.origin && (
        url.pathname.endsWith('.css') || url.pathname.endsWith('.js') ||
        url.pathname.endsWith('.svg') || url.pathname.match(/\.(woff2?|ttf|otf|eot)$/)
    );
    if (isFontCdn || isStatic) {
        event.respondWith((async () => {
            const c = await caches.open(STATIC_C);
            const cached = await c.match(req);
            const networkPromise = fetch(req).then(r => { c.put(req, r.clone()).catch(()=>{}); return r; }).catch(() => null);
            return cached || (await networkPromise) || new Response('', { status: 504 });
        })());
        return;
    }

    // 3) Images / uploads: CacheFirst (trim to 120 entries)
    if (url.origin === self.location.origin && (url.pathname.startsWith('/uploads/') || url.pathname.startsWith('/assets/') ||
        url.pathname.match(/\.(png|jpe?g|webp|gif|avif)$/))) {
        event.respondWith((async () => {
            const c = await caches.open(IMG_C);
            const cached = await c.match(req);
            if (cached) return cached;
            try {
                const r = await fetch(req);
                c.put(req, r.clone()).catch(()=>{});
                trim(IMG_C, 120);
                return r;
            } catch { return cached || new Response('', { status: 504 }); }
        })());
    }
});

// ===== Messages from the page (enqueue post + manual replay trigger) =====
self.addEventListener('message', async (e) => {
    if (e.data === 'SKIP_WAITING') { self.skipWaiting(); return; }
    if (e.data && e.data.type === 'REPLAY_QUEUE') {
        e.waitUntil ? e.waitUntil(replayQueuedPosts()) : replayQueuedPosts();
        return;
    }
});

// ===== Background Sync: replay queued POSTs in the background =====
self.addEventListener('sync', event => {
    if (event.tag === 'matjarak-post-queue') {
        event.waitUntil(replayQueuedPosts());
    }
});

// Some browsers (mainly Chrome) periodic sync — fallback safety net
self.addEventListener('periodicsync', event => {
    if (event.tag === 'matjarak-post-queue') {
        event.waitUntil(replayQueuedPosts());
    }
});

async function notifyClients(payload) {
    const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of list) { try { c.postMessage(payload); } catch (e) {} }
}

async function rebuildFormData(item) {
    const fd = new FormData();
    for (const part of item.fields) {
        if (part.kind === 'file' && part.blob) {
            fd.append(part.name, part.blob, part.filename || 'upload');
        } else {
            fd.append(part.name, part.value ?? '');
        }
    }
    return fd;
}

// Lock to prevent the same queued item being sent twice when both
// `sync` and `REPLAY_QUEUE` fire concurrently (root cause of duplicate posts).
const _inFlight = new Set();
let _replayRunning = false;

async function replayQueuedPosts() {
    if (_replayRunning) return;
    _replayRunning = true;
    try {
        const items = await idbAll();
        if (!items.length) return;
        for (const item of items) {
            if (_inFlight.has(item.id)) continue;
            _inFlight.add(item.id);
            try {
                const fd = await rebuildFormData(item);
                const headers = { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' };
                if (item.csrf) headers['X-CSRF-TOKEN'] = item.csrf;
                const res = await fetch(item.url, {
                    method: item.method || 'POST',
                    body: fd,
                    credentials: 'include',
                    headers,
                });
                if (res.ok || res.status === 201 || res.status === 303) {
                    await idbDelete(item.id);
                    await notifyClients({ type: 'BGSYNC_DONE', id: item.id, ok: true, status: res.status });
                    try {
                        await self.registration.showNotification('تم نشر إعلانك ✅', {
                            body: item.title || 'تم رفع المنشور بنجاح',
                            icon: '/assets/logo.png',
                            badge: '/assets/logo.png',
                            tag: 'bgsync-' + item.id,
                            data: { url: '/' },
                        });
                    } catch (e) {}
                } else {
                    // Server rejected — drop to avoid endless retry loops
                    await idbDelete(item.id);
                    await notifyClients({ type: 'BGSYNC_DONE', id: item.id, ok: false, status: res.status });
                }
            } catch (err) {
                // Network failure — leave item in queue for the next sync event
                await notifyClients({ type: 'BGSYNC_RETRY', id: item.id, error: String(err) });
                throw err; // tell the browser to retry the sync
            } finally {
                _inFlight.delete(item.id);
            }
        }
    } finally {
        _replayRunning = false;
    }
}

// ===== Web Push (pure Web Push protocol — no Firebase) =====
self.addEventListener('push', event => {
    let data = {};
    try { data = event.data ? event.data.json() : {}; }
    catch (e) {
        try { data = { title: 'متجرك', body: event.data ? event.data.text() : '' }; }
        catch { data = { title: 'متجرك', body: '' }; }
    }
    const title = data.title || 'متجرك';
    const options = {
        body: data.body || '',
        icon: data.icon || '/assets/logo.png',
        badge: data.badge || '/assets/logo.png',
        image: data.image || undefined,
        tag: data.tag || ('matjarak-' + Date.now()),
        renotify: true,
        requireInteraction: true,
        silent: false,
        vibrate: data.vibrate || [120, 60, 120],
        timestamp: Date.now(),
        data: { url: data.url || data.link || '/notifications' },
    };
    event.waitUntil((async () => {
        await self.registration.showNotification(title, options);
        // Wake any open client so the home feed / badge refreshes immediately
        await notifyClients({ type: 'PUSH_RECEIVED', payload: data });
    })());
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    const url = (event.notification.data && event.notification.data.url) || '/';
    event.waitUntil((async () => {
        const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
        for (const c of list) {
            try { await c.navigate(url); return c.focus(); } catch (e) {}
        }
        if (self.clients.openWindow) return self.clients.openWindow(url);
    })());
});
