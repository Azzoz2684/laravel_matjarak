@extends('layouts.app')
@section('title', 'اختر إعلاناً للتمييز')
@section('content')
<div class="max-w-3xl mx-auto">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-bold">✨ اختر إعلاناً لتمييزه</h1>
        <a href="{{ route('wallet.show') }}" class="text-sm text-primary">‹ رجوع للمحفظة</a>
    </div>

    @if($posts->isEmpty())
        <div class="bg-white dark:bg-gray-800 p-8 rounded-xl text-center text-gray-500 shadow">
            لا يوجد لديك إعلانات قابلة للتمييز حالياً. انشر إعلاناً أولاً.
            <div class="mt-3">
                <a href="{{ route('posts.create') }}" class="inline-block bg-primary text-white px-4 py-2 rounded-lg">+ إعلان جديد</a>
            </div>
        </div>
    @else
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            @foreach($posts as $post)
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
                    <img src="{{ $post->firstImage() }}" alt="" class="w-full h-36 object-cover">
                    <div class="p-3">
                        <div class="font-bold truncate">{{ $post->title }}</div>
                        <div class="text-xs text-gray-500 mt-1">{{ $post->priceArabic() }}</div>
                        <a href="{{ route('wallet.feature.confirm', $post) }}"
                           class="mt-3 block text-center bg-primary text-white font-semibold py-2 rounded-lg">
                            اختر هذا الإعلان
                        </a>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="mt-4">{{ $posts->links() }}</div>
    @endif
</div>
@endsection
