@extends('layouts.app')
@section('title', 'تأكيد تمييز الإعلان')
@section('content')
<div class="max-w-lg mx-auto">
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow overflow-hidden">
        <img src="{{ $post->firstImage() }}" class="w-full h-48 object-cover">
        <div class="p-5 space-y-3">
            <h1 class="text-lg font-bold">{{ $post->title }}</h1>

            <div class="grid grid-cols-2 gap-3 text-sm">
                <div class="bg-gray-50 dark:bg-gray-700/40 p-3 rounded-lg">
                    <div class="text-gray-500 text-xs">تكلفة التمييز</div>
                    <div class="font-bold">{{ number_format($cost, 2) }} {{ $wallet->currency }}</div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-700/40 p-3 rounded-lg">
                    <div class="text-gray-500 text-xs">مدة التمييز</div>
                    <div class="font-bold">{{ $days }} أيام</div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-700/40 p-3 rounded-lg">
                    <div class="text-gray-500 text-xs">رصيدك الحالي</div>
                    <div class="font-bold">{{ number_format((float) $wallet->balance, 2) }}</div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-700/40 p-3 rounded-lg">
                    <div class="text-gray-500 text-xs">الرصيد بعد الخصم</div>
                    <div class="font-bold {{ (float)$wallet->balance < $cost ? 'text-red-600' : 'text-green-600' }}">
                        {{ number_format(max(0, (float) $wallet->balance - $cost), 2) }}
                    </div>
                </div>
            </div>

            @if((float) $wallet->balance < $cost)
                <div class="bg-red-50 text-red-800 p-3 rounded-lg text-sm">
                    رصيدك غير كافٍ. الرجاء شحن المحفظة أولاً.
                </div>
                <a href="{{ route('wallet.topup') }}" class="block text-center bg-emerald-600 text-white font-bold py-3 rounded-xl">شحن المحفظة عبر واتساب</a>
            @else
                <form action="{{ route('wallet.feature.apply', $post) }}" method="POST">
                    @csrf
                    <button class="w-full bg-primary text-white font-bold py-3 rounded-xl shadow hover:bg-primary-dark">
                        ✅ تأكيد التمييز
                    </button>
                </form>
            @endif

            <a href="{{ route('wallet.feature.list') }}" class="block text-center text-sm text-gray-500 mt-2">اختيار إعلان آخر</a>
        </div>
    </div>
</div>
@endsection
