@extends('layouts.app')
@section('title', 'محفظتي')
@section('content')
<div class="max-w-2xl mx-auto space-y-4">

    {{-- Hero balance card --}}
    <div class="relative overflow-hidden rounded-2xl shadow-lg text-white p-6"
         style="background: linear-gradient(135deg, #16a34a 0%, #15803d 60%, #0f766e 100%);">
        <div class="flex items-start justify-between">
            <div>
                <div class="text-sm opacity-80">رصيد المحفظة</div>
                <div class="text-4xl font-extrabold mt-1 tracking-tight">
                    {{ number_format((float) $wallet->balance, 2) }}
                    <span class="text-lg font-bold opacity-80">{{ $wallet->currency }}</span>
                </div>
                <div class="text-xs opacity-80 mt-2">@{{ auth()->user()->username }}</div>
            </div>
            <div class="text-5xl opacity-30">💳</div>
        </div>
        <div class="grid grid-cols-2 gap-2 mt-5">
            <a href="{{ route('wallet.feature.list') }}"
               class="bg-white/95 text-emerald-700 hover:bg-white text-center font-bold py-3 rounded-xl shadow">
                ✨ تمييز إعلان
            </a>
            <a href="{{ route('wallet.topup') }}"
               class="bg-black/25 hover:bg-black/35 border border-white/30 text-white text-center font-bold py-3 rounded-xl">
                💬 شحن المحفظة
            </a>
        </div>
    </div>

    {{-- Admin announcements --}}
    @foreach($announcements as $ann)
        @php
            $tone = [
                'info'    => ['bg' => 'bg-blue-50 dark:bg-blue-900/30',    'text' => 'text-blue-800 dark:text-blue-100',    'border' => 'border-blue-300',    'icon' => 'ℹ️'],
                'success' => ['bg' => 'bg-green-50 dark:bg-green-900/30',  'text' => 'text-green-800 dark:text-green-100',  'border' => 'border-green-300',   'icon' => '✅'],
                'warning' => ['bg' => 'bg-yellow-50 dark:bg-yellow-900/30','text' => 'text-yellow-800 dark:text-yellow-100','border' => 'border-yellow-300',  'icon' => '⚠️'],
                'danger'  => ['bg' => 'bg-red-50 dark:bg-red-900/30',      'text' => 'text-red-800 dark:text-red-100',      'border' => 'border-red-300',     'icon' => '🚨'],
            ][$ann->level] ?? ['bg' => 'bg-gray-50', 'text' => 'text-gray-800', 'border' => 'border-gray-300', 'icon' => '📢'];
        @endphp
        <div class="{{ $tone['bg'] }} {{ $tone['text'] }} border {{ $tone['border'] }} rounded-xl p-4 shadow-sm">
            <div class="flex items-start gap-3">
                <div class="text-2xl">{{ $tone['icon'] }}</div>
                <div class="flex-1">
                    <div class="font-bold mb-1">{{ $ann->title }}</div>
                    <div class="text-sm whitespace-pre-line leading-relaxed">{{ $ann->body }}</div>
                    <form action="{{ route('wallet.announcements.dismiss', $ann) }}" method="POST" class="mt-3">
                        @csrf
                        <button class="bg-white/90 hover:bg-white text-gray-800 text-sm font-semibold px-4 py-1.5 rounded-lg shadow-sm">
                            موافق
                        </button>
                    </form>
                </div>
            </div>
        </div>
    @endforeach

    {{-- Info card --}}
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow p-4 text-sm text-gray-600 dark:text-gray-300">
        <div class="font-semibold mb-1 text-gray-800 dark:text-gray-100">كيف تعمل المحفظة؟</div>
        <ul class="space-y-1 list-disc pr-5">
            <li>تكلفة تمييز إعلان واحد: <b>{{ number_format($featureCost, 2) }} {{ $wallet->currency }}</b> — ولمدة <b>{{ $featureDays }}</b> أيام.</li>
            <li>لشحن المحفظة تواصل مع الدعم عبر واتساب من الزر أعلاه.</li>
            <li>الإعلان المميّز يظهر في قسم «المميزة» وفي أعلى النتائج.</li>
        </ul>
    </div>

    {{-- Transactions --}}
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
        <div class="px-4 py-3 border-b dark:border-gray-700 font-bold">آخر المعاملات</div>
        @if($transactions->isEmpty())
            <div class="p-6 text-center text-gray-500">لا توجد معاملات حتى الآن.</div>
        @else
            <ul class="divide-y dark:divide-gray-700">
                @foreach($transactions as $tx)
                    <li class="p-3 flex items-center justify-between text-sm">
                        <div>
                            <div class="font-semibold">{{ $tx->reasonArabic() }}</div>
                            <div class="text-xs text-gray-500">{{ optional($tx->created_at)->format('Y-m-d H:i') }}</div>
                        </div>
                        <div class="font-bold {{ $tx->type === 'credit' ? 'text-green-600' : 'text-red-600' }}">
                            {{ $tx->type === 'credit' ? '+' : '−' }}{{ number_format((float) $tx->amount, 2) }}
                        </div>
                    </li>
                @endforeach
            </ul>
        @endif
    </div>
</div>
@endsection
