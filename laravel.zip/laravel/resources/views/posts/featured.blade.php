@extends('layouts.app')
@section('title', 'إعلانات مميزة')
@section('content')
<h1 class="text-xl font-bold mb-4">⭐ إعلانات مميزة</h1>
<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
    @foreach($posts as $post)
        @include('partials.post_card', ['post' => $post])
    @endforeach
</div>
<div class="mt-6">{{ $posts->links() }}</div>
@endsection
