@extends('layouts.app')
@section('title', $post->title . ' - ' . ($appName ?? 'متجرك'))
@section('description', mb_substr(strip_tags($post->description ?? $post->title), 0, 160))
@section('no_bottom_nav', '1')
@php
    $imgs = $post->images ?? [];
    if (empty($imgs)) $imgs = ['/assets/logo.png'];
    $absImg = url($imgs[0] ?? '/assets/logo.png');
    $absUrl = url(route('posts.show', $post, false));
    $isOwner = auth()->check() && ($post->user_id === auth()->id());
    $isAdmin = auth()->check() && auth()->user()->hasRole('admin');
    $waText = "السلام عليكم، بخصوص إعلانك:\n" . $absUrl . "\n";
    $waUrl = $post->whatsapp
        ? 'https://wa.me/' . ltrim($post->whatsapp, '+') . '?text=' . rawurlencode($waText)
        : null;
    $callNumber = $post->phone ?: $post->whatsapp;
    $telUrl = $callNumber ? 'tel:' . preg_replace('/[^0-9+]/', '', $callNumber) : null;
@endphp

@push('head')
    <link rel="canonical" href="{{ $absUrl }}">
    <meta property="og:type" content="product">
    <meta property="og:title" content="{{ $post->title }}">
    <meta property="og:description" content="{{ mb_substr(strip_tags($post->description ?? $post->title), 0, 200) }}">
    <meta property="og:url" content="{{ $absUrl }}">
    <meta property="og:image" content="{{ $absImg }}">
    <meta property="og:image:secure_url" content="{{ $absImg }}">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="{{ $post->title }}">
    <meta property="og:site_name" content="{{ $appName ?? 'متجرك' }}">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $post->title }}">
    <meta name="twitter:description" content="{{ mb_substr(strip_tags($post->description ?? $post->title), 0, 200) }}">
    <meta name="twitter:image" content="{{ $absImg }}">
    <script type="application/ld+json">
    {!! json_encode([
        '@context' => 'https://schema.org', '@type' => 'Product',
        'name' => $post->title,
        'description' => mb_substr(strip_tags($post->description ?? $post->title), 0, 500),
        'image' => array_map(fn($i) => url($i), $imgs),
        'url' => $absUrl, 'category' => $post->category,
        'offers' => [
            '@type' => 'Offer', 'price' => (float)$post->price,
            'priceCurrency' => $post->currency ?: 'SDG',
            'availability' => 'https://schema.org/InStock',
            'areaServed' => $post->state, 'url' => $absUrl,
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}
    </script>
@endpush

@section('content')

{{-- Sticky back button (modern, glassy) --}}
<div class="mb-3">
    <button type="button" onclick="postBack()" aria-label="رجوع"
            class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-md border border-gray-200 dark:border-gray-700 shadow-sm text-sm font-semibold hover:bg-white">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>
        رجوع
    </button>
</div>
<script>
function postBack(){
    try {
        if (document.referrer && new URL(document.referrer).origin === location.origin) { history.back(); return; }
    } catch(_){}
    location.href = '{{ url('/') }}';
}
</script>

<div class="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm">
    {{-- Header (user + options) --}}
    <div class="flex items-center justify-between p-3 border-b border-gray-100 dark:border-gray-700">
        <a href="#" class="flex items-center gap-2">
            @if($post->user->avatar_url)
                <img src="{{ $post->user->avatar_url }}" alt="" class="w-10 h-10 rounded-full object-cover">
            @else
                <div class="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                    {{ mb_substr($post->user->username ?? 'م', 0, 1) }}
                </div>
            @endif
            <div>
                <div class="font-semibold text-sm">{{ $post->user->full_name ?? $post->user->username }}</div>
                <div class="text-[11px] text-gray-500">{{ $post->created_at->diffForHumans() }}</div>
            </div>
        </a>
        <div class="relative">
            <button onclick="toggleMenu('show')" class="w-9 h-9 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center justify-center text-gray-500" aria-label="خيارات">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
            </button>
            <div id="menu-show" class="hidden absolute left-0 mt-1 bg-white dark:bg-gray-700 shadow-xl rounded-lg p-1 z-30 w-40 text-sm">
                @if($isOwner || $isAdmin)
                    <a href="{{ route('posts.edit', $post) }}" class="block px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded">✏️ تعديل</a>
                    <form action="{{ route('posts.destroy', $post) }}" method="POST" onsubmit="return confirm('تأكيد الحذف؟')">
                        @csrf @method('DELETE')
                        <button class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded text-red-500">🗑 حذف</button>
                    </form>
                @endif
                @auth
                    @if(!$isOwner)
                        <button onclick="openReport({{ $post->id }}); toggleMenu('show')" class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded text-red-500">🚩 إبلاغ</button>
                    @endif
                @endauth
                <button onclick="sharePost('{{ $absUrl }}','{{ addslashes($post->title) }}'); toggleMenu('show')" class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded">➦ مشاركة</button>
            </div>
        </div>
    </div>

    {{-- Image Gallery: arrows + dots + click-to-expand --}}
    <div class="relative group" id="gallery">
        <div id="galleryTrack" class="flex overflow-x-auto snap-x snap-mandatory scroll-smooth no-scrollbar">
            @foreach($imgs as $i => $img)
                <img src="{{ $img }}" data-idx="{{ $i }}" alt="{{ $post->title }}" loading="lazy"
                     class="gallery-img w-full shrink-0 snap-center h-80 object-cover bg-gray-100 dark:bg-gray-900 cursor-zoom-in">
            @endforeach
        </div>

        @if(count($imgs) > 1)
            <button type="button" onclick="gNav(-1)" aria-label="السابق"
                    class="absolute top-1/2 -translate-y-1/2 right-2 w-10 h-10 rounded-full bg-black/50 text-white text-xl flex items-center justify-center backdrop-blur-sm hover:bg-black/70">›</button>
            <button type="button" onclick="gNav(1)" aria-label="التالي"
                    class="absolute top-1/2 -translate-y-1/2 left-2 w-10 h-10 rounded-full bg-black/50 text-white text-xl flex items-center justify-center backdrop-blur-sm hover:bg-black/70">‹</button>
            <div id="galleryDots" class="absolute bottom-3 inset-x-0 flex justify-center gap-2">
                @foreach($imgs as $i => $img)
                    <button type="button" onclick="gGo({{ $i }})" aria-label="صورة {{ $i+1 }}"
                            class="dot w-3 h-3 rounded-full bg-white/60 border border-black/20 transition-all"></button>
                @endforeach
            </div>
            <div class="absolute top-3 left-3 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
                <span id="gCur">1</span>/<span>{{ count($imgs) }}</span>
            </div>
        @endif

        @if($post->featured)
            <span class="absolute top-3 right-3 bg-yellow-400 text-xs font-bold px-2 py-0.5 rounded-full">⭐ مميز</span>
        @endif
    </div>

    {{-- Lightbox (pinch-zoom enabled, true center) --}}
    <div id="lightbox" class="hidden fixed inset-0 z-50 bg-black" style="touch-action:pinch-zoom;">
        <button onclick="closeLightbox()" aria-label="إغلاق" class="fixed top-4 right-4 w-11 h-11 rounded-full bg-white/20 text-white text-2xl flex items-center justify-center z-[60]">←</button>
        <div id="lightboxScroll" class="w-screen h-screen overflow-auto flex items-center justify-center" style="touch-action:pinch-zoom;">
            <img id="lightboxImg" src="" alt="" class="block max-w-none object-contain select-none" style="max-width:100vw;max-height:100vh;width:auto;height:auto;margin:auto;" draggable="false">
        </div>
        @if(count($imgs) > 1)
            <button onclick="gNav(-1, true)" class="fixed top-1/2 -translate-y-1/2 right-2 w-12 h-12 rounded-full bg-white/20 text-white text-2xl z-[60]">›</button>
            <button onclick="gNav(1, true)" class="fixed top-1/2 -translate-y-1/2 left-2 w-12 h-12 rounded-full bg-white/20 text-white text-2xl z-[60]">‹</button>
        @endif
    </div>

    {{-- Body --}}
    <div class="p-4 space-y-4">
        <h1 class="text-xl font-bold leading-tight">{{ $post->title }}</h1>
        <div class="text-2xl text-primary font-extrabold">{{ $post->priceArabic() }}</div>

        {{-- Info cards: 2 per row --}}
        <div class="grid grid-cols-2 gap-3">
            <div class="bg-gray-50 dark:bg-gray-900/40 border border-gray-100 dark:border-gray-700 rounded-2xl p-3 shadow-sm">
                <div class="text-[11px] text-gray-500 mb-1">📍 الولاية</div>
                <div class="font-semibold text-sm truncate">{{ $post->state ?: '—' }}</div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-900/40 border border-gray-100 dark:border-gray-700 rounded-2xl p-3 shadow-sm">
                <div class="text-[11px] text-gray-500 mb-1">🏙 المدينة</div>
                <div class="font-semibold text-sm truncate">{{ $post->city ?: '—' }}</div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-900/40 border border-gray-100 dark:border-gray-700 rounded-2xl p-3 shadow-sm">
                <div class="text-[11px] text-gray-500 mb-1">📂 القسم</div>
                <div class="font-semibold text-sm truncate">{{ $post->category ?: '—' }}</div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-900/40 border border-gray-100 dark:border-gray-700 rounded-2xl p-3 shadow-sm">
                <div class="text-[11px] text-gray-500 mb-1">✨ الحالة</div>
                <div class="font-semibold text-sm truncate">{{ $post->condition ?: '—' }}</div>
            </div>
        </div>

        <p class="whitespace-pre-wrap leading-relaxed text-[15px]">{{ $post->description }}</p>

        {{-- Contact CTAs: Call + WhatsApp (shown to everyone including owner) --}}
        <div class="space-y-2">
            @if($telUrl)
                <a href="{{ $telUrl }}"
                   class="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-white font-bold text-base shadow"
                   style="background:#2563eb">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="#fff" aria-hidden="true">
                        <path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.4c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.2 2.2z"/>
                    </svg>
                    اتصال {{ !$post->phone ? '(عبر رقم الواتساب)' : '' }}
                </a>
            @endif
            @if($waUrl)
                <a href="{{ $waUrl }}" target="_blank" rel="noopener"
                   class="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-white font-bold text-base shadow"
                   style="background:#25D366">
                    <svg viewBox="0 0 32 32" width="22" height="22" fill="#fff" aria-hidden="true">
                        <path d="M19.11 17.5c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.61.14-.18.27-.7.88-.86 1.06-.16.18-.32.2-.59.07-.27-.14-1.13-.42-2.16-1.33-.8-.71-1.34-1.6-1.5-1.87-.16-.27-.02-.42.12-.55.12-.12.27-.32.41-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.61-1.47-.84-2.01-.22-.53-.45-.46-.61-.47l-.52-.01c-.18 0-.48.07-.73.34-.25.27-.96.94-.96 2.29 0 1.35.98 2.65 1.12 2.83.14.18 1.93 2.95 4.68 4.13.65.28 1.16.45 1.56.58.65.21 1.25.18 1.72.11.53-.08 1.6-.65 1.83-1.28.23-.63.23-1.17.16-1.28-.07-.11-.25-.18-.52-.32zM16.02 4C9.38 4 4 9.38 4 16.02c0 2.12.55 4.18 1.6 6L4 28l6.2-1.62a12 12 0 0 0 5.82 1.49h.01c6.64 0 12.02-5.38 12.02-12.02C28.05 9.38 22.67 4 16.02 4z"/>
                    </svg>
                    تواصل عبر الواتساب
                </a>
            @endif
            @if($isOwner && ($post->phone || $post->whatsapp))
                <div class="text-[11px] text-gray-500 text-center">أرقام التواصل التي اخترتها لهذا الإعلان</div>
            @endif
        </div>

        {{-- نبذة عن الناشر --}}
        @if(!empty($post->user->bio))
        <div class="bg-gray-50 dark:bg-gray-900/40 border border-gray-100 dark:border-gray-700 rounded-2xl p-3">
            <div class="text-[11px] text-gray-500 mb-1">📝 نبذة عن الناشر</div>
            <p class="text-sm whitespace-pre-wrap leading-relaxed">{{ $post->user->bio }}</p>
        </div>
        @endif

        {{-- Action bar: like / save / share — equal flex-1, AJAX --}}
        @auth
        <div class="flex items-stretch border-t border-b border-gray-100 dark:border-gray-700 py-2">
            <button id="btnLike" type="button" onclick="ajaxLike(this, {{ $post->id }})"
                    class="flex-1 flex flex-col items-center justify-center py-1 gap-0.5 {{ $post->isLikedBy(auth()->id()) ? 'text-red-500' : 'text-gray-500' }}">
                <span class="heart text-xl">{{ $post->isLikedBy(auth()->id()) ? '❤️' : '🤍' }}</span>
                <span class="text-[11px]"><span class="count">{{ $post->likes()->count() }}</span> إعجاب</span>
            </button>
            <button id="btnSave" type="button" onclick="ajaxSave(this, {{ $post->id }})"
                    class="flex-1 flex flex-col items-center justify-center py-1 gap-0.5 {{ $post->isSavedBy(auth()->id()) ? 'text-yellow-500' : 'text-gray-500' }}">
                <span class="star text-xl">{{ $post->isSavedBy(auth()->id()) ? '★' : '☆' }}</span>
                <span class="text-[11px]">حفظ</span>
            </button>
            <button type="button" onclick="sharePost('{{ $absUrl }}','{{ addslashes($post->title) }}')"
                    class="flex-1 flex flex-col items-center justify-center py-1 gap-0.5 text-gray-500">
                <span class="text-xl">➦</span>
                <span class="text-[11px]">مشاركة</span>
            </button>
        </div>
        @endauth

        {{-- Seller info + rating --}}
        @if(!$isOwner)
        <div class="bg-gradient-to-l from-emerald-50 to-blue-50 dark:from-emerald-900/20 dark:to-blue-900/20 rounded-2xl p-4 border border-gray-100 dark:border-gray-700">
            <div class="flex items-center gap-3">
                @if($post->user->avatar_url)
                    <img src="{{ $post->user->avatar_url }}" alt="" class="w-12 h-12 rounded-full object-cover shrink-0">
                @else
                    <div class="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white text-xl font-bold shrink-0">
                        {{ mb_substr($post->user->username ?? 'م', 0, 1) }}
                    </div>
                @endif
                <div class="flex-1 min-w-0">
                    <div class="font-bold truncate">{{ $post->user->full_name ?? $post->user->username }}</div>
                    <div class="text-xs text-gray-500">
                        @php $full = (int) floor($sellerRatingAvg); @endphp
                        <span class="text-yellow-500">{{ str_repeat('★', $full) }}{{ str_repeat('☆', 5-$full) }}</span>
                        <span class="ml-1">({{ number_format($sellerRatingAvg, 1) }} • {{ $sellerRatingCount }})</span>
                    </div>
                </div>
            </div>

            @auth
                @if($userRated)
                    <div class="mt-3 text-xs text-gray-500">
                        ✅ سبق تقييمك لهذا البائع:
                        <span class="text-yellow-500">{{ str_repeat('★', (int)$userRated->stars) }}</span>
                    </div>
                @else
                    <div id="rateBox" class="mt-3">
                        <div class="text-xs text-gray-500 mb-1">قيّم البائع:</div>
                        <div id="stars" class="flex items-center gap-1 text-2xl text-gray-300">
                            @for($i=1;$i<=5;$i++)
                                <button type="button" data-v="{{ $i }}" onclick="pickStar({{ $i }})" class="hover:scale-110 transition">☆</button>
                            @endfor
                            <button id="submitRate" type="button" onclick="submitRating({{ $post->user_id }})"
                                    class="text-sm bg-primary text-white px-3 py-1.5 rounded-lg mr-2 disabled:opacity-40" disabled>إرسال</button>
                        </div>
                        <div class="text-[10px] text-gray-400 mt-1">يمكنك التقييم مرة واحدة فقط.</div>
                    </div>
                @endif
            @endauth
        </div>
        @endif
    </div>
</div>

{{-- Comments --}}
<section id="comments" class="mt-6 bg-white dark:bg-gray-800 rounded-2xl p-4">
    <h2 class="font-bold mb-3">التعليقات (<span id="cmt-count">{{ $post->comments->count() }}</span>)</h2>
    @auth
        <form id="cmtForm" class="flex gap-2 mb-4">
            @csrf
            <input id="cmt-body" name="body" required maxlength="1000" placeholder="اكتب تعليقاً..."
                   class="flex-1 px-3 py-2 rounded-full bg-gray-100 dark:bg-gray-700">
            <input type="hidden" id="cmt-parent" name="parent_id" value="">
            <button class="bg-primary text-white px-4 rounded-full">إرسال</button>
        </form>
        <div id="reply-context" class="hidden mb-3 text-xs text-primary">
            تقوم بالرد على <span id="reply-name"></span>
            <button type="button" onclick="cancelReply()" class="text-red-500 mr-2">إلغاء</button>
        </div>
    @else
        <a href="{{ route('login') }}" class="text-accent text-sm">سجل الدخول للتعليق</a>
    @endauth

    @php
        $topLevel = $post->comments->whereNull('parent_id');
        $byParent = $post->comments->whereNotNull('parent_id')->groupBy('parent_id');
    @endphp

    <div id="cmt-list" class="space-y-3">
        @foreach($topLevel as $c)
            <div id="cmt-{{ $c->id }}" class="border-b border-gray-100 dark:border-gray-700 pb-2">
                <div class="flex gap-3 items-start">
                    <div class="w-9 h-9 bg-accent text-white rounded-full flex items-center justify-center font-bold shrink-0">
                        {{ mb_substr($c->user->username, 0, 1) }}
                    </div>
                    <div class="flex-1">
                        <div class="text-sm font-semibold">{{ $c->user->username }}</div>
                        <div class="text-sm">{{ $c->body }}</div>
                        <div class="flex items-center gap-3 text-xs text-gray-400 mt-1">
                            <span>{{ $c->created_at->diffForHumans() }}</span>
                            @auth
                                <button type="button" onclick="startReply({{ $c->id }}, '{{ addslashes($c->user->username) }}')" class="text-primary">↩ رد</button>
                            @endauth
                        </div>
                    </div>
                </div>
                @if(isset($byParent[$c->id]))
                    <div class="mr-12 mt-2 space-y-2">
                        @foreach($byParent[$c->id] as $r)
                            <div id="cmt-{{ $r->id }}" class="flex gap-2 items-start">
                                <div class="w-7 h-7 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center text-xs font-bold shrink-0">
                                    {{ mb_substr($r->user->username, 0, 1) }}
                                </div>
                                <div class="flex-1 bg-gray-50 dark:bg-gray-900/40 rounded-lg px-2 py-1">
                                    <div class="text-xs font-semibold">{{ $r->user->username }}</div>
                                    <div class="text-sm">{{ $r->body }}</div>
                                    <div class="text-[10px] text-gray-400">{{ $r->created_at->diffForHumans() }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endif
            </div>
        @endforeach
    </div>
</section>

{{-- Recommendations --}}
@if($recommended->count())
<section class="mt-6">
    <h2 class="font-bold mb-3">✨ اقتراحات لك</h2>
    <div class="flex gap-3 overflow-x-auto -mx-4 px-4 pb-2 no-scrollbar">
        @foreach($recommended as $p)
            <a href="{{ route('posts.show', $p) }}" class="shrink-0 w-40 bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700">
                <img src="{{ $p->firstImage() }}" alt="{{ $p->title }}" class="w-full h-32 object-cover" loading="lazy">
                <div class="p-2">
                    <div class="text-sm font-semibold truncate">{{ $p->title }}</div>
                    <div class="text-primary text-sm font-bold">{{ $p->priceArabic() }}</div>
                </div>
            </a>
        @endforeach
    </div>
</section>
@endif

{{-- Sticky WhatsApp CTA removed — button now appears under description --}}

<style>.no-scrollbar::-webkit-scrollbar{display:none}.no-scrollbar{scrollbar-width:none}</style>

<script>
// === Gallery ===
const gTrack = document.getElementById('galleryTrack');
const gDots = document.querySelectorAll('#galleryDots .dot');
const gCur = document.getElementById('gCur');
const gImgs = {!! json_encode(array_values($imgs)) !!};
let gIdx = 0;

function gUpdateDots() {
    gDots.forEach((d,i) => {
        d.classList.toggle('bg-white', i === gIdx);
        d.classList.toggle('w-6', i === gIdx);
        d.classList.toggle('bg-white/60', i !== gIdx);
    });
    if (gCur) gCur.textContent = (gIdx+1);
}
function gGo(i) {
    gIdx = Math.max(0, Math.min(gImgs.length-1, i));
    if (gTrack && gTrack.children[gIdx]) gTrack.children[gIdx].scrollIntoView({behavior:'smooth', inline:'center', block:'nearest'});
    gUpdateDots();
    if (lbOpen) document.getElementById('lightboxImg').src = gImgs[gIdx];
}
function gNav(delta, lb) { gGo(gIdx + delta); }
if (gTrack) {
    gTrack.addEventListener('scroll', () => {
        const w = gTrack.clientWidth || 1;
        gIdx = Math.round(gTrack.scrollLeft / w);
        gUpdateDots();
    }, {passive:true});
    gUpdateDots();
}

// === Lightbox (centered + native pinch-zoom) ===
let lbOpen = false;
function lbCenter(){
    const sc = document.getElementById('lightboxScroll');
    if (!sc) return;
    requestAnimationFrame(() => {
        sc.scrollTop = (sc.scrollHeight - sc.clientHeight) / 2;
        sc.scrollLeft = (sc.scrollWidth - sc.clientWidth) / 2;
    });
}
document.querySelectorAll('.gallery-img').forEach(img => {
    img.addEventListener('click', () => {
        gIdx = parseInt(img.dataset.idx || 0);
        const lbImg = document.getElementById('lightboxImg');
        lbImg.src = gImgs[gIdx];
        document.getElementById('lightbox').classList.remove('hidden');
        lbOpen = true; document.body.style.overflow = 'hidden';
        lbImg.onload = lbCenter;
        lbCenter();
    });
});
function closeLightbox(){
    document.getElementById('lightbox').classList.add('hidden');
    lbOpen = false; document.body.style.overflow = '';
}
document.addEventListener('keydown', (e) => {
    if (!lbOpen) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') gNav(1);
    if (e.key === 'ArrowRight') gNav(-1);
});

// === AJAX like/save (no reload) ===
async function ajaxLike(btn, postId) {
    const res = await fetch(`/posts/${postId}/like`, {
        method:'POST',
        headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json'},
    });
    const d = await res.json().catch(()=>null);
    if (!d) return;
    btn.classList.toggle('text-red-500', d.liked);
    btn.classList.toggle('text-gray-500', !d.liked);
    btn.querySelector('.heart').textContent = d.liked ? '❤️' : '🤍';
    btn.querySelector('.count').textContent = d.likes_count;
    if (d.liked) toastFlash('تم الإعجاب ❤️');
}
async function ajaxSave(btn, postId) {
    const res = await fetch(`/posts/${postId}/save`, {
        method:'POST',
        headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json'},
    });
    const d = await res.json().catch(()=>null);
    if (!d) return;
    btn.classList.toggle('text-yellow-500', d.saved);
    btn.classList.toggle('text-gray-500', !d.saved);
    btn.querySelector('.star').textContent = d.saved ? '★' : '☆';
    toastFlash(d.saved ? 'تم الحفظ ★' : 'تم الإلغاء');
}

// === Menu ===
window.toggleMenu = window.toggleMenu || function(id){
    const m = document.getElementById('menu-'+id);
    if(!m) return;
    document.querySelectorAll('[id^="menu-"]').forEach(el => el !== m && el.classList.add('hidden'));
    m.classList.toggle('hidden');
};
document.addEventListener('click', (e) => {
    if (!e.target.closest('[id^="menu-"]') && !e.target.closest('[onclick^="toggleMenu"]')) {
        document.querySelectorAll('[id^="menu-"]').forEach(el => el.classList.add('hidden'));
    }
});

// === Reply / comments ===
window.startReply = function(id, name){
    document.getElementById('cmt-parent').value = id;
    document.getElementById('reply-name').textContent = '@'+name;
    document.getElementById('reply-context').classList.remove('hidden');
    document.getElementById('cmt-body').focus();
};
window.cancelReply = function(){
    document.getElementById('cmt-parent').value = '';
    document.getElementById('reply-context').classList.add('hidden');
};
if(location.hash && location.hash.startsWith('#cmt-')) {
    const el = document.querySelector(location.hash);
    if(el){ el.scrollIntoView({behavior:'smooth', block:'center'}); el.classList.add('ring-2','ring-primary','rounded-lg'); }
}

// === Star rating ===
let pickedStars = 0;
function pickStar(v) {
    pickedStars = v;
    document.querySelectorAll('#stars button[data-v]').forEach(btn => {
        const isOn = parseInt(btn.dataset.v) <= v;
        btn.textContent = isOn ? '★' : '☆';
        btn.classList.toggle('text-yellow-500', isOn);
        btn.classList.toggle('text-gray-300', !isOn);
    });
    document.getElementById('submitRate').disabled = false;
}
async function submitRating(sellerId) {
    if (!pickedStars) return;
    const res = await fetch(`/sellers/${sellerId}/rate`, {
        method:'POST',
        headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded'},
        body: 'stars='+pickedStars,
    });
    const d = await res.json().catch(()=>null);
    if (d && d.ok) {
        document.getElementById('rateBox').innerHTML =
            '<div class="text-xs text-gray-500 mt-2">✅ شكراً على تقييمك! المتوسط الآن: '+d.avg+' ('+d.count+')</div>';
        toastFlash('تم حفظ تقييمك ⭐');
    } else if (res.status === 409) {
        toastFlash('سبق تقييمك لهذا البائع');
        document.getElementById('rateBox').remove();
    } else {
        toastFlash('تعذر إرسال التقييم');
    }
}
</script>

@auth
<script>
document.getElementById('cmtForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = document.getElementById('cmt-body').value.trim();
    const parent = document.getElementById('cmt-parent').value;
    if(!body) return;
    const params = new URLSearchParams();
    params.append('body', body);
    if (parent) params.append('parent_id', parent);
    const res = await fetch(`{{ route('posts.comment', $post) }}`, {
        method:'POST',
        headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded'},
        body: params.toString(),
    });
    const d = await res.json().catch(()=>null);
    if (d?.success) { document.getElementById('cmt-body').value=''; cancelReply(); location.reload(); }
});
</script>
@endauth
@endsection
