@extends('layouts.app')
@section('title', 'تعديل الإعلان')
@section('no_bottom_nav', '1')
@section('content')
@push('head')
<script>
// Block re-entry to the edit page after a successful save.
// On submit, mark this post as "just edited" in sessionStorage.
// On any subsequent visit (back/forward/direct), redirect to the post page.
(function(){
    try {
        const POST_ID = {{ (int) $post->id }};
        const KEY = 'edit_done_' + POST_ID;
        const SHOW_URL = @json(route('posts.show', $post));
        if (sessionStorage.getItem(KEY)) {
            location.replace(SHOW_URL);
            return;
        }
        window.addEventListener('pageshow', (e) => {
            if (e.persisted && sessionStorage.getItem(KEY)) location.replace(SHOW_URL);
            else if (e.persisted) history.back();
        });
        document.addEventListener('submit', (e) => {
            if (e.target && e.target.tagName === 'FORM' && e.target.method.toLowerCase() === 'post') {
                sessionStorage.setItem(KEY, '1');
            }
        }, true);
    } catch(_){}
})();
</script>
@endpush
@php
    $categories = \App\Models\Category::where('is_active', true)->orderBy('sort_order')->pluck('name')->toArray();
    if (empty($categories)) $categories = ['إلكترونيات','سيارات','عقارات','أثاث','ملابس','هواتف','أخرى'];
    $states = \App\Models\StateModel::where('is_active', true)->orderBy('sort_order')->pluck('name')->toArray();
    if (empty($states)) $states = ['الخرطوم','الجزيرة','نهر النيل','الشمالية','كسلا'];
    $existingImages = $post->images ?? [];
@endphp
<div class="bg-white dark:bg-gray-800 rounded-xl p-5 shadow">
    <h1 class="text-xl font-bold mb-4">✏ تعديل الإعلان</h1>
    <form action="{{ route('posts.update', $post) }}" method="POST" enctype="multipart/form-data" class="space-y-3">
        @csrf @method('PUT')
        <div>
            <label class="text-sm font-semibold block mb-1">العنوان *</label>
            <input name="title" value="{{ old('title', $post->title) }}" required maxlength="200" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">الوصف *</label>
            <textarea name="description" required minlength="10" rows="4" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">{{ old('description', $post->description) }}</textarea>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">السعر *</label>
                <input name="price" type="number" min="0" step="0.01" value="{{ old('price', $post->price) }}" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">العملة</label>
                <select name="currency" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    @foreach(['SDG'=>'جنيه سوداني','USD'=>'دولار','SAR'=>'ريال سعودي'] as $k=>$v)
                        <option value="{{ $k }}" {{ $post->currency===$k?'selected':'' }}>{{ $v }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">القسم *</label>
                <select name="category" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    @foreach($categories as $c)<option value="{{ $c }}" {{ $post->category===$c?'selected':'' }}>{{ $c }}</option>@endforeach
                </select>
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">الولاية *</label>
                <select name="state" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    @foreach($states as $s)<option value="{{ $s }}" {{ $post->state===$s?'selected':'' }}>{{ $s }}</option>@endforeach
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">المدينة *</label>
                <input name="city" value="{{ old('city', $post->city) }}" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">الحالة *</label>
                <select name="condition" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    <option value="">اختر...</option>
                    @foreach(['جديد','مستعمل'] as $c)
                        <option value="{{ $c }}" {{ $post->condition===$c?'selected':'' }}>{{ $c }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">هاتف (اختياري)</label>
                <input name="phone" value="{{ old('phone', $post->phone) }}" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700" placeholder="+249...">
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">واتساب <span class="text-red-500">*</span></label>
                <input name="whatsapp" value="{{ old('whatsapp', $post->whatsapp) }}" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700" placeholder="+249...">
            </div>
        </div>

        @if(count($existingImages))
        <div>
            <label class="text-sm font-semibold block mb-1">الصور الحالية</label>
            <p class="text-xs text-gray-500 mb-2">انقر على صورة لتحديدها كصورة الغلاف ⭐. اضغط × لإزالة صورة.</p>
            <div class="grid grid-cols-3 gap-2" id="existingGrid">
                @foreach($existingImages as $i => $img)
                    <div class="relative cursor-pointer rounded-lg overflow-hidden ring-1 ring-gray-300 existing-thumb {{ $i===0?'ring-4 ring-primary':'' }}" data-idx="{{ $i }}" data-path="{{ $img }}">
                        <img src="{{ $img }}" class="w-full h-24 object-cover">
                        @if($i===0)<span class="cover-badge absolute top-1 right-1 bg-primary text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">⭐ غلاف</span>@endif
                        <button type="button" class="absolute top-1 left-1 bg-red-500 text-white w-6 h-6 rounded-full text-xs remove-btn" aria-label="إزالة">×</button>
                        <input type="hidden" name="existing_images[]" value="{{ $img }}">
                    </div>
                @endforeach
            </div>
            <input type="hidden" name="existing_cover_index" id="existingCoverIndex" value="0">
        </div>
        @endif

        <div>
            <label class="text-sm font-semibold block mb-1">إضافة صور جديدة (حتى 10، {{ env('UPLOAD_MAX_MB', 5) }}MB لكل صورة)</label>
            <input id="imgInput" name="images[]" type="file" multiple accept="image/jpeg,image/png,image/webp"
                   class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            <div id="imgPreview" class="grid grid-cols-3 gap-2 mt-2"></div>
            <div id="imgError" class="text-red-500 text-xs mt-1"></div>
        </div>

        <div>
            <label class="text-sm font-semibold block mb-1">الفيديو (اختياري — حتى 5MB)</label>
            @if(!empty($post->video_url))
                <video src="{{ $post->video_url }}" controls class="w-full max-h-56 rounded-lg bg-black mb-2"></video>
                <label class="text-xs flex items-center gap-2 mb-2"><input type="checkbox" name="remove_video" value="1"> إزالة الفيديو الحالي</label>
            @endif
            <input id="vidInput" name="video" type="file" accept="video/mp4,video/webm,video/quicktime"
                   class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            <video id="vidPreview" class="hidden w-full max-h-56 mt-2 rounded-lg bg-black" controls></video>
            <div id="vidError" class="text-red-500 text-xs mt-1"></div>
        </div>

        <script>
        (function(){
            const grid = document.getElementById('existingGrid');
            if(!grid) return;
            const idxInput = document.getElementById('existingCoverIndex');
            function refresh(){
                Array.from(grid.querySelectorAll('.existing-thumb')).forEach((el, i) => {
                    el.classList.toggle('ring-4', i==idxInput.value);
                    el.classList.toggle('ring-primary', i==idxInput.value);
                });
            }
            grid.addEventListener('click', (e) => {
                const rm = e.target.closest('.remove-btn');
                if(rm){ e.stopPropagation(); rm.closest('.existing-thumb').remove(); refresh(); return; }
                const th = e.target.closest('.existing-thumb');
                if(!th) return;
                const all = Array.from(grid.querySelectorAll('.existing-thumb'));
                idxInput.value = all.indexOf(th);
                refresh();
            });
        })();
        document.getElementById('vidInput')?.addEventListener('change', (e) => {
            const err = document.getElementById('vidError'); err.textContent = '';
            const v = document.getElementById('vidPreview');
            const f = e.target.files[0];
            if(!f){ v.classList.add('hidden'); return; }
            if(f.size > 5*1024*1024){ err.textContent = 'حجم الفيديو يجب ألا يتجاوز 5 ميجابايت'; e.target.value=''; v.classList.add('hidden'); return; }
            v.src = URL.createObjectURL(f);
            v.classList.remove('hidden');
        });
        </script>

        <button class="w-full bg-primary text-white py-3 rounded-lg font-bold">حفظ التغييرات</button>
    </form>
</div>
@endsection
