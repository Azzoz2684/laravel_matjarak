@extends('layouts.app')
@section('title', 'إنشاء إعلان')
@section('content')
@php
    $categories = \App\Models\Category::where('is_active', true)->orderBy('sort_order')->pluck('name')->toArray();
    if (empty($categories)) $categories = ['إلكترونيات','سيارات','عقارات','أثاث','ملابس','هواتف','أخرى'];
    $states = \App\Models\StateModel::where('is_active', true)->orderBy('sort_order')->pluck('name')->toArray();
    if (empty($states)) $states = ['الخرطوم','الجزيرة','نهر النيل','الشمالية','كسلا'];
@endphp

<div class="bg-white dark:bg-gray-800 rounded-xl p-5 shadow">
    <h1 class="text-xl font-bold mb-4">📝 إنشاء إعلان جديد</h1>
    <form id="postForm" data-bgsync-form action="{{ route('posts.store') }}" method="POST" enctype="multipart/form-data" class="space-y-3">

        @csrf
        <div>
            <label class="text-sm font-semibold block mb-1">العنوان *</label>
            <input name="title" required maxlength="200" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">الوصف *</label>
            <textarea name="description" required minlength="10" rows="4" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700"></textarea>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">السعر *</label>
                <input name="price" type="number" min="0" step="0.01" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">العملة</label>
                <select name="currency" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    <option value="SDG">جنيه سوداني</option>
                    <option value="USD">دولار</option>
                    <option value="SAR">ريال سعودي</option>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">القسم *</label>
                <select name="category" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    @foreach($categories as $c)<option>{{ $c }}</option>@endforeach
                </select>
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">الولاية *</label>
                <select name="state" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    @foreach($states as $s)<option>{{ $s }}</option>@endforeach
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">المدينة *</label>
                <input name="city" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">الحالة *</label>
                <select name="condition" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                    <option value="">اختر...</option>
                    <option value="جديد">جديد</option>
                    <option value="مستعمل">مستعمل</option>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="text-sm font-semibold block mb-1">هاتف (اختياري)</label>
                <input name="phone" dir="ltr" inputmode="tel" autocomplete="off"
                       class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700 toggle-ltr" placeholder="+249..."
                       oninput="this.value = this.value.replace(/\s+/g,'')">
            </div>
            <div>
                <label class="text-sm font-semibold block mb-1">واتساب <span class="text-red-500">*</span></label>
                <input name="whatsapp" required dir="ltr" inputmode="tel" autocomplete="off"
                       class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700 toggle-ltr" placeholder="+249..."
                       oninput="this.value = this.value.replace(/\s+/g,'')">
            </div>
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">الصور <span class="text-red-500">*</span> (JPG/PNG/WEBP — حتى {{ env('UPLOAD_MAX_MB', 5) }}MB، 10 صور كحد أقصى)</label>
            <p class="text-xs text-gray-500 mb-2">يجب رفع صورة واحدة على الأقل. انقر على صورة لتحديدها كصورة الغلاف ⭐</p>
            <input id="imgInput" name="images[]" type="file" multiple required accept="image/jpeg,image/png,image/webp"
                   class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            <input type="hidden" name="cover_index" id="coverIndex" value="0">
            <div id="imgPreview" class="grid grid-cols-3 gap-2 mt-2"></div>
            <div id="imgError" class="text-red-500 text-xs mt-1"></div>
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">فيديو قصير (اختياري — حتى 5MB، MP4/WebM/MOV)</label>
            <input id="vidInput" name="video" type="file" accept="video/mp4,video/webm,video/quicktime"
                   class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            <video id="vidPreview" class="hidden w-full max-h-56 mt-2 rounded-lg bg-black" controls></video>
            <div id="vidError" class="text-red-500 text-xs mt-1"></div>
        </div>
        <script>
        document.getElementById('vidInput')?.addEventListener('change', (e) => {
            const err = document.getElementById('vidError'); err.textContent = '';
            const v = document.getElementById('vidPreview');
            const f = e.target.files[0];
            if(!f){ v.classList.add('hidden'); return; }
            if(f.size > 5*1024*1024){ err.textContent = 'حجم الفيديو يجب ألا يتجاوز 5 ميجابايت'; e.target.value=''; v.classList.add('hidden'); return; }
            v.src = URL.createObjectURL(f);
            v.classList.remove('hidden');
        });
        </script>
        <script>
        const MAX_MB = {{ (int) env('UPLOAD_MAX_MB', 5) }};
        const ALLOWED = ['image/jpeg','image/png','image/webp'];
        let selectedFiles = [];
        let coverIdx = 0;
        function renderPreview(){
            const prev = document.getElementById('imgPreview');
            prev.innerHTML = '';
            selectedFiles.forEach((f, i) => {
                const wrap = document.createElement('div');
                wrap.className = 'relative cursor-pointer rounded-lg overflow-hidden ' + (i===coverIdx ? 'ring-4 ring-primary' : 'ring-1 ring-gray-300');
                wrap.onclick = () => { coverIdx = i; document.getElementById('coverIndex').value=i; renderPreview(); };
                const img = document.createElement('img');
                img.src = URL.createObjectURL(f);
                img.className = 'w-full h-24 object-cover';
                wrap.appendChild(img);
                if (i===coverIdx) {
                    const tag = document.createElement('span');
                    tag.className = 'absolute top-1 right-1 bg-primary text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full';
                    tag.textContent = '⭐ غلاف';
                    wrap.appendChild(tag);
                }
                prev.appendChild(wrap);
            });
        }
        document.getElementById('imgInput').addEventListener('change', (e) => {
            const err = document.getElementById('imgError'); err.textContent=''; coverIdx = 0; document.getElementById('coverIndex').value=0;
            const files = Array.from(e.target.files || []);
            if (files.length > 10) { err.textContent = 'الحد الأقصى 10 صور'; e.target.value=''; selectedFiles=[]; renderPreview(); return; }
            for (const f of files) {
                if (!ALLOWED.includes(f.type)) { err.textContent = 'نوع الملف غير مسموح: '+f.name; e.target.value=''; selectedFiles=[]; renderPreview(); return; }
                if (f.size > MAX_MB*1024*1024) { err.textContent = `${f.name} أكبر من ${MAX_MB}MB`; e.target.value=''; selectedFiles=[]; renderPreview(); return; }
            }
            selectedFiles = files;
            renderPreview();
        });
        </script>
        <button id="adSubmit" class="w-full bg-primary text-white py-3 rounded-lg font-bold">نشر الإعلان</button>
    </form>
</div>

{{-- Back-button guard only. Submission is handled exclusively by
     /assets/bgsync-client.js (single source of truth) to avoid the
     double-submit + stuck "قيد النشر" bug. --}}
<script>
(function(){
    window.addEventListener('pageshow', (e) => {
        if (e.persisted) { location.replace('/'); }
    });
    const form = document.getElementById('postForm');
    const btn  = document.getElementById('adSubmit');
    if (!form || !btn) return;
    form.addEventListener('submit', () => {
        btn.disabled = true; btn.textContent = 'جاري النشر…';
    }, false);
})();
</script>
@endsection
