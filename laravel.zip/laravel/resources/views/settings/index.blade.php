@extends('layouts.app')
@section('title', 'الإعدادات')
@section('content')
<h1 class="text-xl font-bold mb-4">⚙ الإعدادات</h1>

<div class="space-y-3 max-w-lg">
    {{-- Profile shortcut --}}
    <a href="{{ route('profile.show') }}" class="flex items-center gap-3 bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <div class="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold text-lg">
            {{ mb_substr(auth()->user()->username ?? 'م', 0, 1) }}
        </div>
        <div class="flex-1">
            <div class="font-bold">{{ auth()->user()->full_name ?? auth()->user()->username }}</div>
            <div class="text-xs text-gray-500">عرض وتعديل الحساب</div>
        </div>
        <span class="text-gray-400">‹</span>
    </a>

    {{-- Wallet hero card --}}
    @php
        $__wallet = auth()->user()->walletOrCreate();
    @endphp
    <a href="{{ route('wallet.show') }}"
       class="relative overflow-hidden rounded-2xl shadow-lg text-white p-4 flex items-center gap-4"
       style="background: linear-gradient(135deg, #16a34a 0%, #15803d 60%, #0f766e 100%);">
        <div class="text-4xl">💳</div>
        <div class="flex-1">
            <div class="text-xs opacity-80">محفظتي</div>
            <div class="text-2xl font-extrabold leading-tight">
                {{ number_format((float) $__wallet->balance, 2) }}
                <span class="text-xs font-bold opacity-80">{{ $__wallet->currency }}</span>
            </div>
            <div class="text-xs opacity-80 mt-1">تمييز إعلاناتك وشحن الرصيد</div>
        </div>
        <span class="text-white/80">‹</span>
    </a>

    <a href="{{ route('privacy.show') }}" class="flex items-center justify-between bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <span>🔒 سياسة الخصوصية</span>
        <span class="text-gray-400">‹</span>
    </a>


    {{-- View mode (moved here, removed from home) --}}
    <form action="{{ route('settings.viewMode') }}" method="POST" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        @csrf
        <div class="font-semibold mb-2">🗂 عرض الصفحة الرئيسية</div>
        <div class="grid grid-cols-2 gap-2">
            <label class="cursor-pointer border-2 rounded-lg p-3 text-center {{ $user->feed_view_mode === 'grid' ? 'border-primary' : 'border-transparent' }}">
                <input type="radio" name="feed_view_mode" value="grid" class="hidden" {{ $user->feed_view_mode === 'grid' ? 'checked' : '' }} onchange="this.form.submit()">
                <div class="text-2xl mb-1">▦▦</div>
                <div class="text-sm">عمودين</div>
            </label>
            <label class="cursor-pointer border-2 rounded-lg p-3 text-center {{ $user->feed_view_mode === 'single' ? 'border-primary' : 'border-transparent' }}">
                <input type="radio" name="feed_view_mode" value="single" class="hidden" {{ $user->feed_view_mode === 'single' ? 'checked' : '' }} onchange="this.form.submit()">
                <div class="text-2xl mb-1">▭</div>
                <div class="text-sm">عمود واحد</div>
            </label>
        </div>
    </form>

    <a href="{{ route('settings.notifications') }}" class="flex items-center justify-between bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <span>🔔 إعدادات الإشعارات</span>
        <span class="text-gray-400">‹</span>
    </a>


    <a href="{{ route('notifications.index') }}" class="flex items-center justify-between bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <span>📥 صندوق الإشعارات</span>
        <span class="text-gray-400">‹</span>
    </a>

    <form action="{{ route('settings.theme') }}" method="POST" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow flex items-center justify-between">
        @csrf
        <span>🎨 الوضع: {{ session('theme', 'light') === 'dark' ? 'ليلي 🌙' : 'نهاري ☀' }}</span>
        <button class="px-4 py-1 rounded bg-primary text-white text-sm">تبديل</button>
    </form>

    @auth
        @if(auth()->user()->hasRole('admin'))
            <a href="{{ route('admin.dashboard') }}" class="block bg-accent text-white p-4 rounded-xl shadow font-bold text-center">
                🛠 لوحة الإدارة
            </a>
        @endif
    @endauth

    <a href="https://wa.me/{{ ltrim($supportWhatsapp ?? '+249900000000', '+') }}" target="_blank" rel="noopener"
       class="block bg-green-500 text-white p-4 rounded-xl shadow text-center font-bold">💬 المساعدة (واتساب)</a>

    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow text-xs text-gray-500 text-center">
        {{ $appName ?? 'متجرك' }} — الإصدار 1.0
    </div>

    <form action="{{ route('logout') }}" method="POST" class="block">
        @csrf
        <button class="w-full bg-red-500 text-white p-4 rounded-xl shadow font-bold">🚪 تسجيل الخروج</button>
    </form>
</div>
@endsection
