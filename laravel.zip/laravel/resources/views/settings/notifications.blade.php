@extends('layouts.app')
@section('title', 'إعدادات الإشعارات')
@section('content')
<h1 class="text-xl font-bold mb-4">🔔 إعدادات الإشعارات</h1>
<form action="{{ route('settings.notifications.update') }}" method="POST" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow space-y-4 max-w-lg">
    @csrf
    <label class="flex items-center justify-between">
        <span>تفعيل الإشعارات</span>
        <input type="checkbox" name="notify_enabled" value="1" {{ $user->notify_enabled ? 'checked' : '' }} class="toggle-ltr w-5 h-5">
    </label>
    <div>
        <label class="block text-sm mb-2">نطاق الإشعارات</label>
        <div class="space-y-2">
            <label class="flex items-center gap-2"><input type="radio" name="notify_scope" value="all" {{ $user->notify_scope==='all'?'checked':'' }}> كل الإشعارات</label>
            <label class="flex items-center gap-2"><input type="radio" name="notify_scope" value="interests" {{ $user->notify_scope==='interests'?'checked':'' }}> اهتماماتي فقط</label>
        </div>
    </div>
    <div>
        <label class="block text-sm mb-2">اهتماماتي (الأقسام التي يهمك متابعتها)</label>
        <div class="grid grid-cols-2 gap-2">
            @foreach(\App\Models\Category::where('is_active',true)->orderBy('sort_order')->get() as $cat)
                <label class="flex items-center gap-2 text-sm">
                    <input type="checkbox" name="interest_categories[]" value="{{ $cat->name }}"
                        {{ in_array($cat->name, (array)$user->interest_categories) ? 'checked' : '' }}>
                    {{ $cat->name }}
                </label>
            @endforeach
        </div>
    </div>
    <button class="bg-primary text-white px-6 py-2 rounded-xl font-bold w-full">حفظ</button>
</form>
@endsection
