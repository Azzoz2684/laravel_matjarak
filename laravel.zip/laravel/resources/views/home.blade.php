@extends('layouts.app')
@section('title', 'الرئيسية - ' . ($appName ?? 'متجرك'))
@section('content')

@php
    $categories = \App\Models\Category::where('is_active', true)->orderBy('sort_order')->get();
    $catNames = $categories->pluck('name')->all();
    if (empty($catNames)) $catNames = ['إلكترونيات','سيارات','عقارات','أثاث','ملابس','هواتف','أخرى'];
    $statesList = \App\Models\StateModel::where('is_active', true)->orderBy('sort_order')->pluck('name')->all();
    if (empty($statesList)) $statesList = ['الخرطوم','الجزيرة','نهر النيل','الشمالية','كسلا'];
    $mode = auth()->check() ? (auth()->user()->feed_view_mode ?? 'grid') : 'grid';
    $gridClasses = $mode === 'single' ? 'space-y-0' : 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3';
    $broadcasts = \App\Models\Broadcast::where('is_active', true)->latest()->limit(20)->get();
    $broadcastItems = $broadcasts->map(function($b) {
        return [
            'id' => $b->id, 'title' => $b->title, 'body' => $b->body,
            'link' => $b->link, 'link_text' => $b->link_text,
            'phone' => $b->contact_phone, 'ctext' => $b->contact_text,
            'image' => $b->image_url,
        ];
    })->values();
@endphp

{{-- PWA Install Prompt — hidden by default; only shown when supported --}}
<div id="pwaInstall" class="hidden mb-4 bg-gradient-to-l from-emerald-500 to-blue-600 text-white rounded-2xl shadow-lg p-4">
    <div class="flex items-start gap-3">
        <div class="text-3xl">📲</div>
        <div class="flex-1">
            <div class="font-extrabold text-base">قم بتثبيت تطبيق متجرك!</div>
            <div class="text-sm text-white/90 mt-0.5">تجربة أسرع، إشعارات فورية، وعمل بدون انترنت.</div>
            <div class="mt-3 flex flex-wrap gap-2">
                <button id="pwaInstallBtn" type="button" class="hidden bg-white text-emerald-700 font-bold text-sm px-4 py-2 rounded-full shadow">📥 تثبيت التطبيق</button>
                <button id="pwaHowBtn" type="button" class="hidden bg-white/20 text-white text-sm px-4 py-2 rounded-full">طريقة التثبيت على iPhone</button>
                <button id="pwaDismiss" type="button" class="bg-white/10 text-white/80 text-xs px-3 py-2 rounded-full">لاحقاً</button>
            </div>
        </div>
    </div>
    <div id="pwaHowBox" class="hidden mt-3 text-xs bg-black/20 p-3 rounded-xl leading-relaxed">
        <b>Safari (iPhone / iPad):</b> اضغط زر المشاركة <span dir="ltr">⬆</span> ثم اختر "إضافة إلى الشاشة الرئيسية".
    </div>
</div>

{{-- Broadcast queue: one card at a time (live-updated via /broadcasts/feed) --}}
<div id="bcContainer" class="mb-4" data-items='{{ $broadcastItems->toJson(JSON_UNESCAPED_UNICODE) }}'>
    {{-- Single card injected by JS --}}
</div>


{{-- Search bar --}}
<form action="{{ route('home') }}" method="GET" class="mb-3 flex flex-row items-center gap-2">
    <div class="flex-1 relative">
        <span class="absolute top-1/2 -translate-y-1/2 right-3 text-gray-400">🔍</span>
        <input type="text" name="q" value="{{ request('q') }}" placeholder="ابحث عن منتج..."
               class="w-full pr-9 pl-4 py-2.5 rounded-full bg-white dark:bg-gray-800 text-sm border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary/40">
    </div>
    <select name="state" class="px-3 py-2.5 rounded-full bg-white dark:bg-gray-800 text-sm border border-gray-200 dark:border-gray-700 max-w-[35%]">
        <option value="">الولاية</option>
        @foreach($statesList as $s)
            <option value="{{ $s }}" {{ request('state')===$s?'selected':'' }}>{{ $s }}</option>
        @endforeach
    </select>
    @if(request('category'))<input type="hidden" name="category" value="{{ request('category') }}">@endif
    <button class="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-full text-sm font-bold shrink-0 shadow">بحث</button>
</form>

<div class="flex gap-2 overflow-x-auto pb-2 mb-4 -mx-4 px-4">
    <a href="{{ route('home') }}" class="shrink-0 px-3 py-1.5 rounded-full text-sm {{ !request('category') ? 'bg-primary text-white' : 'bg-white dark:bg-gray-800' }}">الكل</a>
    @foreach($categories as $cat)
        <a href="{{ route('home', ['category' => $cat->name]) }}"
           class="shrink-0 px-3 py-1.5 rounded-full text-sm {{ request('category') === $cat->name ? 'bg-primary text-white' : 'bg-white dark:bg-gray-800' }}">
           {{ $cat->icon ? $cat->icon.' ' : '' }}{{ $cat->name }}
        </a>
    @endforeach
</div>

@if($featured->count())
<section class="mb-6">
    <h2 class="text-lg font-bold mb-3">⭐ إعلانات مميزة</h2>
    <div class="flex gap-3 overflow-x-auto -mx-4 px-4 pb-2">
        @foreach($featured as $p)
            <a href="{{ route('posts.show', $p) }}" class="shrink-0 w-40 bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow">
                <img src="{{ $p->firstImage() }}" alt="{{ $p->title }}" class="w-full h-32 object-cover" loading="lazy">
                <div class="p-2">
                    <div class="text-sm font-semibold truncate">{{ $p->title }}</div>
                    <div class="text-primary text-sm font-bold">{{ $p->priceArabic() }}</div>
                </div>
            </a>
        @endforeach
    </div>
</section>
@endif

<h2 class="text-lg font-bold mb-3">أحدث الإعلانات</h2>
<div class="{{ $gridClasses }}">
    @forelse($posts as $post)
        @include('partials.post_card', ['post' => $post, 'mode' => $mode])
    @empty
        <div class="col-span-full text-center py-10 text-gray-500">لا توجد إعلانات</div>
    @endforelse
</div>

<div class="mt-6">{{ $posts->links() }}</div>

<script>
// ==== Broadcast Queue (one at a time, dismissed-IDs persisted) ====
//      + Live polling /broadcasts/feed every 20s and on Web Push receive
//      so admin messages appear instantly without waiting for a page reload.
(function(){
    const container = document.getElementById('bcContainer');
    if (!container) return;
    let items = [];
    try { items = JSON.parse(container.dataset.items || '[]'); } catch(e){ items = []; }
    const seenKey = 'matjarak_bc_seen';
    let seen = [];
    try { seen = JSON.parse(localStorage.getItem(seenKey) || '[]'); } catch(e){ seen = []; }
    let queue = items.filter(it => !seen.includes(it.id));
    let lastSignature = items.map(i => i.id + ':' + (i.updated||'')).join('|');

    function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

    function render(){
        if (!queue.length) { container.innerHTML=''; return; }
        const it = queue[0];
        const waUrl = it.phone ? `https://wa.me/${String(it.phone).replace(/[^\d]/g,'')}` : '';
        container.innerHTML = `
        <div class="bg-gradient-to-l from-primary to-emerald-600 text-white rounded-2xl shadow-lg overflow-hidden transition-all duration-300">
            ${it.image ? `<img src="${it.image}" alt="" class="w-full h-40 object-cover">` : ''}
            <div class="p-4">
                <div class="flex items-center gap-2 mb-1 text-white/90 text-xs">📣 رسالة من إدارة متجرك</div>
                <h3 class="font-extrabold text-lg leading-snug">${escapeHtml(it.title || '')}</h3>
                <p class="text-sm mt-1 leading-relaxed whitespace-pre-wrap">${escapeHtml(it.body || '')}</p>
                <div class="mt-3 flex flex-wrap gap-2">
                    <button type="button" data-act="ok" class="bg-white text-primary font-bold text-sm px-4 py-2 rounded-full">✓ موافق</button>
                    ${it.link ? `<a href="${it.link}" target="_blank" rel="noopener" class="bg-white/20 text-white font-bold text-sm px-4 py-2 rounded-full">🔗 ${escapeHtml(it.link_text || 'فتح الرابط')}</a>` : ''}
                    ${waUrl ? `<a href="${waUrl}" target="_blank" rel="noopener" class="bg-green-500 text-white font-bold text-sm px-4 py-2 rounded-full">💬 ${escapeHtml(it.ctext || 'تواصل واتساب')}</a>` : ''}
                </div>
            </div>
        </div>`;
        container.querySelector('[data-act="ok"]').addEventListener('click', () => {
            seen.push(it.id);
            try { localStorage.setItem(seenKey, JSON.stringify(seen)); } catch(e){}
            queue.shift();
            container.firstElementChild.style.opacity = '0';
            container.firstElementChild.style.transform = 'translateY(-10px)';
            setTimeout(render, 280);
        });
    }

    async function refresh(){
        try {
            const r = await fetch('/broadcasts/feed', { credentials:'same-origin', cache:'no-store', headers:{'Accept':'application/json'} });
            if (!r.ok) return;
            const j = await r.json();
            const fresh = Array.isArray(j.items) ? j.items : [];
            const sig = fresh.map(i => i.id + ':' + (i.updated||'')).join('|');
            if (sig === lastSignature) return; // nothing changed
            lastSignature = sig;
            items = fresh;
            // refresh seen filter; if first visible card differs, re-render
            const newQueue = items.filter(it => !seen.includes(it.id));
            const firstChanged = (queue[0] && queue[0].id) !== (newQueue[0] && newQueue[0].id);
            queue = newQueue;
            if (firstChanged || !container.firstElementChild) render();
        } catch(e){}
    }

    render();
    // Initial async refresh in case the server-side snapshot is stale
    refresh();
    // Poll every 20 seconds
    setInterval(refresh, 20000);
    // Refresh whenever the tab becomes visible again
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
    // Refresh instantly when a Web Push arrives (Service Worker forwards it)
    window.addEventListener('matjarak:push', refresh);
})();

// ==== PWA Install (interactive + OS-aware) ====

(function(){
    const box = document.getElementById('pwaInstall');
    const btn = document.getElementById('pwaInstallBtn');
    const howBtn = document.getElementById('pwaHowBtn');
    const howBox = document.getElementById('pwaHowBox');
    const dismiss = document.getElementById('pwaDismiss');
    if (!box) return;

    // Already installed?
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    if (isStandalone) return;

    // Recently dismissed?
    try {
        const until = parseInt(localStorage.getItem('pwa_dismiss_until') || '0', 10);
        if (Date.now() < until) return;
    } catch(e){}

    // OS detection — iOS Safari does NOT support beforeinstallprompt
    const ua = navigator.userAgent || '';
    const isIOS = /iPad|iPhone|iPod/.test(ua) && !window.MSStream;

    if (isIOS) {
        // iOS → show manual instructions only
        howBtn.classList.remove('hidden');
        howBox.classList.remove('hidden');
        box.classList.remove('hidden');
        howBtn.addEventListener('click', () => howBox.classList.toggle('hidden'));
    } else {
        // Android / Chrome / Edge / Windows → wait for the native prompt event
        let deferred = null;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferred = e;
            btn.classList.remove('hidden');
            box.classList.remove('hidden');
        });
        btn.addEventListener('click', async () => {
            if (!deferred) return;
            try {
                deferred.prompt();
                const { outcome } = await deferred.userChoice;
                if (outcome === 'accepted' && window.toastFlash) toastFlash('جارٍ التثبيت…');
            } catch(e){}
            deferred = null;
            btn.classList.add('hidden');
        });
    }

    dismiss && dismiss.addEventListener('click', () => {
        try { localStorage.setItem('pwa_dismiss_until', String(Date.now() + 7*24*3600*1000)); } catch(e){}
        box.classList.add('hidden');
    });

    // Hide entirely on successful install
    window.addEventListener('appinstalled', () => {
        box.classList.add('hidden');
        if (window.toastFlash) toastFlash('تم تثبيت التطبيق بنجاح ✅');
    });
})();
</script>
@endsection
