<!DOCTYPE html>
<html lang="ar" dir="rtl" class="{{ session('theme', 'light') === 'dark' ? 'dark' : '' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5, user-scalable=yes">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', $appName ?? 'متجرك')</title>
    <meta name="description" content="@yield('description', 'متجرك — سوق إلكتروني سوداني لبيع وشراء كل ما تحتاج: سيارات، إلكترونيات، عقارات، أثاث وأكثر.')">
    <meta name="theme-color" content="#16a34a">
    <link rel="manifest" href="/manifest.webmanifest">
    <link rel="apple-touch-icon" href="/assets/icon-192.png">
    <link rel="icon" type="image/png" href="/assets/logo.png">
    <link rel="shortcut icon" href="/assets/logo.png">
    {{-- Default Open Graph (per-page can override via @push('head')) --}}
    <meta property="og:site_name" content="{{ $appName ?? 'متجرك' }}">
    <meta property="og:type" content="website">
    <meta property="og:title" content="@yield('title', $appName ?? 'متجرك')">
    <meta property="og:description" content="@yield('description', 'متجرك — سوق إلكتروني سوداني')">
    <meta property="og:image" content="{{ url('/assets/logo.png') }}">
    <meta name="twitter:card" content="summary_large_image">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    @stack('head')
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: { extend: {
                fontFamily: { sans: ['Cairo', 'system-ui', 'sans-serif'] },
                colors: {
                    primary: { DEFAULT: '#16a34a', dark: '#15803d' },
                    accent:  { DEFAULT: '#2563eb' },
                }
            }}
        }
    </script>
    <style>
        body { font-family: 'Cairo', sans-serif; }
        .toggle-ltr { direction: ltr; }
        .modal-backdrop { background: rgba(0,0,0,0.5); }
        /* Smooth page transitions */
        @keyframes pageIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        main { animation: pageIn .28s ease-out both; }
        @media (prefers-reduced-motion: reduce){ main { animation: none; } }
        @view-transition { navigation: auto; }
        ::view-transition-old(root){ animation: pageIn .25s reverse ease-in both; }
        ::view-transition-new(root){ animation: pageIn .25s ease-out both; }
    </style>
</head>
@php $__hideNav = trim($__env->yieldContent('no_bottom_nav')) === '1'; @endphp
<body class="bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen {{ $__hideNav ? 'pb-6' : 'pb-20' }}">

@include('partials.header')

@if (session('success'))
    <div class="max-w-5xl mx-auto px-4 mt-4 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 p-3 rounded-lg text-sm">
        {{ session('success') }}
    </div>
@endif
@if ($errors->any())
    <div class="max-w-5xl mx-auto px-4 mt-4 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 p-3 rounded-lg text-sm">
        @foreach ($errors->all() as $e)<div>{{ $e }}</div>@endforeach
    </div>
@endif

{{-- Play Store install banner (Android only, hidden inside TWA / once dismissed) --}}
<div id="playInstallBanner" class="hidden fixed bottom-24 inset-x-2 z-40 bg-white dark:bg-gray-800 border border-primary/30 shadow-lg rounded-2xl p-3 flex items-center gap-3">
    <img src="/assets/logo.png" class="w-10 h-10 rounded-lg" alt="">
    <div class="flex-1 min-w-0">
        <div class="text-sm font-bold">حمّل تطبيق متجرك</div>
        <div class="text-[11px] text-gray-500">تجربة أسرع وأفضل من Google Play</div>
    </div>
    <a href="https://play.google.com/store/apps/details?id=com.storxsudai.matjaruk"
       target="_blank" rel="noopener"
       class="bg-primary text-white text-xs font-bold px-3 py-2 rounded-lg whitespace-nowrap">تثبيت</a>
    <button id="playInstallDismiss" aria-label="إغلاق" class="text-gray-400 text-xl px-1">×</button>
</div>
<script>
(function(){
    try {
        var ua = navigator.userAgent || '';
        var isAndroid = /Android/i.test(ua);
        var isTWA = document.referrer.startsWith('android-app://com.storxsudai.matjaruk')
                 || /; wv\)/.test(ua) // WebView from TWA
                 || sessionStorage.getItem('isTWA') === '1';
        if (document.referrer.startsWith('android-app://com.storxsudai.matjaruk')) sessionStorage.setItem('isTWA','1');
        var dismissed = localStorage.getItem('playInstallDismissed') === '1';
        if (isAndroid && !isTWA && !dismissed) {
            var el = document.getElementById('playInstallBanner');
            if (el) el.classList.remove('hidden');
        }
        document.getElementById('playInstallDismiss')?.addEventListener('click', function(){
            localStorage.setItem('playInstallDismissed','1');
            document.getElementById('playInstallBanner')?.classList.add('hidden');
        });
    } catch(e){}
})();
</script>

<main class="max-w-5xl mx-auto px-4 py-4">
    @yield('content')
</main>


@if(!$__hideNav)
    @include('partials.bottom_nav')
@endif

{{-- Report Modal --}}
<div id="reportModal" class="fixed inset-0 hidden items-center justify-center z-50 modal-backdrop">
    <div class="bg-white dark:bg-gray-800 rounded-2xl w-11/12 max-w-md p-5 shadow-xl">
        <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-lg">🚩 الإبلاغ عن المنشور</h3>
            <button onclick="closeReport()" class="text-2xl text-gray-500">×</button>
        </div>
        <p class="text-sm text-gray-500 mb-3">يرجى توضيح سبب الإبلاغ وسنراجعه بأسرع وقت.</p>
        <textarea id="reportReason" rows="4" maxlength="500" placeholder="اكتب تفاصيل البلاغ هنا..."
                  class="w-full p-3 rounded-lg bg-gray-100 dark:bg-gray-700 text-sm"></textarea>
        <div class="flex gap-2 mt-4">
            <button onclick="submitReport()" class="flex-1 bg-red-500 text-white py-2 rounded-lg font-bold">إرسال البلاغ</button>
            <button onclick="closeReport()" class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700">إلغاء</button>
        </div>
    </div>
</div>

<script>
    const csrf = document.querySelector('meta[name="csrf-token"]').content;
    async function postAction(url) {
        const res = await fetch(url, { method: 'POST', headers: { 'X-CSRF-TOKEN': csrf, 'Accept': 'application/json' } });
        return res.json().catch(() => ({}));
    }
    async function toggleLike(btn, postId) {
        const data = await postAction(`/posts/${postId}/like`);
        if (data.liked !== undefined) {
            btn.classList.toggle('text-red-500', data.liked);
            btn.classList.toggle('text-gray-400', !data.liked);
            btn.classList.toggle('text-gray-500', !data.liked);
            const c = btn.querySelector('.count'); if (c) c.textContent = data.likes_count;
            const h = btn.querySelector('.heart'); if (h) h.textContent = data.liked ? '❤️' : '🤍';
            if (data.liked && window.toastFlash) toastFlash('تم الإعجاب ❤️');
        }
    }
    window.toastFlash = function(msg){
        const t = document.createElement('div');
        t.textContent = msg;
        t.className = 'fixed bottom-24 inset-x-0 mx-auto w-fit bg-black/80 text-white text-sm px-4 py-2 rounded-full z-50';
        document.body.appendChild(t); setTimeout(()=>t.remove(), 1800);
    };

    // Report modal
    let _reportPostId = null;
    window.openReport = function(postId){ _reportPostId = postId; document.getElementById('reportReason').value=''; document.getElementById('reportModal').classList.remove('hidden'); document.getElementById('reportModal').classList.add('flex'); };
    window.closeReport = function(){ document.getElementById('reportModal').classList.add('hidden'); document.getElementById('reportModal').classList.remove('flex'); };
    window.submitReport = async function(){
        const reason = document.getElementById('reportReason').value.trim();
        if(!reason){ alert('اكتب سبب البلاغ'); return; }
        const res = await fetch(`/posts/${_reportPostId}/report`,{
            method:'POST',
            headers:{'X-CSRF-TOKEN':csrf,'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},
            body:'reason='+encodeURIComponent(reason)
        });
        if(res.ok){ closeReport(); toastFlash('تم إرسال البلاغ، شكراً لك ✅'); }
        else toastFlash('تعذر إرسال البلاغ');
    };

    function shareUrl(url, title){
        if (navigator.share) { navigator.share({title, url}).catch(()=>{}); }
        else { navigator.clipboard?.writeText(url); toastFlash('تم نسخ الرابط'); }
    }
    window.sharePost = shareUrl;

    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js').then(reg => {
                if (reg.waiting) reg.waiting.postMessage('SKIP_WAITING');
                // Request a periodic sync if the browser supports it (Chrome).
                if ('periodicSync' in reg) {
                    navigator.permissions.query({ name: 'periodic-background-sync' }).then(p => {
                        if (p.state === 'granted') {
                            reg.periodicSync.register('matjarak-post-queue', { minInterval: 15*60*1000 }).catch(()=>{});
                        }
                    }).catch(()=>{});
                }
            }).catch(()=>{});
        });
    }

    // Background Sync client (queues post submissions + replays in SW)
    (function(){
        const s = document.createElement('script');
        s.src = '/assets/bgsync-client.js';
        s.defer = true;
        document.head.appendChild(s);
    })();


    // ===== Scroll position preservation across full reloads =====
    (function(){
        try {
            const KEY = 'scrollY:' + location.pathname + location.search;
            const saved = parseInt(sessionStorage.getItem(KEY) || '0', 10);
            if (saved > 0) {
                // wait for layout
                requestAnimationFrame(() => window.scrollTo(0, saved));
                setTimeout(() => window.scrollTo(0, saved), 120);
                sessionStorage.removeItem(KEY);
            }
            window.addEventListener('beforeunload', () => {
                sessionStorage.setItem(KEY, String(window.scrollY|0));
            });
        } catch(e){}
    })();

    // ===== Web Push subscription (no Firebase) =====
    @auth
    (function(){
        if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
        function urlBase64ToUint8Array(b64){
            const pad = '='.repeat((4 - b64.length % 4) % 4);
            const s = (b64 + pad).replace(/-/g,'+').replace(/_/g,'/');
            const raw = atob(s); const out = new Uint8Array(raw.length);
            for (let i=0;i<raw.length;i++) out[i] = raw.charCodeAt(i);
            return out;
        }
        async function trySubscribe(){
            try {
                if (Notification.permission === 'denied') return;
                if (Notification.permission === 'default') {
                    const p = await Notification.requestPermission();
                    if (p !== 'granted') return;
                }
                const keyRes = await fetch('/push/vapid-key').then(r=>r.json()).catch(()=>null);
                if (!keyRes || !keyRes.key) return; // server not configured yet
                const reg = await navigator.serviceWorker.ready;
                let sub = await reg.pushManager.getSubscription();
                if (!sub) {
                    sub = await reg.pushManager.subscribe({
                        userVisibleOnly: true,
                        applicationServerKey: urlBase64ToUint8Array(keyRes.key),
                    });
                }
                const j = sub.toJSON();
                await fetch('/push/subscribe', {
                    method:'POST',
                    headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Accept':'application/json'},
                    body: JSON.stringify({ endpoint: j.endpoint, keys: j.keys })
                });
            } catch(e){}
        }
        // Subscribe on first user interaction (required by browsers)
        const fire = () => { document.removeEventListener('click', fire); document.removeEventListener('touchstart', fire); trySubscribe(); };
        if (Notification.permission === 'granted') trySubscribe();
        else { document.addEventListener('click', fire, { once:true }); document.addEventListener('touchstart', fire, { once:true }); }
    })();
    @endauth

</script>

</body>
</html>
