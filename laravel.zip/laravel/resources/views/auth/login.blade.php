@extends('layouts.app')
@section('title', 'تسجيل الدخول')
@section('content')
<div class="max-w-sm mx-auto bg-white dark:bg-gray-800 p-6 rounded-xl shadow mt-10">
    <h1 class="text-xl font-bold mb-4 text-center">تسجيل الدخول</h1>

    <a href="{{ route('auth.google') }}"
       class="w-full flex items-center justify-center gap-2 bg-white border border-gray-300 dark:border-gray-600 text-gray-800 dark:text-gray-100 py-2.5 rounded-lg font-bold mb-4 hover:bg-gray-50 dark:hover:bg-gray-700">
        <svg viewBox="0 0 24 24" width="20" height="20"><path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.44c-.28 1.48-1.12 2.73-2.39 3.58v2.96h3.86c2.26-2.08 3.58-5.15 3.58-8.78z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-2.96c-1.07.72-2.44 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.11C3.26 21.3 7.31 24 12 24z"/><path fill="#FBBC05" d="M5.27 14.33c-.24-.72-.38-1.49-.38-2.33s.14-1.61.38-2.33V6.56H1.29C.47 8.18 0 10.03 0 12s.47 3.82 1.29 5.44l3.98-3.11z"/><path fill="#EA4335" d="M12 4.77c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.56l3.98 3.11C6.22 6.88 8.87 4.77 12 4.77z"/></svg>
        تسجيل الدخول عبر جوجل
    </a>
    <div class="flex items-center gap-2 my-3 text-xs text-gray-400">
        <div class="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
        <span>أو</span>
        <div class="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
    </div>

    <form action="{{ route('login') }}" method="POST" class="space-y-3">
        @csrf
        <div>
            <label class="text-sm font-semibold block mb-1">رقم الهاتف</label>
            <input name="phone" required dir="ltr" inputmode="tel" placeholder="+249..." class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">كلمة المرور</label>
            <div class="relative">
                <input id="pw" name="password" type="password" required dir="ltr"
                       class="w-full p-2 pl-10 rounded bg-gray-100 dark:bg-gray-700">
                <button type="button" id="pwToggle" aria-label="إظهار كلمة المرور"
                        class="absolute inset-y-0 left-2 my-auto text-gray-500 text-lg">👁</button>
            </div>
        </div>
        <input type="hidden" name="remember" value="1">
        <p class="text-xs text-gray-500">سيبقى تسجيل الدخول فعّالاً تلقائياً على هذا الجهاز.</p>
        <button class="w-full bg-primary text-white py-2 rounded-lg font-bold">دخول</button>
        <a href="{{ route('register') }}" class="block text-center text-sm text-accent">ليس لديك حساب؟ سجّل الآن</a>
    </form>
</div>
<script>
(function(){
    const pw = document.getElementById('pw');
    const btn = document.getElementById('pwToggle');
    btn?.addEventListener('click', () => {
        const shown = pw.type === 'text';
        pw.type = shown ? 'password' : 'text';
        btn.textContent = shown ? '👁' : '🙈';
    });
})();
</script>
@endsection
