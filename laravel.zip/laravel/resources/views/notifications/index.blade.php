@extends('layouts.app')
@section('title', 'الإشعارات')
@section('content')
<div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-bold">🔔 الإشعارات</h1>
    <div class="flex gap-3">
        <a href="{{ route('settings.notifications') }}" class="text-sm text-accent">⚙ الإعدادات</a>
        <button onclick="markAllAjax()" class="text-sm text-accent">تعليم الكل كمقروء</button>
    </div>
</div>

@php $cats = \App\Models\Category::where('is_active',true)->orderBy('sort_order')->pluck('name'); @endphp

<div class="bg-white dark:bg-gray-800 p-3 rounded-xl mb-3 grid grid-cols-3 gap-2">
    <select id="f-filter" class="text-sm p-2 rounded bg-gray-100 dark:bg-gray-700">
        <option value="all">الكل</option>
        <option value="unread">غير مقروء</option>
        <option value="read">مقروء</option>
    </select>
    <select id="f-sort" class="text-sm p-2 rounded bg-gray-100 dark:bg-gray-700">
        <option value="desc">الأحدث</option>
        <option value="asc">الأقدم</option>
    </select>
    <select id="f-cat" class="text-sm p-2 rounded bg-gray-100 dark:bg-gray-700">
        <option value="">كل الأقسام</option>
        @foreach($cats as $c)<option value="{{ $c }}">{{ $c }}</option>@endforeach
    </select>
</div>

<div id="notif-list" class="space-y-2"></div>
<div id="notif-empty" class="text-center py-10 text-gray-500 hidden">لا توجد إشعارات</div>

<script>
const $f = id => document.getElementById(id);
['f-filter','f-sort','f-cat'].forEach(id => $f(id).addEventListener('change', loadNotifs));

async function loadNotifs(){
    const p = new URLSearchParams({filter:$f('f-filter').value, sort:$f('f-sort').value, category:$f('f-cat').value});
    const r = await fetch('/notifications/feed?'+p.toString(), {headers:{'Accept':'application/json'}});
    const {items} = await r.json();
    const root = $f('notif-list');
    $f('notif-empty').classList.toggle('hidden', items.length > 0);
    root.innerHTML = items.map(n => {
        const href = n.link || (n.post_id ? `/posts/${n.post_id}` : null);
        const inner = `
            <div class="flex-1">
                <div class="font-semibold">${escapeHtml(n.title||'')}</div>
                <div class="text-sm text-gray-600 dark:text-gray-300">${escapeHtml(n.body||'')}</div>
                <div class="text-xs text-gray-400 mt-1">${new Date(n.created_at).toLocaleString('ar')}</div>
            </div>
            <div class="flex flex-col gap-1 shrink-0">
                ${!n.is_read?`<button onclick="event.stopPropagation();event.preventDefault();markRead(${n.id})" class="text-xs text-primary">✓</button>`:''}
                <button onclick="event.stopPropagation();event.preventDefault();delNotif(${n.id})" class="text-xs text-red-500">×</button>
            </div>`;
        const cls = `bg-white dark:bg-gray-800 p-3 rounded-lg shadow flex items-start justify-between gap-3 ${n.is_read?'opacity-60':''}`;
        if (href) return `<a href="${href}" onclick="markRead(${n.id})" data-id="${n.id}" class="${cls} block hover:bg-gray-50 dark:hover:bg-gray-700">${inner}</a>`;
        return `<div class="${cls}" data-id="${n.id}">${inner}</div>`;
    }).join('');
}
function escapeHtml(s){return (s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function markRead(id){ await fetch(`/notifications/${id}/read`, {method:'POST', headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json'}}); loadNotifs(); }
async function delNotif(id){ await fetch(`/notifications/${id}`, {method:'POST', headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json','X-HTTP-Method-Override':'DELETE'}}); loadNotifs(); }
async function markAllAjax(){ await fetch('/notifications/read-all', {method:'POST', headers:{'X-CSRF-TOKEN':csrf,'Accept':'application/json'}}); loadNotifs(); }
loadNotifs(); setInterval(loadNotifs, 30000);
</script>
@endsection
