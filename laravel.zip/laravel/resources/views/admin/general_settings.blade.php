@extends('layouts.app')
@section('title', 'الإعدادات العامة')
@section('content')
<h1 class="text-xl font-bold mb-4">⚙ الإعدادات العامة</h1>
<form id="gsForm" action="{{ route('admin.general.update') }}" method="POST" class="bg-white dark:bg-gray-800 rounded-xl p-5 shadow space-y-4 max-w-xl">
    @csrf
    <div>
        <label class="text-sm font-semibold block mb-1">اسم التطبيق</label>
        <input name="app_name" required value="{{ $app_name }}" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
    </div>
    <div>
        <label class="text-sm font-semibold block mb-1">رقم واتساب الدعم</label>
        <input name="support_whatsapp" required value="{{ $support_whatsapp }}" placeholder="+249..."
               class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700 toggle-ltr">
        <div class="text-xs text-gray-500 mt-1">يستخدم في زر "المساعدة" في حساب المستخدمين والإعدادات.</div>
    </div>
    <div class="flex items-center gap-3">
        <button id="gsSubmit" class="bg-primary text-white px-6 py-2 rounded-lg font-bold">💾 حفظ</button>
        <span id="gsStatus" class="text-sm text-gray-500"></span>
    </div>
</form>
<script>
(function(){
    const f = document.getElementById('gsForm');
    const b = document.getElementById('gsSubmit');
    const s = document.getElementById('gsStatus');
    f.addEventListener('submit', async (e) => {
        e.preventDefault();
        b.disabled = true; s.textContent = 'جاري الحفظ…';
        const fd = new FormData(f);
        try {
            const r = await fetch(f.action, {
                method:'POST', body: fd, credentials:'same-origin',
                headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}
            });
            if (!r.ok) throw new Error();
            s.textContent = '✅ تم الحفظ'; s.classList.remove('text-red-500'); s.classList.add('text-green-600');
            window.toastFlash && toastFlash('تم حفظ الإعدادات');
        } catch(_) {
            s.textContent = '⚠ فشل الحفظ'; s.classList.add('text-red-500');
        } finally { b.disabled = false; setTimeout(()=> s.textContent='', 2500); }
    });
})();
</script>
@endsection
