@extends('layouts.app')
@section('title', 'لوحة الإدارة')
@section('content')
<h1 class="text-xl font-bold mb-4">🛡 لوحة الإدارة</h1>

<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow text-center">
        <div class="text-3xl font-bold text-primary">{{ $stats['users'] }}</div>
        <div class="text-sm text-gray-500">مستخدمون</div>
    </div>
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow text-center">
        <div class="text-3xl font-bold text-accent">{{ $stats['posts'] }}</div>
        <div class="text-sm text-gray-500">إعلانات</div>
    </div>
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow text-center">
        <div class="text-3xl font-bold text-yellow-500">{{ $stats['featured'] }}</div>
        <div class="text-sm text-gray-500">مميزة</div>
    </div>
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow text-center">
        <div class="text-3xl font-bold text-red-500">{{ $stats['pending_reports'] }}</div>
        <div class="text-sm text-gray-500">بلاغات معلقة</div>
    </div>
</div>

<div class="grid grid-cols-2 md:grid-cols-3 gap-3">
    <a href="{{ route('admin.posts') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">📝</div>
        <div class="font-bold">المنشورات</div>
        <div class="text-xs text-gray-500 mt-1">إدارة الإعلانات</div>
    </a>
    <a href="{{ route('admin.broadcasts') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">📣</div>
        <div class="font-bold">الرسائل الجماعية</div>
        <div class="text-xs text-gray-500 mt-1">إرسال إشعارات شاملة</div>
    </a>
    <a href="{{ route('admin.users') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">👥</div>
        <div class="font-bold">المستخدمين</div>
        <div class="text-xs text-gray-500 mt-1">الأدوار والصلاحيات</div>
    </a>
    <a href="{{ route('admin.searchTrends') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">🔎</div>
        <div class="font-bold">تحليلات البحث</div>
        <div class="text-xs text-gray-500 mt-1">اهتمامات المستخدمين</div>
    </a>
    <a href="{{ route('admin.categories') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">🗂</div>
        <div class="font-bold">الأقسام وترتيبها</div>
        <div class="text-xs text-gray-500 mt-1">إدارة الفئات والولايات</div>
    </a>
    <a href="{{ route('admin.reports') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">🚩</div>
        <div class="font-bold">البلاغات</div>
        <div class="text-xs text-gray-500 mt-1">المراجعة والإجراءات</div>
    </a>
    <a href="{{ route('admin.general') }}" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow text-center hover:shadow-lg transition">
        <div class="text-3xl mb-1">⚙</div>
        <div class="font-bold">الإعدادات العامة</div>
        <div class="text-xs text-gray-500 mt-1">رقم الدعم واسم التطبيق</div>
    </a>
</div>
@endsection
