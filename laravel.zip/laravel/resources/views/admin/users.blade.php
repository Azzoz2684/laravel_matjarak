@extends('layouts.app')
@section('title', 'إدارة المستخدمين')
@section('content')
<h1 class="text-xl font-bold mb-4">👥 المستخدمون</h1>
<div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-x-auto">
    <table class="w-full text-sm min-w-[800px]">
        <thead class="bg-gray-100 dark:bg-gray-700">
            <tr>
                <th class="p-3 text-right">المستخدم</th>
                <th class="p-3 text-right">الهاتف</th>
                <th class="p-3 text-right">الولاية</th>
                <th class="p-3 text-right">النبذة</th>
                <th class="p-3 text-right">الأدوار</th>
                <th class="p-3 text-right">تاريخ التسجيل</th>
                <th class="p-3 text-right">تبديل الدور</th>
                <th class="p-3 text-right">إجراءات</th>
            </tr>
        </thead>
        <tbody>
        @foreach($users as $u)
            <tr class="border-t border-gray-100 dark:border-gray-700">
                <td class="p-3">
                    <div class="font-semibold">{{ $u->full_name ?? $u->username }}</div>
                    <div class="text-xs text-gray-400">{{ '@' . $u->username }}</div>
                </td>
                <td class="p-3 toggle-ltr">{{ $u->phone }}</td>
                <td class="p-3">{{ $u->state ?? '—' }}</td>
                <td class="p-3 text-xs max-w-[220px]">
                    <div class="line-clamp-3 text-gray-600 dark:text-gray-300">{{ $u->bio ?: '—' }}</div>
                </td>
                <td class="p-3">
                    @foreach($u->roles as $r)
                        <span class="bg-accent text-white text-xs px-2 py-0.5 rounded">{{ $r->role }}</span>
                    @endforeach
                </td>
                <td class="p-3 text-xs">{{ $u->created_at->diffForHumans() }}</td>
                <td class="p-3">
                    @foreach(['user','seller','admin'] as $role)
                        <form action="{{ route('admin.users.role', $u) }}" method="POST" class="inline">
                            @csrf <input type="hidden" name="role" value="{{ $role }}">
                            <button class="text-xs underline mx-1">{{ $role }}</button>
                        </form>
                    @endforeach
                </td>
                <td class="p-3">
                    @if($u->id !== auth()->id())
                    <form action="{{ route('admin.users.destroy', $u) }}" method="POST" class="inline"
                          onsubmit="return confirm('حذف المستخدم {{ $u->username }} وجميع منشوراته نهائياً؟');">
                        @csrf @method('DELETE')
                        <button class="text-xs bg-red-500 text-white px-3 py-1.5 rounded-lg font-semibold">🗑 حذف</button>
                    </form>
                    @else
                        <span class="text-[11px] text-gray-400">—</span>
                    @endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $users->links() }}</div>
@endsection
