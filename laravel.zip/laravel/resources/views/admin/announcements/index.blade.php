@extends('layouts.app')
@section('title', 'تنبيهات المحفظة')
@section('content')
<div class="max-w-3xl mx-auto">
    <div class="flex items-center justify-between mb-3">
        <h1 class="text-xl font-bold">📢 تنبيهات المحفظة</h1>
        <a href="{{ route('admin.wallets') }}" class="text-sm text-primary">‹ محافظ</a>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow p-4 mb-4">
        <div class="font-bold mb-2">إنشاء تنبيه جديد</div>
        <form action="{{ route('admin.announcements.store') }}" method="POST" class="space-y-2">
            @csrf
            <input type="text" name="title" placeholder="عنوان التنبيه" required maxlength="200" class="w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
            <textarea name="body" rows="3" placeholder="نص الرسالة" required class="w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600"></textarea>
            <div class="grid grid-cols-2 gap-2">
                <select name="level" class="p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
                    <option value="info">معلومة (أزرق)</option>
                    <option value="success">نجاح (أخضر)</option>
                    <option value="warning">تحذير (أصفر)</option>
                    <option value="danger">هام (أحمر)</option>
                </select>
                <label class="flex items-center gap-2 text-sm p-2">
                    <input type="checkbox" name="is_active" value="1" checked> مفعّل
                </label>
            </div>
            <button class="bg-primary text-white font-bold px-4 py-2 rounded-lg">إنشاء التنبيه</button>
        </form>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
        @if($announcements->isEmpty())
            <div class="p-6 text-center text-gray-500">لا توجد تنبيهات.</div>
        @else
            <ul class="divide-y dark:divide-gray-700">
                @foreach($announcements as $a)
                    <li class="p-3 flex items-start justify-between gap-3">
                        <div class="flex-1">
                            <div class="font-bold">{{ $a->title }}
                                <span class="text-xs text-gray-500">({{ $a->level }})</span>
                                @if(!$a->is_active) <span class="text-xs text-red-500">— معطّل</span> @endif
                            </div>
                            <div class="text-sm text-gray-600 dark:text-gray-300 whitespace-pre-line">{{ $a->body }}</div>
                        </div>
                        <div class="flex gap-2">
                            <form action="{{ route('admin.announcements.toggle', $a) }}" method="POST">@csrf
                                <button class="text-xs bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">تفعيل/تعطيل</button>
                            </form>
                            <form action="{{ route('admin.announcements.destroy', $a) }}" method="POST" onsubmit="return confirm('حذف؟')">
                                @csrf @method('DELETE')
                                <button class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">حذف</button>
                            </form>
                        </div>
                    </li>
                @endforeach
            </ul>
        @endif
    </div>
</div>
@endsection
