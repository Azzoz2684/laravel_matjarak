@extends('layouts.app')
@section('title', 'إعدادات المحفظة')
@section('content')
<div class="max-w-lg mx-auto">
    <h1 class="text-xl font-bold mb-4">⚙ إعدادات المحفظة</h1>
    <form action="{{ route('admin.wallets.settings.update') }}" method="POST" class="bg-white dark:bg-gray-800 p-5 rounded-xl shadow space-y-3">
        @csrf
        <label class="block">
            <span class="text-sm font-semibold">مكافأة التسجيل (رصيد ترحيبي)</span>
            <input type="number" step="0.01" min="0" name="wallet_signup_bonus" value="{{ $wallet_signup_bonus }}" class="mt-1 w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
        </label>
        <label class="block">
            <span class="text-sm font-semibold">تكلفة تمييز إعلان</span>
            <input type="number" step="0.01" min="0" name="wallet_feature_cost" value="{{ $wallet_feature_cost }}" class="mt-1 w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
        </label>
        <label class="block">
            <span class="text-sm font-semibold">مدة التمييز (أيام)</span>
            <input type="number" min="1" name="wallet_feature_days" value="{{ $wallet_feature_days }}" class="mt-1 w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
        </label>
        <label class="block">
            <span class="text-sm font-semibold">عملة المحفظة</span>
            <input type="text" maxlength="8" name="wallet_currency" value="{{ $wallet_currency }}" class="mt-1 w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
        </label>
        <label class="block">
            <span class="text-sm font-semibold">رقم واتساب الدعم (بصيغة دولية بدون +)</span>
            <input type="text" name="support_whatsapp" value="{{ $support_whatsapp }}" class="mt-1 w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
        </label>
        <button class="w-full bg-primary text-white font-bold py-2.5 rounded-lg">حفظ الإعدادات</button>
    </form>

    <div class="mt-6 bg-white dark:bg-gray-800 p-5 rounded-xl shadow">
        <h2 class="font-bold mb-2">🔒 سياسة الخصوصية</h2>
        <form action="{{ route('admin.privacy.update') }}" method="POST" class="space-y-3">
            @csrf
            <textarea name="privacy_policy" rows="10" class="w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600 text-sm">{{ $privacy_policy }}</textarea>
            <label class="block">
                <span class="text-sm font-semibold">إصدار السياسة (زيّده لإجبار المستخدمين على القبول من جديد)</span>
                <input type="text" name="privacy_version" value="{{ $privacy_version }}" class="mt-1 w-full p-2 rounded border dark:bg-gray-700 dark:border-gray-600">
            </label>
            <button class="w-full bg-emerald-600 text-white font-bold py-2.5 rounded-lg">حفظ السياسة</button>
        </form>
    </div>
</div>
@endsection
