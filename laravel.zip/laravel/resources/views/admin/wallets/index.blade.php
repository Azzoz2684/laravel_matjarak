@extends('layouts.app')
@section('title', 'المحافظ')
@section('content')
<div class="max-w-5xl mx-auto">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-bold">💳 محافظ المستخدمين</h1>
        <div class="flex gap-2 text-sm">
            <a href="{{ route('admin.wallets.settings') }}" class="bg-gray-200 dark:bg-gray-700 px-3 py-1.5 rounded-lg">⚙ إعدادات المحفظة</a>
            <a href="{{ route('admin.announcements.index') }}" class="bg-gray-200 dark:bg-gray-700 px-3 py-1.5 rounded-lg">📢 التنبيهات</a>
        </div>
    </div>

    <form method="GET" class="mb-3">
        <input type="text" name="q" value="{{ request('q') }}" placeholder="ابحث بالاسم أو رقم الهاتف"
               class="w-full p-2 rounded-lg border dark:bg-gray-800 dark:border-gray-700">
    </form>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gray-100 dark:bg-gray-700">
                <tr>
                    <th class="p-2 text-right">المستخدم</th>
                    <th class="p-2 text-right">الهاتف</th>
                    <th class="p-2 text-right">الرصيد</th>
                    <th class="p-2 text-right">شحن</th>
                    <th class="p-2 text-right">السجل</th>
                </tr>
            </thead>
            <tbody class="divide-y dark:divide-gray-700">
            @foreach($users as $u)
                <tr>
                    <td class="p-2">
                        <div class="font-bold">{{ $u->full_name ?? $u->username }}</div>
                        <div class="text-xs text-gray-500">@{{ $u->username }}</div>
                    </td>
                    <td class="p-2">{{ $u->phone }}</td>
                    <td class="p-2 font-bold">{{ number_format((float) optional($u->wallet)->balance, 2) }}</td>
                    <td class="p-2">
                        <form action="{{ route('admin.wallets.topup', $u) }}" method="POST" class="flex gap-1">
                            @csrf
                            <input type="number" step="0.01" min="0.01" name="amount" placeholder="مبلغ" class="w-24 p-1 rounded border text-xs dark:bg-gray-700 dark:border-gray-600" required>
                            <input type="text" name="note" placeholder="ملاحظة" class="w-32 p-1 rounded border text-xs dark:bg-gray-700 dark:border-gray-600">
                            <button class="bg-primary text-white px-2 py-1 rounded text-xs">+ شحن</button>
                        </form>
                    </td>
                    <td class="p-2"><a href="{{ route('admin.wallets.tx', $u) }}" class="text-primary">عرض</a></td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    <div class="mt-3">{{ $users->links() }}</div>
</div>
@endsection
