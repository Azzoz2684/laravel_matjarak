@extends('layouts.app')
@section('title', 'سجل معاملات المحفظة')
@section('content')
<div class="max-w-3xl mx-auto">
    <div class="flex items-center justify-between mb-3">
        <h1 class="text-xl font-bold">سجل @{{ $user->username }}</h1>
        <a href="{{ route('admin.wallets') }}" class="text-sm text-primary">‹ رجوع</a>
    </div>
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
        @if($transactions->isEmpty())
            <div class="p-6 text-center text-gray-500">لا توجد معاملات.</div>
        @else
            <table class="w-full text-sm">
                <thead class="bg-gray-100 dark:bg-gray-700">
                    <tr><th class="p-2 text-right">التاريخ</th><th class="p-2">النوع</th><th class="p-2">السبب</th><th class="p-2">المبلغ</th><th class="p-2">ملاحظة</th></tr>
                </thead>
                <tbody class="divide-y dark:divide-gray-700">
                    @foreach($transactions as $tx)
                        <tr>
                            <td class="p-2 whitespace-nowrap">{{ $tx->created_at->format('Y-m-d H:i') }}</td>
                            <td class="p-2 text-center">
                                <span class="{{ $tx->type === 'credit' ? 'text-green-600' : 'text-red-600' }} font-bold">
                                    {{ $tx->type === 'credit' ? 'إضافة' : 'خصم' }}
                                </span>
                            </td>
                            <td class="p-2">{{ $tx->reasonArabic() }}</td>
                            <td class="p-2 text-center font-bold">{{ number_format((float) $tx->amount, 2) }}</td>
                            <td class="p-2 text-xs text-gray-500">{{ $tx->note }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
    <div class="mt-3">{{ $transactions->links() }}</div>
</div>
@endsection
