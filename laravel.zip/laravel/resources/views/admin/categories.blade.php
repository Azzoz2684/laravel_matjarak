@extends('layouts.app')
@section('title', 'الأقسام والولايات')
@section('content')
<h1 class="text-xl font-bold mb-4">🗂 الأقسام والولايات</h1>

<style>
/* iOS-style switch */
.switch{position:relative;display:inline-block;width:42px;height:24px}
.switch input{opacity:0;width:0;height:0}
.slider{position:absolute;cursor:pointer;inset:0;background:#cbd5e1;border-radius:24px;transition:.2s}
.slider:before{content:"";position:absolute;height:18px;width:18px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.2)}
.switch input:checked+.slider{background:#16a34a}
.switch input:checked+.slider:before{transform:translateX(18px)}
/* drag handle dots */
.drag-handle{display:inline-grid;grid-template-columns:repeat(2,3px);grid-gap:3px;cursor:grab;padding:8px 4px}
.drag-handle span{width:3px;height:3px;background:#cbd5e1;border-radius:50%}
</style>

<div class="space-y-8">
    {{-- Categories --}}
    <section>
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-bold text-lg">الأقسام</h2>
            <span class="text-xs text-gray-500">اسحب ⠿ لإعادة الترتيب</span>
        </div>

        {{-- Add new --}}
        <form action="{{ route('admin.categories.store') }}" method="POST" class="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 p-3 rounded-xl shadow-sm mb-4">
            @csrf
            <div class="text-xs font-semibold text-emerald-700 dark:text-emerald-300 mb-2">➕ إضافة قسم جديد</div>
            <div class="flex flex-wrap gap-2 items-center">
                <input name="icon" placeholder="🎁" class="w-16 p-2 rounded-lg bg-white dark:bg-gray-800 text-center border border-gray-200 dark:border-gray-700">
                <input name="name" required placeholder="اسم القسم" class="flex-1 min-w-[140px] p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <input name="sort_order" type="number" placeholder="ترتيب" class="w-24 p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <button class="bg-primary text-white px-4 py-2 rounded-lg font-bold">إضافة</button>
            </div>
        </form>

        <div id="catList" class="flex flex-col gap-y-3">
            @foreach($categories as $c)
                <div class="cat-card bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-3" data-id="{{ $c->id }}">
                    <form action="{{ route('admin.categories.update', $c) }}" method="POST" class="flex items-center gap-2 flex-wrap">
                        @csrf @method('PUT')
                        <span class="drag-handle shrink-0" title="اسحب"><span></span><span></span><span></span><span></span><span></span><span></span></span>
                        <input name="icon" value="{{ $c->icon }}" placeholder="🎁"
                               class="w-14 p-2 text-center text-xl rounded-lg bg-gray-50 dark:bg-gray-700 border border-gray-100 dark:border-gray-600 shrink-0">
                        <input name="name" value="{{ $c->name }}"
                               class="flex-1 min-w-[120px] p-2 rounded-lg bg-gray-50 dark:bg-gray-700 border border-gray-100 dark:border-gray-600 font-semibold text-sm">
                        <input type="hidden" name="is_active" value="{{ $c->is_active ? 1 : 0 }}">
                        <input name="sort_order" type="number" value="{{ $c->sort_order }}" title="الترتيب"
                               class="w-14 p-2 rounded-lg bg-gray-50 dark:bg-gray-700 border border-gray-100 dark:border-gray-600 text-sm text-center shrink-0">
                        <button type="submit" class="shrink-0 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-3 py-2 rounded-lg" title="حفظ">💾</button>
                    </form>
                    <form action="{{ route('admin.categories.destroy', $c) }}" method="POST" onsubmit="return confirm('حذف القسم؟')" class="mt-2 flex justify-start">
                        @csrf @method('DELETE')
                        <button class="text-red-400 hover:text-red-600 text-xs px-2" title="حذف">🗑 حذف</button>
                    </form>
                </div>
            @endforeach
        </div>
    </section>

    {{-- States --}}
    <section>
        <div class="flex items-center justify-between mb-3">
            <h2 class="font-bold text-lg">الولايات</h2>
            <span class="text-xs text-gray-500">اسحب ⠿ لإعادة الترتيب</span>
        </div>

        <form action="{{ route('admin.states.store') }}" method="POST" class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3 rounded-xl shadow-sm mb-4">
            @csrf
            <div class="text-xs font-semibold text-blue-700 dark:text-blue-300 mb-2">➕ إضافة ولاية جديدة</div>
            <div class="flex flex-wrap gap-2 items-center">
                <input name="name" required placeholder="اسم الولاية" class="flex-1 min-w-[160px] p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <input name="sort_order" type="number" placeholder="ترتيب" class="w-24 p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <button class="bg-primary text-white px-4 py-2 rounded-lg font-bold">إضافة</button>
            </div>
        </form>

        <div id="stateList" class="flex flex-col gap-y-3">
            @foreach($states as $s)
                <div class="state-card w-full bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-3 flex items-center gap-3" data-id="{{ $s->id }}">
                    <span class="drag-handle" title="اسحب"><span></span><span></span><span></span><span></span><span></span><span></span></span>
                    <span class="text-lg">📍</span>
                    <span class="font-semibold text-sm flex-1">{{ $s->name }}</span>
                    <form action="{{ route('admin.states.destroy', $s) }}" method="POST" onsubmit="return confirm('حذف الولاية؟')">
                        @csrf @method('DELETE')
                        <button class="text-red-400 hover:text-red-600 text-sm px-2" title="حذف">🗑</button>
                    </form>
                </div>
            @endforeach
        </div>
    </section>
</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
<script>
(function(){
    function persistOrder(url, ids){
        fetch(url, {
            method:'POST',
            headers:{'X-CSRF-TOKEN':csrf,'Content-Type':'application/json','Accept':'application/json'},
            body: JSON.stringify({order: ids}),
        }).then(()=> window.toastFlash && toastFlash('تم حفظ الترتيب ✅')).catch(()=>{});
    }
    const cat = document.getElementById('catList');
    if (cat) new Sortable(cat, {
        animation: 150, handle: '.drag-handle',
        onEnd: () => {
            const ids = [...cat.querySelectorAll('.cat-card')].map(el => el.dataset.id);
            persistOrder('{{ route('admin.categories.reorder') }}', ids);
        }
    });
    const st = document.getElementById('stateList');
    if (st) new Sortable(st, {
        animation: 150, handle: '.drag-handle',
        onEnd: () => {
            const ids = [...st.querySelectorAll('.state-card')].map(el => el.dataset.id);
            persistOrder('{{ route('admin.states.reorder') }}', ids);
        }
    });
})();
</script>
@endsection
