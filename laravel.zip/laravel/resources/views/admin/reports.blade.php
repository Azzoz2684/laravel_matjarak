@extends('layouts.app')
@section('title', 'البلاغات')
@section('content')
<h1 class="text-xl font-bold mb-4">🚩 البلاغات</h1>
<div class="flex gap-2 mb-4">
    @foreach(['pending','reviewed','dismissed'] as $st)
        <a href="{{ route('admin.reports', ['status' => $st]) }}"
           class="px-3 py-1 rounded {{ $status === $st ? 'bg-primary text-white' : 'bg-white dark:bg-gray-800' }}">
            {{ ['pending'=>'معلقة','reviewed'=>'تم النظر','dismissed'=>'مرفوضة'][$st] }}
        </a>
    @endforeach
</div>

<div class="space-y-3">
@foreach($reports as $r)
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <div class="flex justify-between items-start mb-2">
            <div>
                <div class="font-bold">{{ $r->post->title ?? '—' }}</div>
                <div class="text-xs text-gray-500">المُبلِّغ: {{ '@' . ($r->reporter->username ?? '—') }}</div>
            </div>
            <div class="text-xs text-gray-400">{{ $r->created_at->diffForHumans() }}</div>
        </div>
        <p class="text-sm bg-gray-100 dark:bg-gray-700 p-2 rounded">{{ $r->reason }}</p>
        <div class="mt-3 flex justify-end">
            <a href="{{ route('admin.reports.show', $r) }}" class="bg-accent text-white text-sm px-4 py-2 rounded">عرض التفاصيل واتخاذ إجراء →</a>
        </div>
    </div>
@endforeach
</div>
<div class="mt-4">{{ $reports->links() }}</div>
@endsection
