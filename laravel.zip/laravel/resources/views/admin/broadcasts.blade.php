@extends('layouts.app')
@section('title', 'الرسائل الجماعية')
@section('content')
<h1 class="text-xl font-bold mb-4">📣 الرسائل الجماعية</h1>

<form action="{{ route('admin.broadcasts.send') }}" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 rounded-xl p-5 shadow space-y-3 mb-6 max-w-2xl">
    @csrf
    <div>
        <label class="text-sm font-semibold block mb-1">العنوان</label>
        <input name="title" required maxlength="150" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
    </div>
    <div>
        <label class="text-sm font-semibold block mb-1">المحتوى</label>
        <textarea name="body" required rows="4" maxlength="1000" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700"></textarea>
    </div>
    <div class="grid grid-cols-2 gap-3">
        <div>
            <label class="text-sm font-semibold block mb-1">رابط (اختياري)</label>
            <input name="link" maxlength="500" placeholder="https://..." class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">نص زر الرابط</label>
            <input name="link_text" maxlength="80" placeholder="فتح الرابط" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
    </div>
    <div class="grid grid-cols-2 gap-3">
        <div>
            <label class="text-sm font-semibold block mb-1">رقم واتساب للتواصل</label>
            <input name="contact_phone" maxlength="30" placeholder="+249..." class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
        <div>
            <label class="text-sm font-semibold block mb-1">نص زر التواصل</label>
            <input name="contact_text" maxlength="80" placeholder="تواصل معنا" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        </div>
    </div>
    <div>
        <label class="text-sm font-semibold block mb-1">صورة (اختياري)</label>
        <input name="image" type="file" accept="image/jpeg,image/png,image/webp" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
    </div>
    <div>
        <label class="text-sm font-semibold block mb-1">الفئة المستهدفة</label>
        <select name="target" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
            <option value="all">جميع المستخدمين</option>
            <option value="sellers">البائعون</option>
            <option value="admins">المسؤولون</option>
        </select>
    </div>
    <label class="flex items-center gap-2 text-sm">
        <input type="checkbox" name="show_on_home" value="1" checked> عرض في أعلى الصفحة الرئيسية
    </label>
    <button class="bg-primary text-white px-6 py-2 rounded-lg font-bold">🚀 إرسال</button>
</form>

<h2 class="font-bold mb-2">آخر الرسائل الجماعية</h2>
<div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-x-auto">
    <table class="w-full text-sm min-w-[700px]">
        <thead class="bg-gray-100 dark:bg-gray-700">
            <tr>
                <th class="p-3 text-right">العنوان</th>
                <th class="p-3 text-right">المستلمون</th>
                <th class="p-3 text-right">على الرئيسية</th>
                <th class="p-3 text-right">التاريخ</th>
                <th class="p-3 text-right">إجراء</th>
            </tr>
        </thead>
        <tbody>
        @foreach($broadcasts as $b)
            <tr class="border-t border-gray-100 dark:border-gray-700">
                <td class="p-3">
                    <div class="font-semibold">{{ $b->title }}</div>
                    <div class="text-xs text-gray-500">{{ \Illuminate\Support\Str::limit($b->body, 80) }}</div>
                </td>
                <td class="p-3">{{ $b->recipients_count }}</td>
                <td class="p-3">{{ $b->is_active ? '✅' : '—' }}</td>
                <td class="p-3">{{ $b->created_at->diffForHumans() }}</td>
                <td class="p-3">
                    <form action="{{ route('admin.broadcasts.toggle', $b) }}" method="POST">@csrf
                        <button class="text-xs text-accent">{{ $b->is_active ? 'إخفاء' : 'إظهار' }}</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $broadcasts->links() }}</div>
@endsection
