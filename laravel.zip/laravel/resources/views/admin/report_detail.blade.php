@extends('layouts.app')
@section('title', 'تفاصيل البلاغ')
@section('content')
@php $post = $report->post; @endphp
<a href="{{ route('admin.reports') }}" class="text-sm text-accent">← العودة للبلاغات</a>
<h1 class="text-xl font-bold my-3">🚩 تفاصيل البلاغ #{{ $report->id }}</h1>

<div class="grid md:grid-cols-2 gap-4">
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <div class="text-sm text-gray-500 mb-2">المُبلِّغ</div>
        <div class="font-bold">{{ '@' . ($report->reporter->username ?? '—') }}</div>
        <div class="text-xs text-gray-500">{{ $report->reporter->phone ?? '' }}</div>
        <div class="mt-3 text-sm text-gray-500">تاريخ البلاغ</div>
        <div>{{ $report->created_at->format('Y-m-d H:i') }}</div>
        <div class="mt-3 text-sm text-gray-500">سبب البلاغ</div>
        <div class="bg-gray-100 dark:bg-gray-700 p-2 rounded">{{ $report->reason }}</div>
        @if($report->action_reason)
            <div class="mt-3 text-sm text-gray-500">إجراء سابق</div>
            <div class="bg-yellow-50 dark:bg-yellow-900/20 p-2 rounded text-sm">{{ $report->action_reason }}</div>
        @endif
    </div>

    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <div class="text-sm text-gray-500 mb-2">الإعلان المبلَّغ عنه</div>
        @if($post)
            <img src="{{ $post->firstImage() }}" class="w-full h-48 object-cover rounded mb-2" alt="">
            <div class="font-bold">{{ $post->title }}</div>
            <div class="text-primary font-bold">{{ number_format($post->price) }} {{ $post->currency }}</div>
            <p class="text-sm mt-2 line-clamp-3">{{ $post->description }}</p>
            <div class="text-xs text-gray-500 mt-2">القسم: {{ $post->category }} | الولاية: {{ $post->state }}</div>
            <div class="text-xs">الناشر: {{ '@' . ($post->user->username ?? '—') }}</div>
            <div class="text-xs">الحالة الحالية: <b>{{ $post->status }}</b></div>
            <a href="{{ route('posts.show', $post) }}" target="_blank" class="text-accent text-sm">عرض في الموقع ↗</a>
        @else
            <div class="text-red-500">الإعلان محذوف</div>
        @endif
    </div>
</div>

<form action="{{ route('admin.reports.act', $report) }}" method="POST" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow mt-4 space-y-3">
    @csrf
    <div class="grid sm:grid-cols-2 gap-3">
        <div>
            <label class="text-sm">قرار البلاغ</label>
            <select name="status" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                <option value="reviewed">قبول البلاغ</option>
                <option value="dismissed">رفض البلاغ</option>
            </select>
        </div>
        <div>
            <label class="text-sm">إجراء على الإعلان</label>
            <select name="post_action" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
                <option value="">بدون إجراء</option>
                <option value="hide">إخفاء</option>
                <option value="ban">حظر</option>
            </select>
        </div>
    </div>
    <div>
        <label class="text-sm">سبب الإجراء (سيُرسل للمبلّغ)</label>
        <textarea name="action_reason" rows="3" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700" placeholder="وضّح السبب..."></textarea>
    </div>
    <button class="bg-primary text-white px-6 py-2 rounded-xl font-bold w-full">تنفيذ وإرسال إشعار</button>
</form>
@endsection
