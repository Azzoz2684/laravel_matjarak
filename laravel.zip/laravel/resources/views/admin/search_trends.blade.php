@extends('layouts.app')
@section('title', 'تحليل كلمات البحث')
@section('content')
<h1 class="text-xl font-bold mb-4">🔎 كلمات البحث الأكثر طلباً</h1>

<div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
    <div class="grid grid-cols-12 text-xs font-bold bg-gray-50 dark:bg-gray-900/40 p-3 border-b border-gray-100 dark:border-gray-700">
        <div class="col-span-5">الكلمة</div>
        <div class="col-span-2 text-center">مرات البحث</div>
        <div class="col-span-2 text-center">آخر بحث</div>
        <div class="col-span-3 text-center">متوسط النتائج</div>
    </div>
    @forelse($top as $row)
        <div class="grid grid-cols-12 items-center text-sm p-3 border-b border-gray-50 dark:border-gray-800">
            <div class="col-span-5 font-semibold truncate">{{ $row->query }}</div>
            <div class="col-span-2 text-center"><span class="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs font-bold">{{ $row->cnt }}</span></div>
            <div class="col-span-2 text-center text-xs text-gray-500">{{ \Carbon\Carbon::parse($row->last_at)->diffForHumans() }}</div>
            <div class="col-span-3 text-center text-xs">{{ number_format((float)$row->avg_results, 1) }}</div>
        </div>
    @empty
        <div class="p-8 text-center text-gray-500">لا توجد بيانات بعد.</div>
    @endforelse
</div>

<h2 class="text-lg font-bold mt-6 mb-3">آخر عمليات البحث</h2>
<div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
    @foreach($recent as $q)
        <div class="flex items-center justify-between p-3 border-b border-gray-50 dark:border-gray-800 text-sm">
            <div class="font-semibold">{{ $q->query }}</div>
            <div class="text-xs text-gray-500">
                {{ $q->category ?: '—' }} • {{ $q->state ?: '—' }} • {{ $q->results_count }} نتيجة • {{ $q->created_at->diffForHumans() }}
            </div>
        </div>
    @endforeach
</div>
{{ $recent->links() }}
@endsection
