@extends('layouts.app')
@section('title', 'إدارة الإعلانات')
@section('content')
<h1 class="text-xl font-bold mb-4">📝 إدارة الإعلانات</h1>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
@foreach($posts as $p)
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow p-4">
        <div class="flex gap-3">
            <img src="{{ $p->firstImage() }}" class="w-20 h-20 object-cover rounded-lg shrink-0" alt="">
            <div class="flex-1 min-w-0">
                <a href="{{ route('posts.show', $p) }}" class="font-bold text-accent line-clamp-1">{{ $p->title }}</a>
                <div class="text-xs text-gray-500 mt-1">
                    👤 {{ $p->user->username ?? '—' }} •
                    🏷 {{ $p->category }} •
                    📍 {{ $p->state }}
                </div>
                <div class="text-xs text-gray-500 mt-1">
                    💵 {{ number_format($p->price) }} {{ $p->currency }} •
                    🕒 {{ $p->created_at->diffForHumans() }}
                </div>
                <div class="mt-1"><span class="text-xs bg-gray-200 dark:bg-gray-700 px-2 py-0.5 rounded">الحالة: {{ ['active'=>'نشط','hidden'=>'مخفي','banned'=>'محظور','pending'=>'قيد المراجعة'][$p->status] ?? $p->status }}</span></div>
            </div>
        </div>

        {{-- Actions in clean columns --}}
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
            <form action="{{ route('admin.posts.featured', $p) }}" method="POST">
                @csrf
                <button class="w-full bg-yellow-100 dark:bg-yellow-900/40 text-yellow-700 dark:text-yellow-200 font-bold text-sm py-2 rounded-lg">
                    {{ $p->featured ? '⭐ إلغاء التمييز' : '⭐ تمييز' }}
                </button>
            </form>
            <form action="{{ route('admin.posts.status', $p) }}" method="POST">
                @csrf <input type="hidden" name="status" value="active">
                <button class="w-full bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-200 font-bold text-sm py-2 rounded-lg">✅ تنشيط</button>
            </form>
            <form action="{{ route('admin.posts.status', $p) }}" method="POST">
                @csrf <input type="hidden" name="status" value="hidden">
                <button class="w-full bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-bold text-sm py-2 rounded-lg">🙈 إخفاء</button>
            </form>
            <form action="{{ route('admin.posts.status', $p) }}" method="POST">
                @csrf <input type="hidden" name="status" value="banned">
                <button class="w-full bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-200 font-bold text-sm py-2 rounded-lg">🚫 حظر</button>
            </form>
        </div>
        <div class="grid grid-cols-2 gap-2 mt-2">
            <a href="{{ route('posts.edit', $p) }}" class="text-center bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-200 font-bold text-sm py-2 rounded-lg">✏ تعديل</a>
            <form action="{{ route('posts.destroy', $p) }}" method="POST" onsubmit="return confirm('تأكيد الحذف؟')">
                @csrf @method('DELETE')
                <button class="w-full bg-red-500 text-white font-bold text-sm py-2 rounded-lg">🗑 حذف</button>
            </form>
        </div>
    </div>
@endforeach
</div>
<div class="mt-4">{{ $posts->links() }}</div>
@endsection
