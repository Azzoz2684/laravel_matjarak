<header class="bg-white dark:bg-gray-800 shadow sticky top-0 z-30">
    <div class="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
        <a href="{{ route('home') }}" class="flex items-center gap-2">
            <span class="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-2xl" aria-hidden="true">🛍️</span>
            <span class="font-bold text-lg">{{ $appName ?? 'متجرك' }}</span>
        </a>
        <nav class="flex items-center gap-3">
            @auth
                <a href="{{ route('notifications.index') }}" class="relative text-gray-600 dark:text-gray-300" id="bell-link" title="الإشعارات">
                    🔔
                    <span id="bell-count" class="hidden absolute -top-1 -left-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 items-center justify-center">0</span>
                </a>
            @else
                <a href="{{ route('login') }}" class="text-sm">دخول</a>
                <a href="{{ route('register') }}" class="bg-primary text-white text-sm px-3 py-1.5 rounded-lg">تسجيل</a>
            @endauth
        </nav>
    </div>
</header>
@auth
<script>
(function(){
    const badge = document.getElementById('bell-count');
    let lastCount = parseInt(localStorage.getItem('matjarak_notif_last') || '0', 10);
    async function showSystemNotification(title, body, url) {
        try {
            if (!('Notification' in window) || Notification.permission !== 'granted') return;
            if ('serviceWorker' in navigator) {
                const reg = await navigator.serviceWorker.ready;
                await reg.showNotification(title, {
                    body, icon: '/assets/logo.png', badge: '/assets/logo.png',
                    tag: 'matjarak-notif', renotify: true, requireInteraction: true, silent: false,
                    data: { url: url || '/notifications' },
                });
            } else { new Notification(title, { body, icon: '/assets/logo.png' }); }
        } catch(e){}
    }
    async function poll(){
        try{
            const r = await fetch('/notifications/unread-count', {headers:{'Accept':'application/json'}});
            const d = await r.json();
            const count = d.count|0;
            if(count > 0){ badge.textContent = count; badge.classList.remove('hidden'); badge.classList.add('flex'); }
            else { badge.classList.add('hidden'); }
            if (count > lastCount) {
                showSystemNotification('متجرك', 'لديك ' + (count-lastCount) + ' إشعار جديد', '/notifications');
            }
            lastCount = count;
            localStorage.setItem('matjarak_notif_last', String(count));
        }catch(e){}
    }
    if ('Notification' in window && Notification.permission === 'default') {
        document.addEventListener('click', () => Notification.requestPermission().catch(()=>{}), { once: true });
    }
    poll(); setInterval(poll, 30000);
})();
</script>
@endauth
