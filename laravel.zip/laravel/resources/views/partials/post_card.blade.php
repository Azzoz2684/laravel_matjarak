@php
    $mode = $mode ?? 'grid';
    $shareUrl = route('posts.show', $post);
    $waText = "السلام عليكم، بخصوص إعلانك:\n" . $shareUrl . "\n";
    $waUrl = $post->whatsapp ? 'https://wa.me/' . ltrim($post->whatsapp, '+') . '?text=' . rawurlencode($waText) : null;
    $isOwner = auth()->check() && $post->user_id === auth()->id();
    $isAdmin = auth()->check() && auth()->user()->hasRole('admin');
    $dotsIcon = '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>';
    $waIcon = '<svg viewBox="0 0 32 32" width="20" height="20" fill="#25D366"><path d="M19.11 17.5c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.61.14-.18.27-.7.88-.86 1.06-.16.18-.32.2-.59.07-.27-.14-1.13-.42-2.16-1.33-.8-.71-1.34-1.6-1.5-1.87-.16-.27-.02-.42.12-.55.12-.12.27-.32.41-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.61-1.47-.84-2.01-.22-.53-.45-.46-.61-.47l-.52-.01c-.18 0-.48.07-.73.34-.25.27-.96.94-.96 2.29 0 1.35.98 2.65 1.12 2.83.14.18 1.93 2.95 4.68 4.13.65.28 1.16.45 1.56.58.65.21 1.25.18 1.72.11.53-.08 1.6-.65 1.83-1.28.23-.63.23-1.17.16-1.28-.07-.11-.25-.18-.52-.32zM16.02 4C9.38 4 4 9.38 4 16.02c0 2.12.55 4.18 1.6 6L4 28l6.2-1.62a12 12 0 0 0 5.82 1.49h.01c6.64 0 12.02-5.38 12.02-12.02C28.05 9.38 22.67 4 16.02 4z"/></svg>';
@endphp

@php
$menuItems = function() use ($post, $isOwner, $isAdmin, $shareUrl) { return ''; };
@endphp

@php
// Reusable menu markup
$menuHtml = '<div id="menu-'.$post->id.'" class="hidden absolute left-0 bg-white dark:bg-gray-700 shadow-xl rounded-lg p-1 z-30 w-44 text-sm">';
if (auth()->check()) {
    if ($isOwner || $isAdmin) {
        $menuHtml .= '<a href="'.route('posts.edit', $post).'" class="block px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded">✏️ تعديل</a>';
        $menuHtml .= '<form action="'.route('posts.destroy', $post).'" method="POST" onsubmit="return confirm(\'تأكيد الحذف؟\')">'.csrf_field().method_field('DELETE').
            '<button class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded text-red-500">🗑 حذف</button></form>';
    }
    if ($isAdmin) {
        $menuHtml .= '<form action="'.route('admin.posts.featured', $post).'" method="POST">'.csrf_field().
            '<button class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded text-yellow-600">'.
            ($post->featured ? '⭐ إلغاء التمييز' : '⭐ تمييز كمنشور بارز').
            '</button></form>';
    }
    if (!$isOwner) {
        $menuHtml .= '<button type="button" onclick="openReport('.$post->id.'); toggleMenu('.$post->id.')" class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded text-red-500">🚩 إبلاغ</button>';
    }
}
$menuHtml .= '<button type="button" onclick="sharePost(\''.$shareUrl.'\',\''.addslashes($post->title).'\'); toggleMenu('.$post->id.')" class="w-full text-right px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded">➦ مشاركة</button>';
$menuHtml .= '</div>';
$showMenu = auth()->check();
@endphp

@if($mode === 'single')
<article data-post="{{ $post->id }}" class="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow mb-4 relative">
    <div class="flex items-center justify-between p-3">
        <div class="flex items-center gap-2 min-w-0">
            @if($post->user->avatar_url ?? null)
                <img src="{{ $post->user->avatar_url }}" alt="" class="w-10 h-10 rounded-full object-cover shrink-0">
            @else
                <div class="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-bold shrink-0">
                    {{ mb_substr($post->user->username ?? 'م', 0, 1) }}
                </div>
            @endif
            <div class="min-w-0">
                <div class="text-sm font-semibold truncate">{{ $post->user->full_name ?? $post->user->username }}</div>
                <div class="text-xs text-gray-500 truncate">{{ $post->created_at->diffForHumans() }} • 📍 {{ $post->state }}</div>
            </div>
        </div>
        <div class="flex items-center gap-2 shrink-0">
            @if($post->featured)<span class="bg-yellow-400 text-[10px] font-bold px-2 py-0.5 rounded-full">⭐ مميز</span>@endif
            @if($showMenu)
            <div class="relative">
                <button onclick="toggleMenu({{ $post->id }})" class="w-9 h-9 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center justify-center text-gray-500" aria-label="خيارات">{!! $dotsIcon !!}</button>
                {!! $menuHtml !!}
            </div>
            @endif
        </div>
    </div>

    <a href="{{ route('posts.show', $post) }}" class="block px-3 pb-2">
        <h3 class="font-bold text-base leading-snug mb-1">{{ $post->title }}</h3>
        @if($post->description)<p class="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{{ $post->description }}</p>@endif
    </a>

    <a href="{{ route('posts.show', $post) }}" class="block">
        <img src="{{ $post->firstImage() }}" alt="{{ $post->title }}" loading="lazy" class="w-full aspect-square object-cover bg-gray-100">
    </a>

    <div class="px-3 py-2 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between">
        <div class="text-xs text-gray-500">📍 {{ $post->state }}{{ $post->city ? ' • '.$post->city : '' }}</div>
        <div class="text-primary font-extrabold">{{ $post->priceArabic() }}</div>
    </div>

    <div class="grid grid-cols-4 border-t border-gray-100 dark:border-gray-700 text-sm">
        @auth
        <button onclick="toggleLike(this, {{ $post->id }})" class="flex items-center justify-center gap-1.5 py-3 {{ $post->isLikedBy(auth()->id()) ? 'text-red-500' : 'text-gray-500' }}">
            <span class="heart">{{ $post->isLikedBy(auth()->id()) ? '❤️' : '🤍' }}</span>
            <span class="text-xs font-semibold">أعجبني</span>
        </button>
        @else
        <a href="{{ route('login') }}" class="flex items-center justify-center gap-1.5 py-3 text-gray-500"><span>🤍</span><span class="text-xs font-semibold">أعجبني</span></a>
        @endauth
        <a href="{{ route('posts.show', $post) }}#comments" class="flex items-center justify-center gap-1.5 py-3 text-gray-500"><span>💬</span><span class="text-xs font-semibold">تعليق</span></a>
        <button onclick="sharePost('{{ $shareUrl }}','{{ addslashes($post->title) }}')" class="flex items-center justify-center gap-1.5 py-3 text-gray-500"><span class="text-base">➦</span><span class="text-xs font-semibold">مشاركة</span></button>
        @if($waUrl)
            <a href="{{ $waUrl }}" target="_blank" rel="noopener" class="flex items-center justify-center gap-1.5 py-3">{!! $waIcon !!}<span class="text-xs font-semibold text-gray-700 dark:text-gray-200">واتساب</span></a>
        @else
            <span class="flex items-center justify-center text-gray-400 py-3 text-xs">—</span>
        @endif
    </div>
</article>

@else
<article data-post="{{ $post->id }}" class="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow hover:shadow-lg transition relative">
    <a href="{{ route('posts.show', $post) }}" class="block">
        <img src="{{ $post->firstImage() }}" alt="{{ $post->title }}" loading="lazy" class="w-full h-40 object-cover bg-gray-100">
    </a>
    @if($post->featured)<span class="absolute top-2 right-2 bg-yellow-400 text-xs px-2 py-0.5 rounded-full">⭐ مميز</span>@endif

    @if($showMenu)
    <div class="absolute top-2 left-2 z-20">
        <button onclick="toggleMenu({{ $post->id }})" class="w-8 h-8 rounded-full bg-white/90 dark:bg-gray-900/80 shadow flex items-center justify-center text-gray-700 dark:text-gray-200" aria-label="خيارات">{!! $dotsIcon !!}</button>
        {!! $menuHtml !!}
    </div>
    @endif

    <div class="p-3">
        <a href="{{ route('posts.show', $post) }}" class="block">
            <h3 class="font-bold text-sm line-clamp-1">{{ $post->title }}</h3>
            <div class="text-primary font-extrabold mt-1">{{ $post->priceArabic() }}</div>
            <div class="text-xs text-gray-500 mt-1">📍 {{ $post->state }}</div>
            <div class="text-xs text-gray-400 mt-1">{{ $post->created_at->diffForHumans() }}</div>
        </a>
        @auth
        <div class="flex items-center justify-between mt-2 text-sm">
            <button onclick="toggleLike(this, {{ $post->id }})" class="flex items-center gap-1 {{ $post->isLikedBy(auth()->id()) ? 'text-red-500' : 'text-gray-400' }}">
                <span class="heart">{{ $post->isLikedBy(auth()->id()) ? '❤️' : '🤍' }}</span>
                <span class="count">{{ $post->likes()->count() }}</span>
            </button>
            @if($waUrl)<a href="{{ $waUrl }}" target="_blank" rel="noopener" aria-label="واتساب">{!! $waIcon !!}</a>@endif
        </div>
        @endauth
    </div>
</article>
@endif

<script>
window.toggleMenu = window.toggleMenu || function(id){
    const m = document.getElementById('menu-'+id);
    if(!m) return;
    document.querySelectorAll('[id^="menu-"]').forEach(el => el !== m && el.classList.add('hidden'));
    m.classList.toggle('hidden');
};
document.addEventListener('click', (e) => {
    if (!e.target.closest('[id^="menu-"]') && !e.target.closest('[aria-label="خيارات"]')) {
        document.querySelectorAll('[id^="menu-"]').forEach(el => el.classList.add('hidden'));
    }
}, true);
</script>
