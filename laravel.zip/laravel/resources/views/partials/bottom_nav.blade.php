@php
    $tabs = [
        ['route' => 'home',           'label' => 'الرئيسية', 'svg' => 'home'],
        ['route' => 'featured',       'label' => 'مميزة',    'svg' => 'star'],
        ['route' => 'posts.create',   'label' => 'إعلان',    'svg' => 'plus', 'center' => true, 'auth' => true],
        ['route' => 'profile.show',   'label' => 'حسابي',    'svg' => 'user', 'auth' => true],
        ['route' => 'settings.index', 'label' => 'الإعدادات','svg' => 'gear', 'auth' => true],
    ];
    $svgs = [
        'home'  => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/>',
        'star'  => '<path d="M12 3l2.7 6 6.3.6-4.8 4.3 1.5 6.4L12 17l-5.7 3.3 1.5-6.4L3 9.6 9.3 9z"/>',
        'plus'  => '<path d="M12 5v14M5 12h14"/>',
        'user'  => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 5-6 8-6s6.5 2 8 6"/>',
        'gear'  => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    ];
@endphp
<nav class="fixed bottom-0 inset-x-0 bg-white/95 dark:bg-gray-800/95 backdrop-blur border-t border-gray-200 dark:border-gray-700 z-30">
    <div class="max-w-5xl mx-auto grid grid-cols-5 text-center">
        @foreach($tabs as $t)
            @php
                $active = $t['route'] === 'profile.show'
                    ? request()->routeIs('profile.*')
                    : ($t['route'] === 'settings.index'
                        ? request()->routeIs('settings.*')
                        : request()->routeIs($t['route']));
                $href = (!empty($t['auth']) && !auth()->check()) ? route('login') : route($t['route']);
            @endphp
            <a href="{{ $href }}" class="group py-2 flex flex-col items-center gap-1 transition-all duration-200 {{ $active ? 'text-primary' : 'text-gray-500 dark:text-gray-400' }}">
                @if(!empty($t['center']))
                    <span class="-mt-5 bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg ring-4 ring-white dark:ring-gray-800">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6">{!! $svgs[$t['svg']] !!}</svg>
                    </span>
                @else
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="transition-transform duration-200 {{ $active ? 'w-7 h-7 scale-110 stroke-[2.4]' : 'w-6 h-6' }}">
                        {!! $svgs[$t['svg']] !!}
                    </svg>
                @endif
                <span class="text-[11px] {{ $active ? 'font-bold' : 'font-medium' }}">{{ $t['label'] }}</span>
            </a>
        @endforeach
    </div>
</nav>
