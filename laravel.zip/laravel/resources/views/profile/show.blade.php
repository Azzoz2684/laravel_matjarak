@extends('layouts.app')
@section('title', 'حسابي')
@section('content')
<div class="bg-white dark:bg-gray-800 rounded-xl p-5 shadow mb-4">
    <div class="flex items-center gap-3">
        @if($user->avatar_url)
            <img src="{{ $user->avatar_url }}" class="w-16 h-16 rounded-full object-cover">
        @else
            <div class="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl">
                {{ mb_substr($user->username, 0, 1) }}
            </div>
        @endif
        <div class="flex-1">
            <div class="font-bold">{{ $user->full_name ?? $user->username }}</div>
            <div class="text-sm text-gray-500">{{ '@' . $user->username }}</div>
            <div class="text-xs text-gray-400">{{ $user->phone }}</div>
        </div>
    </div>
    @if($user->bio)<p class="mt-3 text-sm">{{ $user->bio }}</p>@endif
    <a href="{{ route('profile.edit') }}"
       class="mt-4 block w-full text-center bg-primary text-white py-2.5 rounded-xl font-bold text-base shadow">
        ✏️ تعديل الملف الشخصي
    </a>
</div>

{{-- Pending background uploads (optimistic queue) — purge stale leftovers --}}
<div id="pendingPostsWrap" class="hidden mb-4">
    <div class="flex items-center justify-between mb-3">
        <h2 class="font-bold">قيد النشر</h2>
        <button id="clearAllPending" class="text-xs text-red-500 underline">مسح الكل</button>
    </div>
    <div id="pendingPosts" class="grid grid-cols-2 md:grid-cols-3 gap-3"></div>
</div>
<script>
(function(){
    const wrap = document.getElementById('pendingPostsWrap');
    const host = document.getElementById('pendingPosts');
    const KEY  = 'matjarak_pending_posts_v2'; // bumped — drops old stuck entries
    // Clear any legacy storage from previous buggy version
    try { localStorage.removeItem('matjarak_pending_posts'); } catch(_){}

    // Aggressive sweep: drop anything older than 30s (real network upload finishes in seconds)
    function sweep(){
        try {
            const q = JSON.parse(localStorage.getItem(KEY)||'[]');
            const now = Date.now();
            const fresh = q.filter(p => p && p.createdAt && (now - p.createdAt) < 30000);
            if (fresh.length !== q.length) localStorage.setItem(KEY, JSON.stringify(fresh));
        } catch(_){}
    }

    function render(){
        sweep();
        let q = [];
        try { q = JSON.parse(localStorage.getItem(KEY)||'[]'); } catch(_){}
        if (!q.length) { wrap.classList.add('hidden'); host.innerHTML=''; return; }
        wrap.classList.remove('hidden');
        host.innerHTML = q.map((p,i) => `
          <div class="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow border border-dashed border-primary/40 relative">
            <button data-dismiss="${i}" class="absolute top-1 left-1 bg-black/60 text-white rounded-full w-6 h-6 text-xs leading-none">×</button>
            ${p.thumb ? `<img src="${p.thumb}" class="w-full h-32 object-cover opacity-70">` : `<div class="w-full h-32 bg-gray-200 dark:bg-gray-700"></div>`}
            <div class="p-2 text-xs">
              <div class="font-bold truncate">${(p.title||'').replace(/</g,'&lt;')}</div>
              <div class="text-gray-500">${p.price||''}</div>
              <div class="mt-1 ${p.status==='failed'?'text-red-500':'text-primary'}">${p.status==='failed'?'⚠ فشل الرفع':'⏳ جاري الرفع…'}</div>
            </div>
          </div>`).join('');
        host.querySelectorAll('[data-dismiss]').forEach(b => b.addEventListener('click', (ev) => {
            const idx = +ev.currentTarget.getAttribute('data-dismiss');
            try {
                const arr = JSON.parse(localStorage.getItem(KEY)||'[]');
                arr.splice(idx,1); localStorage.setItem(KEY, JSON.stringify(arr));
            } catch(_){}
            render();
        }));
    }

    document.getElementById('clearAllPending')?.addEventListener('click', () => {
        try { localStorage.removeItem(KEY); } catch(_){}
        render();
    });

    sweep(); render();
    setInterval(render, 1500);

    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', (e) => {
            if (e.data && e.data.type === 'BGSYNC_DONE') {
                try {
                    const q = JSON.parse(localStorage.getItem(KEY)||'[]');
                    q.shift(); localStorage.setItem(KEY, JSON.stringify(q));
                } catch(_){}
                render();
            }
        });
    }

    const flash = localStorage.getItem('matjarak_pending_flash');
    if (flash) { localStorage.removeItem('matjarak_pending_flash'); window.toastFlash && toastFlash(flash); }
})();
</script>

<h2 class="font-bold mb-3">إعلاناتي ({{ $posts->count() }})</h2>
<div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
    @forelse($posts as $post)
        <div class="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow">
            <a href="{{ route('posts.show', $post) }}" class="flex gap-3 p-3">
                <img src="{{ $post->firstImage() }}" alt="{{ $post->title }}" loading="lazy" class="w-24 h-24 rounded-lg object-cover bg-gray-100 shrink-0">
                <div class="flex-1 min-w-0">
                    <h3 class="font-bold text-sm line-clamp-1">{{ $post->title }}</h3>
                    <div class="text-primary font-extrabold mt-1 text-sm">{{ $post->priceArabic() }}</div>
                    <div class="text-xs text-gray-500 mt-1">📍 {{ $post->state }}</div>
                    <div class="text-xs text-gray-400 mt-1">{{ $post->created_at->diffForHumans() }}</div>
                </div>
            </a>
            <div class="grid grid-cols-2 border-t border-gray-100 dark:border-gray-700">
                <a href="{{ route('posts.edit', $post) }}"
                   class="py-3 text-center font-bold text-base text-white bg-primary hover:bg-primary-dark">
                    ✏️ تعديل
                </a>
                <form action="{{ route('posts.destroy', $post) }}" method="POST"
                      onsubmit="return confirm('هل أنت متأكد من حذف الإعلان؟ لا يمكن التراجع.')">
                    @csrf @method('DELETE')
                    <button type="submit" class="w-full py-3 font-bold text-base text-white bg-red-500 hover:bg-red-600">
                        🗑 حذف
                    </button>
                </form>
            </div>
        </div>
    @empty
        <div class="col-span-full text-center py-6 text-gray-500">لا توجد إعلانات بعد</div>
    @endforelse
</div>

<h2 class="font-bold mb-3">المحفوظات ({{ $saved->count() }})</h2>
<div class="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
    @forelse($saved as $s)
        @include('partials.post_card', ['post' => $s->post, 'mode' => 'grid'])
    @empty
        <div class="col-span-full text-center py-6 text-gray-500">لا توجد عناصر محفوظة</div>
    @endforelse
</div>
@endsection
