@extends('layouts.app')
@section('title', 'تعديل الملف')
@section('content')
<div class="bg-white dark:bg-gray-800 rounded-xl p-5 shadow">
    <h1 class="text-xl font-bold mb-4">تعديل الملف</h1>
    <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data" class="space-y-3">
        @csrf @method('PUT')
        <input name="full_name" value="{{ $user->full_name }}" placeholder="الاسم الكامل" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        <input name="state" value="{{ $user->state }}" placeholder="الولاية" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
        <textarea name="bio" rows="3" placeholder="نبذة" class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">{{ $user->bio }}</textarea>
        <div>
            <label class="block text-sm mb-1">الصورة الشخصية</label>
            <input name="avatar" type="file" accept="image/*" class="w-full">
        </div>
        <button class="w-full bg-primary text-white py-2 rounded-lg font-bold">حفظ</button>
    </form>
</div>
@endsection
