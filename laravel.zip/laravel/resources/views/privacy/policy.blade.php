@extends('layouts.app')
@section('title', 'سياسة الخصوصية')
@section('no_bottom_nav', $mustAccept ? '1' : '')
@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow p-6">
        <h1 class="text-2xl font-extrabold mb-4">🔒 سياسة الخصوصية</h1>
        <div class="prose prose-sm dark:prose-invert max-w-none whitespace-pre-line text-gray-700 dark:text-gray-200 leading-relaxed">{{ $content }}</div>
        <div class="text-xs text-gray-400 mt-4">الإصدار: {{ $version }}</div>

        @auth
            @if($mustAccept)
                <form action="{{ route('privacy.accept') }}" method="POST" class="mt-6 border-t dark:border-gray-700 pt-4">
                    @csrf
                    <label class="flex items-start gap-2 text-sm mb-3">
                        <input type="checkbox" name="accept" value="1" required class="mt-1">
                        <span>أوافق على سياسة الخصوصية وشروط الاستخدام.</span>
                    </label>
                    <button class="w-full bg-primary text-white font-bold py-3 rounded-xl">قبول ومتابعة الاستخدام</button>
                </form>
            @else
                <div class="mt-4 text-green-700 dark:text-green-300 text-sm">✅ لقد قبلت أحدث نسخة من السياسة.</div>
            @endif
        @endauth
    </div>
</div>
@endsection
