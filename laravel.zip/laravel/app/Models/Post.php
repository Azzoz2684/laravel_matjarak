<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Post extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id', 'title', 'description', 'price', 'currency', 'category',
        'state', 'city', 'images', 'video_url', 'phone', 'whatsapp', 'status', 'featured',
        'featured_until', 'latitude', 'longitude', 'condition', 'views_count'
    ];
    protected $casts = [
        'images' => 'array',
        'featured' => 'boolean',
        'featured_until' => 'datetime',
        'price' => 'decimal:2',
    ];

    /** Scope: currently featured (featured=1 AND (no expiry OR expiry in future)). */
    public function scopeFeatured($q)
    {
        return $q->where('featured', true)->where(function ($w) {
            $w->whereNull('featured_until')->orWhere('featured_until', '>', now());
        });
    }

    public function isCurrentlyFeatured(): bool
    {
        return $this->featured && (is_null($this->featured_until) || $this->featured_until->isFuture());
    }

    public function user() { return $this->belongsTo(User::class); }
    public function likes() { return $this->hasMany(Like::class); }
    public function comments() { return $this->hasMany(Comment::class); }
    public function saves() { return $this->hasMany(Save::class); }
    public function reports() { return $this->hasMany(Report::class); }

    public function isLikedBy($userId): bool
    {
        return $userId ? $this->likes()->where('user_id', $userId)->exists() : false;
    }
    public function isSavedBy($userId): bool
    {
        return $userId ? $this->saves()->where('user_id', $userId)->exists() : false;
    }
    public function firstImage(): string
    {
        $imgs = $this->images ?? [];
        return $imgs[0] ?? '/assets/logo.png';
    }

    /**
     * Format price in Sudanese colloquial Arabic.
     * 150000 SDG -> "150 ألف جنيه"; 1500000 -> "1.5 مليون جنيه"
     */
    public static function arabicPrice($amount, ?string $currency = 'SDG'): string
    {
        $unit = match(strtoupper((string)$currency)) {
            'USD' => 'دولار',
            'SAR' => 'ريال',
            'AED' => 'درهم',
            'EUR' => 'يورو',
            default => 'جنيه',
        };
        $n = (float) $amount;
        if ($n <= 0) return 'بلاش — ' . $unit;
        $fmt = function($v){ $s = number_format($v, 1); return str_ends_with($s, '.0') ? substr($s, 0, -2) : $s; };
        if ($n >= 1_000_000_000) return $fmt($n/1_000_000_000) . ' مليار ' . $unit;
        if ($n >= 1_000_000)     return $fmt($n/1_000_000) . ' مليون ' . $unit;
        if ($n >= 1_000)         return $fmt($n/1_000) . ' ألف ' . $unit;
        return number_format($n) . ' ' . $unit;
    }

    public function priceArabic(): string
    {
        return static::arabicPrice($this->price, $this->currency);
    }
}
