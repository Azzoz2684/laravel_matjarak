<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SellerRating extends Model {
    protected $fillable = ['seller_id','rater_id','stars','comment'];
}
