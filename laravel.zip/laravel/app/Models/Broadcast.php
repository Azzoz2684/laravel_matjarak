<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Broadcast extends Model {
    protected $fillable = ['title', 'body', 'link', 'link_text', 'contact_phone', 'contact_text', 'image_url', 'is_active', 'created_by', 'recipients_count'];
    protected $casts = ['is_active' => 'boolean'];
}
