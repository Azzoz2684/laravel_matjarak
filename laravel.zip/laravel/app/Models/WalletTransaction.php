<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WalletTransaction extends Model
{
    protected $fillable = ['wallet_id', 'user_id', 'type', 'amount', 'reason', 'reference_id', 'meta', 'note'];
    protected $casts = [
        'amount' => 'decimal:2',
        'meta'   => 'array',
    ];

    public function wallet() { return $this->belongsTo(Wallet::class); }
    public function user() { return $this->belongsTo(User::class); }

    public function reasonArabic(): string
    {
        return match ($this->reason) {
            'signup_bonus' => 'مكافأة التسجيل',
            'admin_topup'  => 'شحن من الإدارة',
            'feature_post' => 'تمييز إعلان',
            'refund'       => 'استرداد',
            default        => $this->reason,
        };
    }
}
