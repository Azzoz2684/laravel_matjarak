<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SearchQuery extends Model {
    protected $fillable = ['user_id','query','category','state','results_count','ip'];
}
