<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Report extends Model {
    protected $fillable = ['user_id', 'post_id', 'reason', 'status', 'action_reason', 'acted_by', 'acted_at'];
    protected $casts = ['acted_at' => 'datetime'];
    public function post() { return $this->belongsTo(Post::class); }
    public function reporter() { return $this->belongsTo(User::class, 'user_id'); }
}
