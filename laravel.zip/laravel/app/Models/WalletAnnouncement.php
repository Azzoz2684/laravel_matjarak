<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WalletAnnouncement extends Model
{
    protected $fillable = ['title', 'body', 'level', 'is_active', 'starts_at', 'ends_at', 'created_by'];
    protected $casts = [
        'is_active' => 'boolean',
        'starts_at' => 'datetime',
        'ends_at'   => 'datetime',
    ];

    /**
     * Announcements visible to the given user (active, in-window, not dismissed).
     */
    public static function forUser(int $userId)
    {
        $now = now();
        return static::where('is_active', true)
            ->where(function ($q) use ($now) {
                $q->whereNull('starts_at')->orWhere('starts_at', '<=', $now);
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('ends_at')->orWhere('ends_at', '>=', $now);
            })
            ->whereNotIn('id', function ($sub) use ($userId) {
                $sub->select('announcement_id')
                    ->from('wallet_announcement_dismissals')
                    ->where('user_id', $userId);
            })
            ->latest()
            ->get();
    }
}
