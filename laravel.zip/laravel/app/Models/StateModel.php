<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class StateModel extends Model {
    protected $table = 'states';
    protected $fillable = ['name', 'sort_order', 'is_active'];
    protected $casts = ['is_active' => 'boolean'];
}
