<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['username', 'full_name', 'phone', 'email', 'password', 'avatar_url', 'state', 'bio',
        'google_id', 'notify_enabled', 'notify_scope', 'interest_categories', 'last_daily_notified_at', 'feed_view_mode',
        'privacy_accepted_at', 'privacy_version'];
    protected $hidden = ['password', 'remember_token'];
    protected $casts = [
        'password' => 'hashed',
        'notify_enabled' => 'boolean',
        'interest_categories' => 'array',
        'last_daily_notified_at' => 'datetime',
        'privacy_accepted_at' => 'datetime',
    ];

    public function roles() { return $this->hasMany(UserRole::class); }
    public function posts() { return $this->hasMany(Post::class); }
    public function likes() { return $this->hasMany(Like::class); }
    public function saves() { return $this->hasMany(Save::class); }
    public function comments() { return $this->hasMany(Comment::class); }
    public function notifications() { return $this->hasMany(Notification::class); }
    public function wallet() { return $this->hasOne(Wallet::class); }
    public function walletTransactions() { return $this->hasMany(WalletTransaction::class); }

    public function walletOrCreate(): Wallet
    {
        return $this->wallet()->firstOrCreate(
            ['user_id' => $this->id],
            ['balance' => 0, 'currency' => AppSetting::get('wallet_currency', 'SDG')]
        );
    }

    public function hasRole(string $role): bool
    {
        return $this->roles()->where('role', $role)->exists();
    }

    public function getRoleNamesAttribute(): array
    {
        return $this->roles()->pluck('role')->toArray();
    }
}
