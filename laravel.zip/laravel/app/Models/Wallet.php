<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Wallet extends Model
{
    protected $fillable = ['user_id', 'balance', 'currency'];
    protected $casts = ['balance' => 'decimal:2'];

    public function user() { return $this->belongsTo(User::class); }
    public function transactions() { return $this->hasMany(WalletTransaction::class); }

    /**
     * Safely credit the wallet inside a DB transaction with row-lock.
     * Returns the created WalletTransaction.
     */
    public function credit(float $amount, string $reason, array $meta = [], ?int $referenceId = null, ?string $note = null): WalletTransaction
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('Amount must be positive');
        }
        return DB::transaction(function () use ($amount, $reason, $meta, $referenceId, $note) {
            $w = self::where('id', $this->id)->lockForUpdate()->first();
            $w->balance = (float) $w->balance + $amount;
            $w->save();
            return WalletTransaction::create([
                'wallet_id'    => $w->id,
                'user_id'      => $w->user_id,
                'type'         => 'credit',
                'amount'       => $amount,
                'reason'       => $reason,
                'reference_id' => $referenceId,
                'meta'         => $meta,
                'note'         => $note,
            ]);
        });
    }

    /**
     * Safely debit; throws \RuntimeException('insufficient_funds') if not enough.
     */
    public function debit(float $amount, string $reason, array $meta = [], ?int $referenceId = null, ?string $note = null): WalletTransaction
    {
        if ($amount <= 0) {
            throw new \InvalidArgumentException('Amount must be positive');
        }
        return DB::transaction(function () use ($amount, $reason, $meta, $referenceId, $note) {
            $w = self::where('id', $this->id)->lockForUpdate()->first();
            if ((float) $w->balance < $amount) {
                throw new \RuntimeException('insufficient_funds');
            }
            $w->balance = (float) $w->balance - $amount;
            $w->save();
            return WalletTransaction::create([
                'wallet_id'    => $w->id,
                'user_id'      => $w->user_id,
                'type'         => 'debit',
                'amount'       => $amount,
                'reason'       => $reason,
                'reference_id' => $referenceId,
                'meta'         => $meta,
                'note'         => $note,
            ]);
        });
    }
}
