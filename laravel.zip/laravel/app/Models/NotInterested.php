<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class NotInterested extends Model {
    protected $table = 'not_interested';
    protected $fillable = ['user_id', 'post_id'];
}
