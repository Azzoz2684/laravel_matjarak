<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;

class AppSetting extends Model
{
    protected $fillable = ['key', 'value'];
    public $timestamps = true;

    /** Keys that must be encrypted at rest (never exposed to client). */
    public const ENCRYPTED_KEYS = ['gemini_api_key'];

    public static function get(string $key, $default = null)
    {
        $all = Cache::remember('app_settings_all', 300, function () {
            return static::pluck('value', 'key')->all();
        });
        $val = $all[$key] ?? null;
        if ($val !== null && in_array($key, self::ENCRYPTED_KEYS, true)) {
            try { $val = Crypt::decryptString($val); }
            catch (\Throwable $e) { /* legacy plaintext value, keep as-is */ }
        }
        return $val ?? $default;
    }

    public static function set(string $key, $value): void
    {
        $stored = (string) $value;
        if (in_array($key, self::ENCRYPTED_KEYS, true) && $stored !== '') {
            $stored = Crypt::encryptString($stored);
        }
        static::updateOrCreate(['key' => $key], ['value' => $stored]);
        Cache::forget('app_settings_all');
    }
}
