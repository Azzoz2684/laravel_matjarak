<?php
namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        Paginator::useTailwind();

        // Arabic relative time ("منذ ساعة"، "منذ يوم")
        Carbon::setLocale('ar');

        // Share frequently-used app settings with every view
        View::composer('*', function ($view) {
            try {
                $support = \App\Models\AppSetting::get('support_whatsapp', '+249900000000');
                $appName = \App\Models\AppSetting::get('app_name', 'متجرك');
                $view->with(['supportWhatsapp' => $support, 'appName' => $appName]);
            } catch (\Throwable $e) {
                $view->with(['supportWhatsapp' => '+249900000000', 'appName' => 'متجرك']);
            }
        });
    }
}
