<?php
namespace App\Services;

use App\Models\PushSubscription;
use Illuminate\Support\Facades\Log;

/**
 * Pure Web Push notification sender (no Firebase).
 *
 * For real encrypted delivery on Hostinger run:
 *     composer require minishlink/web-push
 * Then this class will use it automatically. Without the package installed,
 * notifications fall back to the in-app polling channel (the bell badge),
 * so the app keeps working — only OS-level background pushes are skipped.
 */
class WebPushSender
{
    public static function sendToUser(int $userId, array $payload): int
    {
        $subs = PushSubscription::where('user_id', $userId)->get();
        return self::dispatch($subs, $payload);
    }

    public static function sendToUsers(array $userIds, array $payload): int
    {
        if (!$userIds) return 0;
        $subs = PushSubscription::whereIn('user_id', $userIds)->get();
        return self::dispatch($subs, $payload);
    }

    protected static function dispatch($subs, array $payload): int
    {
        if ($subs->isEmpty()) return 0;
        if (!class_exists(\Minishlink\WebPush\WebPush::class)) {
            // Library not installed — no-op (in-app bell still notifies).
            return 0;
        }
        $pub = (string) env('VAPID_PUBLIC_KEY');
        $priv = (string) env('VAPID_PRIVATE_KEY');
        $subject = (string) env('VAPID_SUBJECT', 'mailto:admin@example.com');
        if (!$pub || !$priv) return 0;

        try {
            $auth = ['VAPID' => ['subject' => $subject, 'publicKey' => $pub, 'privateKey' => $priv]];
            $webPush = new \Minishlink\WebPush\WebPush($auth);
            $count = 0;
            foreach ($subs as $s) {
                $sub = \Minishlink\WebPush\Subscription::create([
                    'endpoint'        => $s->endpoint,
                    'publicKey'       => $s->p256dh,
                    'authToken'       => $s->auth,
                    'contentEncoding' => 'aes128gcm',
                ]);
                $webPush->queueNotification($sub, json_encode($payload, JSON_UNESCAPED_UNICODE));
                $count++;
            }
            foreach ($webPush->flush() as $report) {
                if (!$report->isSuccess() && $report->isSubscriptionExpired()) {
                    PushSubscription::where('endpoint', $report->getRequest()->getUri()->__toString())->delete();
                }
            }
            return $count;
        } catch (\Throwable $e) {
            Log::warning('WebPush failed: ' . $e->getMessage());
            return 0;
        }
    }
}
