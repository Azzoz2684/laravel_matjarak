<?php

namespace App\Http\Middleware;

use App\Models\AppSetting;
use Closure;
use Illuminate\Http\Request;

class RequirePrivacyAcceptance
{
    /**
     * Routes always allowed even if the user hasn't accepted the policy.
     */
    protected array $whitelist = [
        'privacy.show', 'privacy.accept', 'privacy.store',
        'logout', 'login', 'register',
        'auth.google', 'auth.google.callback',
    ];

    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if (!$user) return $next($request);

        $routeName = optional($request->route())->getName();
        if ($routeName && in_array($routeName, $this->whitelist, true)) {
            return $next($request);
        }

        // Allow static/asset requests unconditionally.
        if ($request->is('assets/*') || $request->is('uploads/*') || $request->is('push/*')) {
            return $next($request);
        }

        $currentVersion = (string) AppSetting::get('privacy_version', '1');
        $accepted = (string) ($user->privacy_version ?? '');
        if ($accepted !== '' && $accepted === $currentVersion) {
            return $next($request);
        }

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(['error' => 'privacy_acceptance_required'], 403);
        }

        return redirect()->route('privacy.show');
    }
}
