<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureUserHasRole
{
    public function handle(Request $request, Closure $next, string $role)
    {
        if (!auth()->check()) {
            return $request->expectsJson()
                ? response()->json(['error' => 'Unauthorized'], 401)
                : redirect()->route('login');
        }
        $user = auth()->user();
        if (!$user->hasRole($role) && !$user->hasRole('admin')) {
            return $request->expectsJson()
                ? response()->json(['error' => 'Forbidden'], 403)
                : abort(403);
        }
        return $next($request);
    }
}
