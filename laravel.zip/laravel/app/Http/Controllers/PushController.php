<?php
namespace App\Http\Controllers;

use App\Models\PushSubscription;
use Illuminate\Http\Request;

class PushController extends Controller
{
    public function vapidKey()
    {
        return response()->json(['key' => (string) env('VAPID_PUBLIC_KEY', '')]);
    }

    public function subscribe(Request $r)
    {
        $data = $r->validate([
            'endpoint' => 'required|string|max:2048',
            'keys.p256dh' => 'required|string|max:255',
            'keys.auth'   => 'required|string|max:255',
        ]);
        PushSubscription::updateOrCreate(
            ['user_id' => auth()->id(), 'endpoint' => $data['endpoint']],
            [
                'p256dh' => $data['keys']['p256dh'],
                'auth'   => $data['keys']['auth'],
                'ua'     => substr((string) $r->userAgent(), 0, 255),
            ]
        );
        return response()->json(['ok' => true]);
    }

    public function unsubscribe(Request $r)
    {
        $endpoint = $r->input('endpoint');
        if ($endpoint) {
            PushSubscription::where('user_id', auth()->id())
                ->where('endpoint', $endpoint)->delete();
        }
        return response()->json(['ok' => true]);
    }
}
