<?php
namespace App\Http\Controllers;

use App\Models\Like;
use App\Models\Save;
use App\Models\Comment;
use App\Models\Notification;
use App\Models\Report;
use App\Models\Post;
use Illuminate\Http\Request;

class InteractionController extends Controller
{
    public function toggleLike(Post $post)
    {
        $existing = Like::where('user_id', auth()->id())->where('post_id', $post->id)->first();
        if ($existing) { $existing->delete(); $liked = false; }
        else { Like::create(['user_id' => auth()->id(), 'post_id' => $post->id]); $liked = true; }
        $count = Like::where('post_id', $post->id)->count();
        if (request()->expectsJson()) return response()->json(['liked' => $liked, 'important' => $liked, 'likes_count' => $count]);
        return back();
    }

    public function toggleSave(Post $post)
    {
        $existing = Save::where('user_id', auth()->id())->where('post_id', $post->id)->first();
        if ($existing) { $existing->delete(); $saved = false; }
        else { Save::create(['user_id' => auth()->id(), 'post_id' => $post->id]); $saved = true; }
        if (request()->expectsJson()) return response()->json(['saved' => $saved]);
        return back();
    }

    public function comment(Request $r, Post $post)
    {
        $data = $r->validate([
            'body' => 'required|string|max:1000',
            'parent_id' => 'nullable|integer|exists:comments,id',
        ]);
        $comment = Comment::create([
            'user_id' => auth()->id(),
            'post_id' => $post->id,
            'parent_id' => $data['parent_id'] ?? null,
            'body' => $data['body'],
        ]);

        $author = auth()->user();
        $link = route('posts.show', $post, false) . '#cmt-' . $comment->id;

        // Notify post owner on a new top-level comment
        if (!$comment->parent_id && $post->user_id !== auth()->id()) {
            Notification::create([
                'user_id' => $post->user_id,
                'title' => '💬 تعليق جديد على إعلانك',
                'body' => '@' . $author->username . ': ' . mb_substr($data['body'], 0, 120),
                'link' => $link,
                'type' => 'comment',
                'post_id' => $post->id,
            ]);
            \App\Services\WebPushSender::sendToUser($post->user_id, [
                'title' => '💬 تعليق جديد على إعلانك',
                'body' => '@' . $author->username . ': ' . mb_substr($data['body'], 0, 120),
                'url' => $link, 'tag' => 'cmt-' . $comment->id,
            ]);
        }
        // Notify parent comment owner on a reply
        if ($comment->parent_id) {
            $parent = Comment::find($comment->parent_id);
            if ($parent && $parent->user_id !== auth()->id()) {
                Notification::create([
                    'user_id' => $parent->user_id,
                    'title' => '↩ رد على تعليقك',
                    'body' => '@' . $author->username . ': ' . mb_substr($data['body'], 0, 120),
                    'link' => $link,
                    'type' => 'reply',
                    'post_id' => $post->id,
                ]);
                \App\Services\WebPushSender::sendToUser($parent->user_id, [
                    'title' => '↩ رد على تعليقك',
                    'body' => '@' . $author->username . ': ' . mb_substr($data['body'], 0, 120),
                    'url' => $link, 'tag' => 'reply-' . $comment->id,
                ]);
            }
        }

        if ($r->expectsJson()) {
            return response()->json([
                'success' => true,
                'comment' => [
                    'id' => $comment->id,
                    'body' => $comment->body,
                    'parent_id' => $comment->parent_id,
                    'username' => $author->username,
                    'when' => $comment->created_at->diffForHumans(),
                ],
            ]);
        }
        return back();
    }

    public function report(Request $r, Post $post)
    {
        $data = $r->validate(['reason' => 'required|string|max:500']);
        Report::create([
            'user_id' => auth()->id(),
            'post_id' => $post->id,
            'reason' => $data['reason'],
            'status' => 'pending',
        ]);
        if (request()->expectsJson()) return response()->json(['success' => true]);
        return back()->with('success', 'تم استلام البلاغ، شكراً لك');
    }
}
