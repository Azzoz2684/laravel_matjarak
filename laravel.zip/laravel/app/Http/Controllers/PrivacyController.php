<?php

namespace App\Http\Controllers;

use App\Models\AppSetting;
use Illuminate\Http\Request;

class PrivacyController extends Controller
{
    public function show()
    {
        $content = AppSetting::get('privacy_policy', $this->defaultPolicy());
        $version = (string) AppSetting::get('privacy_version', '1');
        $mustAccept = auth()->check()
            && (string) (auth()->user()->privacy_version ?? '') !== $version;
        return view('privacy.policy', compact('content', 'version', 'mustAccept'));
    }

    public function accept(Request $request)
    {
        $request->validate(['accept' => 'accepted']);
        if (!auth()->check()) return redirect()->route('login');
        $version = (string) AppSetting::get('privacy_version', '1');
        $user = auth()->user();
        $user->forceFill([
            'privacy_accepted_at' => now(),
            'privacy_version'     => $version,
        ])->save();
        return redirect()->intended('/')->with('success', 'شكراً — تم قبول سياسة الخصوصية.');
    }

    protected function defaultPolicy(): string
    {
        return "سياسة الخصوصية\n\n"
            . "نحن نحترم خصوصيتك. يتم جمع الحد الأدنى من البيانات لتشغيل الخدمة (الاسم، رقم الهاتف، الإعلانات المنشورة). "
            . "لا نبيع بياناتك لأي طرف ثالث. يمكنك طلب حذف حسابك في أي وقت من صفحة الإعدادات أو بمراسلة الدعم.\n\n"
            . "باستخدامك للتطبيق فإنك توافق على شروط الاستخدام هذه.";
    }
}
