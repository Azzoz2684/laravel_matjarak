<?php

namespace App\Http\Controllers;

use App\Models\WalletAnnouncement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WalletAnnouncementController extends Controller
{
    public function __construct() { $this->middleware('auth'); }

    /** Dismiss (acknowledge) an announcement for the current user. */
    public function dismiss(Request $request, WalletAnnouncement $announcement)
    {
        DB::table('wallet_announcement_dismissals')->updateOrInsert(
            ['announcement_id' => $announcement->id, 'user_id' => auth()->id()],
            ['dismissed_at' => now()]
        );
        return back()->with('success', 'تم إخفاء التنبيه.');
    }
}
