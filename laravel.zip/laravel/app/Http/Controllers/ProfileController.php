<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Save;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function show()
    {
        $user = auth()->user();
        $posts = Post::where('user_id', $user->id)->latest()->get();
        $saved = Save::with('post.user')->where('user_id', $user->id)->latest()->get();
        return view('profile.show', compact('user', 'posts', 'saved'));
    }

    public function edit() { return view('profile.edit', ['user' => auth()->user()]); }

    public function update(Request $r)
    {
        $data = $r->validate([
            'full_name' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:50',
            'bio' => 'nullable|string|max:500',
            'password' => 'nullable|string|min:6|confirmed',
            'avatar' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $user = auth()->user();
        $user->fill(array_filter([
            'full_name' => $data['full_name'] ?? null,
            'state' => $data['state'] ?? null,
            'bio' => $data['bio'] ?? null,
        ]));
        if (!empty($data['password'])) $user->password = $data['password'];
        if ($r->hasFile('avatar')) {
            $f = $r->file('avatar');
            $name = 'avatar_' . $user->id . '_' . time() . '.' . $f->getClientOriginalExtension();
            $f->move(public_path('uploads'), $name);
            $user->avatar_url = '/uploads/' . $name;
        }
        $user->save();
        if ($r->wantsJson() || $r->ajax()) return response()->json(['ok' => true, 'message' => 'تم تحديث الملف']);
        return back()->with('success', 'تم تحديث الملف');
    }

    /** Granular AJAX field update: full_name, email, state, bio, password */
    public function updateField(Request $r)
    {
        $field = $r->input('field');
        $allowed = ['full_name', 'email', 'state', 'bio', 'password'];
        if (!in_array($field, $allowed, true)) {
            return response()->json(['ok' => false, 'message' => 'حقل غير مسموح'], 422);
        }
        $rules = [
            'full_name' => 'required|string|max:100',
            'email'     => 'nullable|email|max:191',
            'state'     => 'nullable|string|max:50',
            'bio'       => 'nullable|string|max:500',
            'password'  => 'required|string|min:6|confirmed',
        ][$field];
        $data = $r->validate([$field => $rules] + ($field === 'password' ? ['password_confirmation' => 'required'] : []));

        $user = auth()->user();
        if ($field === 'password') {
            $user->password = $data['password'];
        } else {
            $user->{$field} = $data[$field] ?? null;
        }
        $user->save();
        return response()->json(['ok' => true, 'message' => 'تم الحفظ', 'value' => $field === 'password' ? null : $user->{$field}]);
    }
}
