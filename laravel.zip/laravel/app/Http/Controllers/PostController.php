<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\User;
use App\Models\Notification;
use App\Models\SellerRating;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;

class PostController extends Controller
{
    public function show(Post $post)
    {
        $post->increment('views_count');
        $post->load('user', 'comments.user');

        // Recommendations: same category, exclude self, recent
        $recommended = Post::where('status', 'active')
            ->where('id', '!=', $post->id)
            ->where(function ($q) use ($post) {
                $q->where('category', $post->category)
                  ->orWhere('state', $post->state);
            })
            ->orderByDesc('featured')->orderByDesc('created_at')
            ->limit(12)->get();

        // Seller rating summary
        $sellerRatingAvg = (float) SellerRating::where('seller_id', $post->user_id)->avg('stars');
        $sellerRatingCount = (int) SellerRating::where('seller_id', $post->user_id)->count();
        $userRated = null;
        if (auth()->check() && auth()->id() !== $post->user_id) {
            $userRated = SellerRating::where('seller_id', $post->user_id)
                ->where('rater_id', auth()->id())->first();
        }

        return view('posts.show', compact('post','recommended','sellerRatingAvg','sellerRatingCount','userRated'));
    }

    public function rateSeller(Request $r, User $user)
    {
        abort_if(auth()->id() === $user->id, 403, 'لا يمكنك تقييم نفسك');
        $data = $r->validate([
            'stars' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:300',
        ]);
        // One-time only: if exists, do not allow update
        $existing = SellerRating::where('seller_id', $user->id)
            ->where('rater_id', auth()->id())->first();
        if ($existing) {
            return response()->json(['ok' => false, 'message' => 'سبق تقييمك لهذا البائع'], 409);
        }
        SellerRating::create([
            'seller_id' => $user->id,
            'rater_id' => auth()->id(),
            'stars' => $data['stars'],
            'comment' => $data['comment'] ?? null,
        ]);
        $avg = (float) SellerRating::where('seller_id', $user->id)->avg('stars');
        $count = (int) SellerRating::where('seller_id', $user->id)->count();
        return response()->json(['ok' => true, 'avg' => round($avg, 2), 'count' => $count]);
    }

    public function create() { return view('posts.create'); }

    public function store(Request $r)
    {
        $maxMb = (int) env('UPLOAD_MAX_MB', 5);
        $videoMaxMb = (int) env('VIDEO_MAX_MB', 5);
        $data = $r->validate([
            'title'       => 'required|string|max:200',
            'description' => 'required|string|min:10|max:5000',
            'price'       => 'required|numeric|min:0',
            'currency'    => 'required|string|max:10',
            'category'    => 'required|string|max:50',
            'state'       => 'required|string|max:50',
            'city'        => 'required|string|max:100',
            'phone'       => 'nullable|string|max:20',
            'whatsapp'    => 'required|string|max:20',
            'condition'   => 'required|string|max:20',
            'cover_index' => 'nullable|integer|min:0',
            'idempotency_key' => 'nullable|string|max:64',
            'images'      => 'required|array|min:1|max:10',
            'images.*'    => 'image|mimes:jpg,jpeg,png,webp|max:' . ($maxMb * 1024),
            'video'       => 'nullable|file|mimetypes:video/mp4,video/webm,video/quicktime|max:' . ($videoMaxMb * 1024),
        ]);

        $userId = auth()->id();

        // (1) Idempotency-key dedup — replays from the Service Worker with the
        // same key resolve to the same post instead of creating duplicates.
        $idemKey = $data['idempotency_key'] ?? null;
        unset($data['idempotency_key']);
        if ($idemKey) {
            $cacheKey = "post_idem:{$userId}:{$idemKey}";
            $existingId = Cache::get($cacheKey);
            if ($existingId && ($existing = Post::find($existingId))) {
                if ($r->expectsJson()) return response()->json(['post' => $existing, 'duplicate' => true], 200);
                return redirect()->route('home', ['posted' => $existing->id], 303)->with('success', 'تم نشر الإعلان بنجاح');
            }
        }

        // (2) Content-hash dedup — block 100% identical posts from the same user
        // within the last 10 minutes (covers cases where the SW lost the key).
        $contentHash = md5(implode('|', [
            mb_strtolower(trim($data['title'])),
            mb_strtolower(trim($data['description'])),
            (string) $data['price'],
            $data['currency'], $data['category'], $data['state'], $data['city'],
        ]));
        $hashKey = "post_hash:{$userId}:{$contentHash}";
        $dupId = Cache::get($hashKey);
        if ($dupId && ($dup = Post::find($dupId))) {
            if ($idemKey) Cache::put("post_idem:{$userId}:{$idemKey}", $dup->id, now()->addHours(24));
            if ($r->expectsJson()) return response()->json(['post' => $dup, 'duplicate' => true], 200);
            return redirect()->route('home', ['posted' => $dup->id], 303)->with('success', 'تم نشر الإعلان بنجاح');
        }
        // DB fallback in case the cache was cleared
        $existingDb = Post::where('user_id', $userId)
            ->where('title', $data['title'])
            ->where('price', $data['price'])
            ->where('category', $data['category'])
            ->where('created_at', '>=', now()->subMinutes(10))
            ->first();
        if ($existingDb) {
            Cache::put($hashKey, $existingDb->id, now()->addMinutes(10));
            if ($idemKey) Cache::put("post_idem:{$userId}:{$idemKey}", $existingDb->id, now()->addHours(24));
            if ($r->expectsJson()) return response()->json(['post' => $existingDb, 'duplicate' => true], 200);
            return redirect()->route('home', ['posted' => $existingDb->id], 303)->with('success', 'تم نشر الإعلان بنجاح');
        }

        $data['whatsapp'] = $this->normalizePhone($data['whatsapp']);
        $paths = $this->saveImages((array) $r->file('images', []));
        if (empty($paths)) {
            return back()->withErrors(['images' => 'يجب رفع صورة واحدة على الأقل'])->withInput();
        }

        $cover = (int) ($data['cover_index'] ?? 0);
        if ($cover > 0 && isset($paths[$cover])) {
            $chosen = $paths[$cover];
            array_splice($paths, $cover, 1);
            array_unshift($paths, $chosen);
        }
        unset($data['cover_index']);

        $videoUrl = null;
        if ($r->hasFile('video')) {
            $videoUrl = $this->saveVideo($r->file('video'));
        }
        unset($data['video']);

        $post = Post::create(array_merge($data, [
            'user_id' => $userId,
            'images' => $paths,
            'video_url' => $videoUrl,
            'status' => 'active',
        ]));

        // Remember this post for dedup on retries / accidental double-submits
        Cache::put($hashKey, $post->id, now()->addMinutes(10));
        if ($idemKey) Cache::put("post_idem:{$userId}:{$idemKey}", $post->id, now()->addHours(24));

        $this->notifyInterestedUsers($post);

        if ($r->expectsJson()) return response()->json(['post' => $post], 201);
        return redirect()->route('home', ['posted' => $post->id], 303)->with('success', 'تم نشر الإعلان بنجاح');
    }

    private function saveVideo($file): ?string
    {
        if (!$file || !$file->isValid()) return null;
        $ext = strtolower($file->getClientOriginalExtension() ?: 'mp4');
        if (!in_array($ext, ['mp4', 'webm', 'mov'])) $ext = 'mp4';
        $name = Str::random(40) . '.' . $ext;
        $file->move(public_path('uploads'), $name);
        return '/uploads/' . $name;
    }

    private function notifyInterestedUsers(Post $post): void
    {
        $title = '🆕 منشور جديد قد يعجبك';
        $body = $post->title . ' — ' . $post->state;
        $link = route('posts.show', $post, false);

        $users = User::where('notify_enabled', true)
            ->where('id', '!=', $post->user_id)
            ->where(function ($q) use ($post) {
                $q->where('notify_scope', 'all')
                  ->orWhere(function ($w) use ($post) {
                      $w->where('notify_scope', 'interests')
                        ->where('interest_categories', 'like', '%"' . $post->category . '"%');
                  });
            })->limit(2000)->pluck('id');

        $now = now();
        $rows = $users->map(fn ($uid) => [
            'user_id' => $uid, 'title' => $title, 'body' => $body,
            'link' => $link, 'type' => 'new_post', 'post_id' => $post->id,
            'is_read' => false, 'created_at' => $now, 'updated_at' => $now,
        ])->all();
        if ($rows) Notification::insert($rows);

        // Pure Web Push (no Firebase) — works when app is closed
        \App\Services\WebPushSender::sendToUsers($users->all(), [
            'title' => $title, 'body' => $body, 'url' => $link, 'tag' => 'post-' . $post->id,
        ]);
    }

    private function normalizePhone(string $phone): string
    {
        $p = preg_replace('/[^0-9+]/', '', $phone);
        if (!str_starts_with($p, '+')) {
            $p = '+249' . ltrim($p, '0');
        }
        return $p;
    }

    private function saveImages(array $files): array
    {
        $paths = [];
        $allowed = ['image/jpeg','image/png','image/webp'];
        foreach ($files as $file) {
            if (!$file || !$file->isValid()) continue;
            $info = @getimagesize($file->getRealPath());
            if (!$info || !in_array($info['mime'] ?? '', $allowed, true)) continue;
            $ext = match($info['mime']) {
                'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp',
            };
            $name = Str::random(40) . '.' . $ext;
            $file->move(public_path('uploads'), $name);
            $paths[] = '/uploads/' . $name;
        }
        return $paths;
    }

    public function edit(Post $post)
    {
        abort_unless($post->user_id === auth()->id() || auth()->user()->hasRole('admin'), 403);
        return view('posts.edit', compact('post'));
    }

    public function update(Request $r, Post $post)
    {
        abort_unless($post->user_id === auth()->id() || auth()->user()->hasRole('admin'), 403);
        $maxMb = (int) env('UPLOAD_MAX_MB', 5);
        $videoMaxMb = (int) env('VIDEO_MAX_MB', 5);
        $data = $r->validate([
            'title'       => 'required|string|max:200',
            'description' => 'required|string|min:10|max:5000',
            'price'       => 'required|numeric|min:0',
            'currency'    => 'nullable|string|max:10',
            'category'    => 'required|string|max:50',
            'state'       => 'required|string|max:50',
            'city'        => 'required|string|max:100',
            'phone'       => 'nullable|string|max:20',
            'whatsapp'    => 'required|string|max:20',
            'condition'   => 'required|string|max:20',
            'existing_images'   => 'nullable|array',
            'existing_images.*' => 'string',
            'existing_cover_index' => 'nullable|integer|min:0',
            'images'    => 'nullable|array|max:10',
            'images.*'  => 'image|mimes:jpg,jpeg,png,webp|max:' . ($maxMb * 1024),
            'video'     => 'nullable|file|mimetypes:video/mp4,video/webm,video/quicktime|max:' . ($videoMaxMb * 1024),
            'remove_video' => 'nullable|boolean',
        ]);

        $data['whatsapp'] = $this->normalizePhone($data['whatsapp']);
        $existing = $data['existing_images'] ?? [];
        $coverIdx = (int) ($data['existing_cover_index'] ?? 0);
        if ($coverIdx > 0 && isset($existing[$coverIdx])) {
            $c = $existing[$coverIdx];
            array_splice($existing, $coverIdx, 1);
            array_unshift($existing, $c);
        }
        $newPaths = $this->saveImages((array) $r->file('images', []));
        $images = array_values(array_merge($existing, $newPaths));
        if (empty($images)) {
            return back()->withErrors(['images' => 'يجب الإبقاء على صورة واحدة على الأقل'])->withInput();
        }

        if ($r->hasFile('video')) {
            $data['video_url'] = $this->saveVideo($r->file('video'));
        } elseif ($r->boolean('remove_video')) {
            $data['video_url'] = null;
        }

        unset($data['existing_images'], $data['existing_cover_index'], $data['images'], $data['video'], $data['remove_video']);
        $data['images'] = $images;

        $post->update($data);
        // Redirect with 303 so back-button after save doesn't return to the edit form.
        return redirect()->route('posts.show', $post, 303)->with('success', 'تم التحديث');
    }

    public function destroy(Post $post)
    {
        abort_unless($post->user_id === auth()->id() || auth()->user()->hasRole('admin'), 403);
        $post->delete();
        return redirect('/')->with('success', 'تم الحذف');
    }
}
