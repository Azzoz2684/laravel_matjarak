<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index()
    {
        return view('settings.index', ['user' => auth()->user()]);
    }

    public function notifications()
    {
        return view('settings.notifications', ['user' => auth()->user()]);
    }

    public function updateNotifications(Request $r)
    {
        $d = $r->validate([
            'notify_enabled' => 'nullable|boolean',
            'notify_scope' => 'required|in:all,interests',
            'interest_categories' => 'nullable|array',
            'interest_categories.*' => 'string|max:80',
        ]);
        $u = auth()->user();
        $u->notify_enabled = $r->boolean('notify_enabled');
        $u->notify_scope = $d['notify_scope'];
        $u->interest_categories = $d['interest_categories'] ?? [];
        $u->save();
        return back()->with('success', 'تم حفظ الإعدادات');
    }

    /** Feed/notifications view mode: grid (Shein-like 2 columns) or single (one per row) */
    public function updateViewMode(Request $r)
    {
        $d = $r->validate(['feed_view_mode' => 'required|in:grid,single']);
        $u = auth()->user();
        $u->feed_view_mode = $d['feed_view_mode'];
        $u->save();
        if ($r->expectsJson()) return response()->json(['success' => true, 'feed_view_mode' => $u->feed_view_mode]);
        return back()->with('success', 'تم تحديث طريقة العرض');
    }

    public function toggleTheme(Request $r)
    {
        $current = session('theme', 'light');
        session(['theme' => $current === 'dark' ? 'light' : 'dark']);
        return back();
    }
}
