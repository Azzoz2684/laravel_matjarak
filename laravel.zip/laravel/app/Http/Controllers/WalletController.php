<?php

namespace App\Http\Controllers;

use App\Models\AppSetting;
use App\Models\Post;
use App\Models\Wallet;
use App\Models\WalletAnnouncement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WalletController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /** Get or lazily create the current user's wallet. */
    protected function wallet(): Wallet
    {
        $user = auth()->user();
        $wallet = Wallet::firstOrCreate(
            ['user_id' => $user->id],
            ['balance' => 0, 'currency' => AppSetting::get('wallet_currency', 'SDG')]
        );
        return $wallet;
    }

    public function show()
    {
        $wallet = $this->wallet();
        $transactions = $wallet->transactions()->latest()->limit(20)->get();
        $announcements = WalletAnnouncement::forUser(auth()->id());
        $featureCost = (float) AppSetting::get('wallet_feature_cost', 2000);
        $featureDays = (int)   AppSetting::get('wallet_feature_days', 7);
        return view('wallet.show', compact('wallet', 'transactions', 'announcements', 'featureCost', 'featureDays'));
    }

    public function featureList()
    {
        $posts = Post::where('user_id', auth()->id())
            ->where('status', 'active')
            ->where(function ($q) {
                $q->where('featured', false)
                  ->orWhereNull('featured_until')
                  ->orWhere('featured_until', '<', now());
            })
            ->latest()
            ->paginate(20);
        return view('wallet.feature-list', compact('posts'));
    }

    public function featureConfirm(Post $post)
    {
        abort_unless($post->user_id === auth()->id(), 403);
        $wallet = $this->wallet();
        $cost = (float) AppSetting::get('wallet_feature_cost', 2000);
        $days = (int)   AppSetting::get('wallet_feature_days', 7);
        return view('wallet.feature-confirm', compact('post', 'wallet', 'cost', 'days'));
    }

    public function featureApply(Request $request, Post $post)
    {
        abort_unless($post->user_id === auth()->id(), 403);
        $cost = (float) AppSetting::get('wallet_feature_cost', 2000);
        $days = (int)   AppSetting::get('wallet_feature_days', 7);

        try {
            DB::transaction(function () use ($post, $cost, $days) {
                $wallet = Wallet::where('user_id', auth()->id())->lockForUpdate()->firstOrFail();
                if ((float) $wallet->balance < $cost) {
                    throw new \RuntimeException('insufficient_funds');
                }
                $wallet->debit($cost, 'feature_post', ['post_id' => $post->id], $post->id, 'تمييز إعلان: ' . mb_substr($post->title, 0, 60));
                $post->update([
                    'featured'       => true,
                    'featured_until' => now()->addDays(max(1, $days)),
                ]);
            });
        } catch (\RuntimeException $e) {
            return back()->with('error', 'رصيد المحفظة غير كافٍ. الرجاء شحن المحفظة أولاً.');
        } catch (\Throwable $e) {
            return back()->with('error', 'حدث خطأ أثناء تنفيذ العملية. حاول مرة أخرى.');
        }

        return redirect()->route('wallet.show')->with('success', 'تم تمييز الإعلان بنجاح ✨');
    }

    public function topupRedirect()
    {
        $phone = preg_replace('/\D+/', '', (string) AppSetting::get('support_whatsapp', ''));
        if ($phone === '') {
            return back()->with('error', 'رقم الدعم غير مضبوط. تواصل مع الإدارة.');
        }
        $appName = AppSetting::get('app_name', 'متجرك');
        $user    = auth()->user();
        $msg = "مرحباً، أنا @{$user->username} من {$appName}. أرغب في شحن محفظتي.";
        $url = 'https://wa.me/' . $phone . '?text=' . rawurlencode($msg);
        return redirect()->away($url);
    }
}
