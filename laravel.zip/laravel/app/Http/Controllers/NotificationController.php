<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use App\Models\Post;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index(Request $r)
    {
        return view('notifications.index', [
            'filter' => $r->get('filter', 'all'),
            'category' => $r->get('category'),
            'sort' => $r->get('sort', 'desc'),
        ]);
    }

    protected function baseQuery(Request $r)
    {
        $q = Notification::where('user_id', auth()->id());
        $filter = $r->get('filter', 'all');
        if ($filter === 'unread') $q->where('is_read', false);
        if ($filter === 'read') $q->where('is_read', true);

        if ($cat = $r->get('category')) {
            // notifications tied to posts in given category (via post_id)
            $postIds = Post::where('category', $cat)->pluck('id');
            $q->whereIn('post_id', $postIds);
        }
        $sort = $r->get('sort', 'desc') === 'asc' ? 'asc' : 'desc';
        return $q->orderBy('created_at', $sort);
    }

    public function unreadCount()
    {
        return response()->json([
            'count' => Notification::where('user_id', auth()->id())->where('is_read', false)->count(),
        ]);
    }

    public function feed(Request $r)
    {
        $items = $this->baseQuery($r)->limit(50)->get();
        return response()->json(['items' => $items]);
    }

    public function markRead(Notification $notification)
    {
        abort_unless($notification->user_id === auth()->id(), 403);
        $notification->update(['is_read' => true]);
        if (request()->expectsJson()) return response()->json(['success' => true]);
        return back();
    }

    public function markAll()
    {
        Notification::where('user_id', auth()->id())->update(['is_read' => true]);
        if (request()->expectsJson()) return response()->json(['success' => true]);
        return back();
    }

    public function destroy(Notification $notification)
    {
        abort_unless($notification->user_id === auth()->id(), 403);
        $notification->delete();
        if (request()->expectsJson()) return response()->json(['success' => true]);
        return back();
    }
}
