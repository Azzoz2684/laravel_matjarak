<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\NotInterested;
use App\Models\SearchQuery;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $r)
    {
        $category = $r->get('category');
        $state = $r->get('state');
        $q = trim((string) $r->get('q'));

        $query = Post::with('user')->where('status', 'active');

        if ($category) $query->where('category', $category);
        if ($state) $query->where('state', $state);
        if ($q !== '') $query->where(function ($w) use ($q) {
            $w->where('title', 'like', "%$q%")
              ->orWhere('description', 'like', "%$q%");
        });

        if (auth()->check()) {
            $excluded = NotInterested::where('user_id', auth()->id())->pluck('post_id');
            if ($excluded->count()) $query->whereNotIn('id', $excluded);
        }

        $posts = $query->orderByDesc('featured')->orderByDesc('created_at')->paginate(20);
        $featured = Post::with('user')->featured()->where('status', 'active')->latest()->limit(8)->get();


        // Track non-empty searches for analytics (best-effort)
        if ($q !== '' && mb_strlen($q) <= 200) {
            try {
                SearchQuery::create([
                    'user_id' => auth()->id(),
                    'query' => $q,
                    'category' => $category,
                    'state' => $state,
                    'results_count' => $posts->total(),
                    'ip' => $r->ip(),
                ]);
            } catch (\Throwable $e) {}
        }

        return view('home', compact('posts', 'featured', 'category', 'state', 'q'));
    }

    public function featured()
    {
        $posts = Post::with('user')->featured()->where('status', 'active')->latest()->paginate(20);
        return view('posts.featured', compact('posts'));
    }
}
