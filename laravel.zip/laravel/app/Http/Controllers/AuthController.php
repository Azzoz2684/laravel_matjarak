<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function showLogin() { return view('auth.login'); }
    public function showRegister() { return view('auth.register'); }

    public function login(Request $r)
    {
        $data = $r->validate([
            'phone'    => 'required|string',
            'password' => 'required|string|min:6',
        ]);
        // Always remember=true (persistent recall cookie).
        if (!Auth::attempt($data, true)) {
            return back()->withErrors(['phone' => 'بيانات الدخول غير صحيحة. تأكد من رقم الهاتف وكلمة المرور.'])->withInput();
        }
        $r->session()->regenerate();
        $this->extendRememberCookie($r);
        return redirect()->intended('/');
    }

    public function register(Request $r)
    {
        $data = $r->validate([
            'username'  => 'required|string|max:50|unique:users,username',
            'full_name' => 'required|string|max:100',
            'phone'     => 'required|string|max:20|unique:users,phone',
            'password'  => 'required|string|min:6|confirmed',
        ]);
        $user = User::create($data);
        UserRole::create(['user_id' => $user->id, 'role' => 'user']);
        $this->grantSignupBonus($user);
        Auth::login($user, true);
        $this->extendRememberCookie($r);
        return redirect('/');
    }

    /** Grant one-time welcome credit to the new user's wallet. */
    protected function grantSignupBonus(User $user): void
    {
        try {
            $bonus = (float) \App\Models\AppSetting::get('wallet_signup_bonus', 5000);
            if ($bonus <= 0) return;
            $wallet = $user->walletOrCreate();
            $already = \App\Models\WalletTransaction::where('user_id', $user->id)
                ->where('reason', 'signup_bonus')->exists();
            if (!$already) {
                $wallet->credit($bonus, 'signup_bonus', ['source' => 'auto'], null, 'مكافأة ترحيبية عند التسجيل');
            }
        } catch (\Throwable $e) { /* fail-silent — never block signup */ }
    }

    private function extendRememberCookie(Request $r): void
    {
        $cookieName = Auth::guard('web')->getRecallerName();
        if ($cookieName && $r->cookies->has($cookieName)) {
            cookie()->queue(cookie()->forever($cookieName, $r->cookies->get($cookieName)));
        }
    }

    public function logout(Request $r)
    {
        Auth::logout();
        $r->session()->invalidate();
        $r->session()->regenerateToken();
        return redirect('/');
    }

    // ===== Google OAuth (no external package; raw HTTP) =====
    public function googleRedirect()
    {
        $clientId = config('services.google.client_id');
        $redirect = config('services.google.redirect') ?: url('/auth/google/callback');
        if (!$clientId) {
            return redirect()->route('login')->withErrors(['phone' => 'تسجيل الدخول عبر جوجل غير مفعّل حالياً.']);
        }
        $params = http_build_query([
            'client_id'     => $clientId,
            'redirect_uri'  => $redirect,
            'response_type' => 'code',
            'scope'         => 'openid email profile',
            'access_type'   => 'online',
            'prompt'        => 'select_account',
        ]);
        return redirect('https://accounts.google.com/o/oauth2/v2/auth?' . $params);
    }

    public function googleCallback(Request $r)
    {
        $code = $r->get('code');
        $clientId = config('services.google.client_id');
        $clientSecret = config('services.google.client_secret');
        $redirect = config('services.google.redirect') ?: url('/auth/google/callback');
        if (!$code || !$clientId || !$clientSecret) {
            return redirect()->route('login')->withErrors(['phone' => 'تعذّر تسجيل الدخول عبر جوجل.']);
        }
        try {
            $tokRes = Http::asForm()->post('https://oauth2.googleapis.com/token', [
                'code' => $code,
                'client_id' => $clientId,
                'client_secret' => $clientSecret,
                'redirect_uri' => $redirect,
                'grant_type' => 'authorization_code',
            ]);
            if (!$tokRes->ok()) throw new \Exception('token_failed');
            $accessToken = $tokRes->json('access_token');

            $info = Http::withToken($accessToken)->get('https://openidconnect.googleapis.com/v1/userinfo')->json();
            $googleId = $info['sub'] ?? null;
            $email = $info['email'] ?? null;
            $name = $info['name'] ?? ($email ? explode('@', $email)[0] : 'مستخدم');
            $avatar = $info['picture'] ?? null;
            if (!$googleId) throw new \Exception('no_id');

            $user = User::where('google_id', $googleId)->orWhere('email', $email)->first();
            if (!$user) {
                $username = $email ? explode('@', $email)[0] : 'g_' . substr($googleId, 0, 8);
                $username = Str::slug($username, '_');
                $base = $username; $i = 1;
                while (User::where('username', $username)->exists()) { $username = $base . '_' . $i++; }
                $user = User::create([
                    'username'   => $username,
                    'full_name'  => $name,
                    'email'      => $email,
                    'google_id'  => $googleId,
                    'avatar_url' => $avatar,
                    'phone'      => 'g_' . substr($googleId, 0, 10),
                    'password'   => Hash::make(Str::random(32)),
                ]);
                UserRole::create(['user_id' => $user->id, 'role' => 'user']);
                $this->grantSignupBonus($user);
            } else {
                $user->update(array_filter([
                    'google_id'  => $googleId,
                    'avatar_url' => $avatar ?: $user->avatar_url,
                    'full_name'  => $user->full_name ?: $name,
                    'email'      => $user->email ?: $email,
                ]));
            }
            Auth::login($user, true);
            $r->session()->regenerate();
            $this->extendRememberCookie($r);
            return redirect('/');
        } catch (\Throwable $e) {
            return redirect()->route('login')->withErrors(['phone' => 'فشل تسجيل الدخول عبر جوجل: ' . $e->getMessage()]);
        }
    }

    // ===== JSON API =====
    public function apiLogin(Request $r)
    {
        $d = $r->validate(['phone' => 'required|string', 'password' => 'required|string']);
        $user = User::where('phone', $d['phone'])->first();
        if (!$user || !Hash::check($d['password'], $user->password)) {
            return response()->json(['error' => 'بيانات الدخول غير صحيحة'], 401);
        }
        $token = $user->createToken('api')->plainTextToken;
        return response()->json(['token' => $token, 'user' => $user->load('roles')]);
    }

    public function apiRegister(Request $r)
    {
        $d = $r->validate([
            'username'  => 'required|string|max:50|unique:users,username',
            'full_name' => 'required|string|max:100',
            'phone'     => 'required|string|max:20|unique:users,phone',
            'password'  => 'required|string|min:6',
        ]);
        $user = User::create($d);
        UserRole::create(['user_id' => $user->id, 'role' => 'user']);
        $this->grantSignupBonus($user);
        $token = $user->createToken('api')->plainTextToken;
        return response()->json(['token' => $token, 'user' => $user->load('roles')], 201);
    }
}
