<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\StateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::orderBy('sort_order')->get();
        $states = StateModel::orderBy('sort_order')->get();
        return view('admin.categories', compact('categories', 'states'));
    }

    public function storeCategory(Request $r)
    {
        $d = $r->validate([
            'name' => 'required|string|max:80|unique:categories,name',
            'icon' => 'nullable|string|max:30',
            'sort_order' => 'nullable|integer',
        ]);
        Category::create([
            'name' => $d['name'],
            'slug' => Str::slug($d['name']) ?: Str::random(8),
            'icon' => $d['icon'] ?? null,
            'sort_order' => $d['sort_order'] ?? 0,
        ]);
        return back()->with('success', 'تم إضافة القسم');
    }

    public function updateCategory(Request $r, Category $category)
    {
        $d = $r->validate([
            'name' => 'required|string|max:80',
            'icon' => 'nullable|string|max:30',
            'sort_order' => 'nullable|integer',
            'is_active' => 'nullable|boolean',
        ]);
        $category->update($d + ['is_active' => $r->boolean('is_active')]);
        return back()->with('success', 'تم تحديث القسم');
    }

    public function destroyCategory(Category $category)
    {
        $category->delete();
        return back()->with('success', 'تم حذف القسم');
    }

    public function storeState(Request $r)
    {
        $d = $r->validate([
            'name' => 'required|string|max:80|unique:states,name',
            'sort_order' => 'nullable|integer',
        ]);
        StateModel::create($d);
        return back()->with('success', 'تمت إضافة الولاية');
    }

    public function destroyState(StateModel $state)
    {
        $state->delete();
        return back();
    }

    public function reorderCategories(Request $r)
    {
        $ids = (array) $r->input('order', []);
        foreach ($ids as $i => $id) {
            Category::where('id', (int)$id)->update(['sort_order' => $i]);
        }
        return response()->json(['ok' => true]);
    }

    public function reorderStates(Request $r)
    {
        $ids = (array) $r->input('order', []);
        foreach ($ids as $i => $id) {
            StateModel::where('id', (int)$id)->update(['sort_order' => $i]);
        }
        return response()->json(['ok' => true]);
    }
}
