<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Report;
use App\Models\User;
use App\Models\UserRole;
use App\Models\Notification;
use App\Models\AppSetting;
use App\Models\Broadcast;
use App\Models\SearchQuery;
use Illuminate\Http\Request;
// AI integration removed.
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'users' => User::count(),
            'posts' => Post::count(),
            'pending_reports' => Report::where('status', 'pending')->count(),
            'featured' => Post::where('featured', true)->count(),
        ];
        return view('admin.dashboard', compact('stats'));
    }

    // ============== Users ==============
    public function users()
    {
        $users = User::with('roles')->latest()->paginate(30);
        return view('admin.users', compact('users'));
    }

    public function toggleRole(Request $r, User $user)
    {
        $role = $r->validate(['role' => 'required|in:user,seller,admin'])['role'];
        $existing = UserRole::where('user_id', $user->id)->where('role', $role)->first();
        if ($existing) $existing->delete();
        else UserRole::create(['user_id' => $user->id, 'role' => $role]);
        return back();
    }

    public function destroyUser(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->with('error', 'لا يمكنك حذف حسابك من هنا.');
        }
        // Cascades will clear posts/roles/etc if FKs are set; otherwise model events handle it.
        $user->delete();
        return back()->with('success', 'تم حذف المستخدم.');
    }

    // ============== Posts ==============
    public function posts()
    {
        $posts = Post::with('user')->latest()->paginate(30);
        return view('admin.posts', compact('posts'));
    }

    public function toggleFeatured(Post $post)
    {
        $post->update(['featured' => !$post->featured]);
        return back();
    }

    public function setStatus(Request $r, Post $post)
    {
        $status = $r->validate(['status' => 'required|in:active,hidden,banned,pending'])['status'];
        $post->update(['status' => $status]);
        return back();
    }

    // ============== Reports ==============
    public function reports(Request $r)
    {
        $status = $r->get('status', 'pending');
        $reports = Report::with('post.user', 'reporter')->where('status', $status)->latest()->paginate(30);
        return view('admin.reports', compact('reports', 'status'));
    }

    public function showReport(Report $report)
    {
        $report->load('post.user', 'reporter');
        return view('admin.report_detail', compact('report'));
    }

    public function actReport(Request $r, Report $report)
    {
        $data = $r->validate([
            'status' => 'required|in:reviewed,dismissed,pending',
            'action_reason' => 'nullable|string|max:500',
            'post_action' => 'nullable|in:hide,ban',
        ]);
        $report->update([
            'status' => $data['status'],
            'action_reason' => $data['action_reason'] ?? null,
            'acted_by' => auth()->id(),
            'acted_at' => now(),
        ]);
        $action = $data['post_action'] ?? null;
        if ($action) {
            $report->post->update(['status' => $action === 'hide' ? 'hidden' : 'banned']);
        }
        $reporter = $report->reporter;
        if ($reporter && $reporter->notify_enabled) {
            $title = $data['status'] === 'reviewed' ? 'تم قبول بلاغك ✅' : 'تم رفض بلاغك ❌';
            $body  = ($action ? "الإجراء: " . ($action === 'hide' ? 'إخفاء الإعلان' : 'حظر الإعلان') . ' — ' : '')
                   . ($data['action_reason'] ?? 'تمت مراجعة البلاغ.');
            Notification::create([
                'user_id' => $reporter->id,
                'title'   => $title,
                'body'    => $body,
                'post_id' => $report->post_id,
            ]);
        }
        return redirect()->route('admin.reports')->with('success', 'تم تنفيذ الإجراء');
    }

    // AI Settings removed — feature stripped.


    // ============== General Settings (support whatsapp, app name) ==============
    public function generalSettings()
    {
        return view('admin.general_settings', [
            'support_whatsapp' => AppSetting::get('support_whatsapp', '+249900000000'),
            'app_name'         => AppSetting::get('app_name', 'متجرك'),
        ]);
    }

    public function updateGeneralSettings(Request $r)
    {
        $d = $r->validate([
            'support_whatsapp' => 'required|string|max:20',
            'app_name'         => 'required|string|max:80',
        ]);
        foreach ($d as $k => $v) AppSetting::set($k, $v);
        if ($r->ajax() || $r->wantsJson() || $r->expectsJson()) {
            return response()->json(['ok' => true, 'message' => 'تم الحفظ']);
        }
        return back()->with('success', 'تم حفظ الإعدادات العامة');
    }

    // ============== Broadcast ==============
    public function broadcasts()
    {
        $broadcasts = Broadcast::latest()->paginate(20);
        return view('admin.broadcasts', compact('broadcasts'));
    }

    public function sendBroadcast(Request $r)
    {
        $d = $r->validate([
            'title' => 'required|string|max:150',
            'body'  => 'required|string|max:1000',
            'link'  => 'nullable|url|max:500',
            'link_text' => 'nullable|string|max:80',
            'contact_phone' => 'nullable|string|max:30',
            'contact_text'  => 'nullable|string|max:80',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'target'=> 'required|in:all,sellers,admins',
            'show_on_home' => 'nullable|boolean',
        ]);

        $imageUrl = null;
        if ($r->hasFile('image')) {
            $f = $r->file('image');
            $name = \Illuminate\Support\Str::random(40) . '.' . $f->getClientOriginalExtension();
            $f->move(public_path('uploads'), $name);
            $imageUrl = '/uploads/' . $name;
        }

        $query = User::where('notify_enabled', true);
        if ($d['target'] === 'sellers') {
            $query->whereHas('roles', fn($q) => $q->where('role', 'seller'));
        } elseif ($d['target'] === 'admins') {
            $query->whereHas('roles', fn($q) => $q->where('role', 'admin'));
        }
        $userIds = $query->pluck('id');

        $now = now();
        $rows = $userIds->map(fn($id) => [
            'user_id' => $id, 'title' => $d['title'], 'body' => $d['body'],
            'link' => $d['link'] ?? null, 'type' => 'broadcast',
            'is_read' => false, 'created_at' => $now, 'updated_at' => $now,
        ])->all();
        if ($rows) Notification::insert($rows);

        Broadcast::create([
            'title' => $d['title'], 'body' => $d['body'],
            'link' => $d['link'] ?? null, 'link_text' => $d['link_text'] ?? null,
            'contact_phone' => $d['contact_phone'] ?? null, 'contact_text' => $d['contact_text'] ?? null,
            'image_url' => $imageUrl,
            'is_active' => $r->boolean('show_on_home'),
            'created_by' => auth()->id(), 'recipients_count' => count($rows),
        ]);

        return back()->with('success', "تم الإرسال إلى " . count($rows) . " مستخدم");
    }

    public function toggleBroadcast(Broadcast $broadcast)
    {
        $broadcast->update(['is_active' => !$broadcast->is_active]);
        return back();
    }

    // ============== Search analytics ==============
    public function searchTrends()
    {
        $top = SearchQuery::selectRaw('query, COUNT(*) as cnt, MAX(created_at) as last_at, AVG(results_count) as avg_results')
            ->groupBy('query')->orderByDesc('cnt')->limit(50)->get();
        $recent = SearchQuery::latest()->paginate(30);
        return view('admin.search_trends', compact('top', 'recent'));
    }

    // ============== Wallets ==============
    public function wallets(Request $r)
    {
        $q = trim((string) $r->get('q'));
        $users = User::with('wallet')
            ->when($q !== '', function ($qb) use ($q) {
                $qb->where(function ($w) use ($q) {
                    $w->where('username', 'like', "%$q%")
                      ->orWhere('full_name', 'like', "%$q%")
                      ->orWhere('phone', 'like', "%$q%");
                });
            })
            ->latest()->paginate(30)->withQueryString();
        return view('admin.wallets.index', compact('users'));
    }

    public function walletTopup(Request $r, User $user)
    {
        $d = $r->validate([
            'amount' => 'required|numeric|min:0.01|max:100000000',
            'note'   => 'nullable|string|max:200',
        ]);
        $wallet = $user->walletOrCreate();
        try {
            $wallet->credit((float) $d['amount'], 'admin_topup', ['admin_id' => auth()->id()], auth()->id(), $d['note'] ?? null);
        } catch (\Throwable $e) {
            return back()->with('error', 'تعذّر تنفيذ الشحن: ' . $e->getMessage());
        }
        return back()->with('success', 'تم شحن محفظة ' . $user->username . ' بمبلغ ' . number_format((float) $d['amount'], 2));
    }

    public function walletTransactions(User $user)
    {
        $transactions = $user->walletTransactions()->latest()->paginate(50);
        return view('admin.wallets.transactions', compact('user', 'transactions'));
    }

    public function walletSettings()
    {
        return view('admin.wallets.settings', [
            'wallet_signup_bonus' => AppSetting::get('wallet_signup_bonus', 5000),
            'wallet_feature_cost' => AppSetting::get('wallet_feature_cost', 2000),
            'wallet_feature_days' => AppSetting::get('wallet_feature_days', 7),
            'wallet_currency'     => AppSetting::get('wallet_currency', 'SDG'),
            'support_whatsapp'    => AppSetting::get('support_whatsapp', ''),
            'privacy_policy'      => AppSetting::get('privacy_policy', ''),
            'privacy_version'     => AppSetting::get('privacy_version', '1'),
        ]);
    }

    public function updateWalletSettings(Request $r)
    {
        $d = $r->validate([
            'wallet_signup_bonus' => 'required|numeric|min:0',
            'wallet_feature_cost' => 'required|numeric|min:0',
            'wallet_feature_days' => 'required|integer|min:1|max:365',
            'wallet_currency'     => 'required|string|max:8',
            'support_whatsapp'    => 'required|string|max:20',
        ]);
        foreach ($d as $k => $v) AppSetting::set($k, $v);
        return back()->with('success', 'تم حفظ إعدادات المحفظة');
    }

    // ============== Wallet Announcements ==============
    public function announcementsIndex()
    {
        $announcements = \App\Models\WalletAnnouncement::latest()->paginate(30);
        return view('admin.announcements.index', compact('announcements'));
    }

    public function announcementsStore(Request $r)
    {
        $d = $r->validate([
            'title' => 'required|string|max:200',
            'body'  => 'required|string|max:2000',
            'level' => 'required|in:info,success,warning,danger',
            'is_active' => 'nullable|boolean',
        ]);
        \App\Models\WalletAnnouncement::create([
            'title' => $d['title'],
            'body'  => $d['body'],
            'level' => $d['level'],
            'is_active' => $r->boolean('is_active'),
            'created_by' => auth()->id(),
        ]);
        return back()->with('success', 'تم إنشاء التنبيه.');
    }

    public function announcementsToggle(\App\Models\WalletAnnouncement $announcement)
    {
        $announcement->update(['is_active' => !$announcement->is_active]);
        return back();
    }

    public function announcementsDestroy(\App\Models\WalletAnnouncement $announcement)
    {
        $announcement->delete();
        return back()->with('success', 'تم الحذف.');
    }

    // ============== Privacy policy ==============
    public function updatePrivacy(Request $r)
    {
        $d = $r->validate([
            'privacy_policy'  => 'required|string|max:20000',
            'privacy_version' => 'required|string|max:20',
        ]);
        AppSetting::set('privacy_policy', $d['privacy_policy']);
        AppSetting::set('privacy_version', $d['privacy_version']);
        return back()->with('success', 'تم تحديث سياسة الخصوصية.');
    }
}

