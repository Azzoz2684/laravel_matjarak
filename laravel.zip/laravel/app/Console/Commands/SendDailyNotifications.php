<?php
namespace App\Console\Commands;

use App\Models\Notification;
use App\Models\Post;
use App\Models\User;
use Illuminate\Console\Command;

/**
 * php artisan notifications:daily
 * Run once per day via cron:  0 9 * * *  cd ~/public_html && php artisan notifications:daily
 */
class SendDailyNotifications extends Command
{
    protected $signature = 'notifications:daily';
    protected $description = 'إرسال إشعار يومي للمستخدمين حسب تفضيلاتهم';

    public function handle(): int
    {
        $sent = 0;
        User::where('notify_enabled', true)
            ->where(function ($q) {
                $q->whereNull('last_daily_notified_at')
                  ->orWhere('last_daily_notified_at', '<', now()->subDay());
            })
            ->chunk(200, function ($users) use (&$sent) {
                foreach ($users as $u) {
                    $q = Post::where('status', 'active')->latest();
                    if ($u->notify_scope === 'interests' && !empty($u->interest_categories)) {
                        $q->whereIn('category', (array)$u->interest_categories);
                    }
                    $post = $q->first();
                    if (!$post) continue;
                    Notification::create([
                        'user_id' => $u->id,
                        'title' => 'إعلان جديد قد يهمك',
                        'body' => mb_substr($post->title, 0, 120),
                        'post_id' => $post->id,
                    ]);
                    $u->update(['last_daily_notified_at' => now()]);
                    $sent++;
                }
            });
        $this->info("Sent $sent notifications.");
        return 0;
    }
}
