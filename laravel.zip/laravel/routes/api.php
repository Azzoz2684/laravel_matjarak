<?php
// JSON API mirror (Sanctum tokens) — for mobile app / external clients
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InteractionController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\AuthController;
use App\Models\Post;
use App\Models\Category;

Route::post('/auth/login',    [AuthController::class, 'apiLogin']);
Route::post('/auth/register', [AuthController::class, 'apiRegister']);

Route::get('/posts', function () {
    return Post::with('user')->where('status', 'active')->latest()->paginate(20);
});
Route::get('/posts/{post}', fn(Post $post) => $post->load('user', 'comments.user'));
Route::get('/categories', fn() => Category::where('is_active', true)->orderBy('sort_order')->get());

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/me', fn() => auth()->user()->load('roles'));
    Route::post('/posts',                          [PostController::class, 'store']);
    Route::put('/posts/{post}',                    [PostController::class, 'update']);
    Route::delete('/posts/{post}',                 [PostController::class, 'destroy']);

    Route::post('/posts/{post}/like',              [InteractionController::class, 'toggleLike']);
    Route::post('/posts/{post}/save',              [InteractionController::class, 'toggleSave']);
    Route::post('/posts/{post}/not-interested',    [InteractionController::class, 'notInterested']);
    Route::post('/posts/{post}/comments',          [InteractionController::class, 'comment']);
    Route::post('/posts/{post}/report',            [InteractionController::class, 'report']);

    Route::get('/notifications',                   [NotificationController::class, 'feed']);
    Route::get('/notifications/unread-count',      [NotificationController::class, 'unreadCount']);
    Route::post('/notifications/{notification}/read', [NotificationController::class, 'markRead']);
    Route::post('/notifications/read-all',         [NotificationController::class, 'markAll']);
    Route::delete('/notifications/{notification}', [NotificationController::class, 'destroy']);
});
