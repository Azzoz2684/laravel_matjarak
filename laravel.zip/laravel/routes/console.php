<?php
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', fn() => $this->comment(Inspiring::quote()))->purpose('Inspiring quote');

// Daily push at 9am (works if you set up cron: * * * * * php artisan schedule:run)
Schedule::command('notifications:daily')->dailyAt('09:00');
