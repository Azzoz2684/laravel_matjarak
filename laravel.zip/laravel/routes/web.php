<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\InteractionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\PushController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\WalletAnnouncementController;
use App\Http\Controllers\PrivacyController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\CategoryController;

// Public — VAPID key for client subscription
Route::get('/push/vapid-key', [PushController::class, 'vapidKey']);

// Public — Live broadcasts feed
Route::get('/broadcasts/feed', function () {
    $items = \App\Models\Broadcast::where('is_active', true)
        ->latest()->limit(20)->get()->map(function ($b) {
            return [
                'id'=>$b->id,'title'=>$b->title,'body'=>$b->body,'link'=>$b->link,
                'link_text'=>$b->link_text,'phone'=>$b->contact_phone,'ctext'=>$b->contact_text,
                'image'=>$b->image_url,'updated'=>optional($b->updated_at)->timestamp,
            ];
        });
    return response()->json(['items'=>$items,'ts'=>now()->timestamp])
        ->header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
})->name('broadcasts.feed');

// Public privacy view (readable to anyone)
Route::get('/privacy', [PrivacyController::class, 'show'])->name('privacy.show');
Route::post('/privacy/accept', [PrivacyController::class, 'accept'])
    ->middleware(['auth', 'throttle:20,1'])->name('privacy.accept');

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/featured', [HomeController::class, 'featured'])->name('featured');
Route::get('/posts/{post}', [PostController::class, 'show'])->name('posts.show');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:5,1');
    Route::get('/auth/google', [AuthController::class, 'googleRedirect'])->name('auth.google');
    Route::get('/auth/google/callback', [AuthController::class, 'googleCallback'])->name('auth.google.callback');
});
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

Route::middleware(['auth', 'privacy'])->group(function () {
    Route::get('/create-ad', [PostController::class, 'create'])->name('posts.create');
    Route::post('/posts', [PostController::class, 'store'])->name('posts.store');
    Route::get('/posts/{post}/edit', [PostController::class, 'edit'])->name('posts.edit');
    Route::put('/posts/{post}', [PostController::class, 'update'])->name('posts.update');
    Route::delete('/posts/{post}', [PostController::class, 'destroy'])->name('posts.destroy');

    Route::post('/posts/{post}/like', [InteractionController::class, 'toggleLike'])->name('posts.like');
    Route::post('/posts/{post}/save', [InteractionController::class, 'toggleSave'])->name('posts.save');
    Route::post('/posts/{post}/comments', [InteractionController::class, 'comment'])->name('posts.comment');
    Route::post('/posts/{post}/report', [InteractionController::class, 'report'])->name('posts.report');
    Route::post('/sellers/{user}/rate', [PostController::class, 'rateSeller'])->name('sellers.rate');

    Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
    Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::patch('/profile/field', [ProfileController::class, 'updateField'])->name('profile.updateField');

    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::get('/notifications/feed', [NotificationController::class, 'feed'])->name('notifications.feed');
    Route::get('/notifications/unread-count', [NotificationController::class, 'unreadCount']);
    Route::post('/notifications/{notification}/read', [NotificationController::class, 'markRead'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'markAll'])->name('notifications.readAll');
    Route::delete('/notifications/{notification}', [NotificationController::class, 'destroy'])->name('notifications.destroy');
    Route::post('/notifications/{notification}', [NotificationController::class, 'destroy']);

    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::get('/settings/notifications', [SettingsController::class, 'notifications'])->name('settings.notifications');
    Route::post('/settings/notifications', [SettingsController::class, 'updateNotifications'])->name('settings.notifications.update');
    Route::post('/settings/view-mode', [SettingsController::class, 'updateViewMode'])->name('settings.viewMode');
    Route::post('/settings/theme', [SettingsController::class, 'toggleTheme'])->name('settings.theme');

    Route::post('/push/subscribe', [PushController::class, 'subscribe'])->name('push.subscribe');
    Route::post('/push/unsubscribe', [PushController::class, 'unsubscribe'])->name('push.unsubscribe');

    // Wallet (user)
    Route::prefix('wallet')->name('wallet.')->group(function () {
        Route::get('/', [WalletController::class, 'show'])->name('show');
        Route::get('/feature', [WalletController::class, 'featureList'])->name('feature.list');
        Route::get('/feature/{post}', [WalletController::class, 'featureConfirm'])->name('feature.confirm');
        Route::post('/feature/{post}', [WalletController::class, 'featureApply'])
            ->middleware('throttle:10,1')->name('feature.apply');
        Route::get('/topup', [WalletController::class, 'topupRedirect'])
            ->middleware('throttle:20,1')->name('topup');
        Route::post('/announcements/{announcement}/dismiss', [WalletAnnouncementController::class, 'dismiss'])
            ->name('announcements.dismiss');
    });
});

Route::middleware(['auth', 'privacy', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');

    Route::get('/users', [AdminController::class, 'users'])->name('users');
    Route::post('/users/{user}/role', [AdminController::class, 'toggleRole'])->name('users.role');
    Route::delete('/users/{user}', [AdminController::class, 'destroyUser'])->name('users.destroy');

    Route::get('/posts', [AdminController::class, 'posts'])->name('posts');
    Route::post('/posts/{post}/featured', [AdminController::class, 'toggleFeatured'])->name('posts.featured');
    Route::post('/posts/{post}/status', [AdminController::class, 'setStatus'])->name('posts.status');

    Route::get('/reports', [AdminController::class, 'reports'])->name('reports');
    Route::get('/reports/{report}', [AdminController::class, 'showReport'])->name('reports.show');
    Route::post('/reports/{report}/act', [AdminController::class, 'actReport'])->name('reports.act');

    Route::get('/categories', [CategoryController::class, 'index'])->name('categories');
    Route::post('/categories', [CategoryController::class, 'storeCategory'])->name('categories.store');
    Route::put('/categories/{category}', [CategoryController::class, 'updateCategory'])->name('categories.update');
    Route::delete('/categories/{category}', [CategoryController::class, 'destroyCategory'])->name('categories.destroy');
    Route::post('/categories/reorder', [CategoryController::class, 'reorderCategories'])->name('categories.reorder');
    Route::post('/states', [CategoryController::class, 'storeState'])->name('states.store');
    Route::delete('/states/{state}', [CategoryController::class, 'destroyState'])->name('states.destroy');
    Route::post('/states/reorder', [CategoryController::class, 'reorderStates'])->name('states.reorder');

    Route::get('/general', [AdminController::class, 'generalSettings'])->name('general');
    Route::post('/general', [AdminController::class, 'updateGeneralSettings'])->name('general.update');

    Route::get('/broadcasts', [AdminController::class, 'broadcasts'])->name('broadcasts');
    Route::post('/broadcasts', [AdminController::class, 'sendBroadcast'])->name('broadcasts.send');
    Route::post('/broadcasts/{broadcast}/toggle', [AdminController::class, 'toggleBroadcast'])->name('broadcasts.toggle');

    Route::get('/search-trends', [AdminController::class, 'searchTrends'])->name('searchTrends');

    // Wallets admin
    Route::get('/wallets', [AdminController::class, 'wallets'])->name('wallets');
    Route::post('/wallets/{user}/topup', [AdminController::class, 'walletTopup'])
        ->middleware('throttle:30,1')->name('wallets.topup');
    Route::get('/wallets/{user}/transactions', [AdminController::class, 'walletTransactions'])->name('wallets.tx');
    Route::get('/wallets-settings', [AdminController::class, 'walletSettings'])->name('wallets.settings');
    Route::post('/wallets-settings', [AdminController::class, 'updateWalletSettings'])->name('wallets.settings.update');

    // Announcements admin
    Route::get('/announcements', [AdminController::class, 'announcementsIndex'])->name('announcements.index');
    Route::post('/announcements', [AdminController::class, 'announcementsStore'])->name('announcements.store');
    Route::post('/announcements/{announcement}/toggle', [AdminController::class, 'announcementsToggle'])->name('announcements.toggle');
    Route::delete('/announcements/{announcement}', [AdminController::class, 'announcementsDestroy'])->name('announcements.destroy');

    // Privacy admin
    Route::post('/privacy', [AdminController::class, 'updatePrivacy'])->name('privacy.update');
});
